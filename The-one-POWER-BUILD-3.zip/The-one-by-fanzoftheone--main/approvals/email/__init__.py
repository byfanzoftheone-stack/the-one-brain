"""Email approval policies."""
