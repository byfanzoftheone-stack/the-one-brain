"""Control panel node tools."""
