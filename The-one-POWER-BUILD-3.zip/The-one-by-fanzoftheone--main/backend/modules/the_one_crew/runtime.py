from app.services.agents.strategist import run_strategist
from app.services.agents.coordinator import run_coordinator
from app.services.tools import write_file, call_api, store_memory

def execute_plan(plan_steps: list, payload: dict):
    actions = []
    goal = payload.get("goal", "unspecified")
    source = payload.get("source", "unknown")

    for step in plan_steps:
        text = step.lower()

        if "write file" in text:
            result = write_file(
                "warehouse/mission_output.txt",
                f"Mission goal: {goal}\nSource: {source}\nStep: {step}\n"
            )
        elif "store memory" in text:
            result = store_memory({
                "event": "mission_run",
                "goal": goal,
                "source": source,
                "step": step
            })
        elif "call api" in text:
            result = call_api("https://api.github.com")
        else:
            result = {"tool": "noop", "status": "skipped", "step": step}

        actions.append(result)

    return actions

def run_the_one_crew(payload: dict):
    plan = run_strategist(payload)
    execution = execute_plan(plan.get("plan", []), payload)
    result = run_coordinator(plan, execution)

    return {
        "status": "success",
        "crew": "the-one-crew",
        "plan": plan,
        "execution": execution,
        "result": result
    }
