# The One Control Core Backend

Run locally:

python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --app-dir . --reload
