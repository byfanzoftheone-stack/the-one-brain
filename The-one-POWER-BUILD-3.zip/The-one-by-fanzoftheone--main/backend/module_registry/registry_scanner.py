import json
import os

MODULE_DIR = os.path.join(os.getcwd(), "modules")
REGISTRY_FILE = os.path.join(os.getcwd(), "backend/module_registry/module_registry.json")

registry = []

for root, dirs, files in os.walk(MODULE_DIR):
    for file in files:
        if file == "module.json":
            path = os.path.join(root, file)
            try:
                with open(path, "r") as f:
                    data = json.load(f)
                    data["path"] = root.replace(MODULE_DIR + "/", "")
                    registry.append(data)
            except Exception as e:
                print(f"Error loading {path}: {e}")

with open(REGISTRY_FILE, "w") as f:
    json.dump(registry, f, indent=2)

print(f"Registered {len(registry)} modules.")
