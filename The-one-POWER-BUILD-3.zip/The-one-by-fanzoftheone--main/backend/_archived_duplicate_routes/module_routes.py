from fastapi import APIRouter
from app.services.module_registry import modules

router = APIRouter(prefix="/api/modules", tags=["modules"])

@router.get("/")
def list_modules():
    return {"modules": modules()}
