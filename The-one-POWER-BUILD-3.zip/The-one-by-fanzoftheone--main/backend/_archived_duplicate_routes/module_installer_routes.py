from fastapi import APIRouter
from app.services.module_installer import available_modules, install_module

router = APIRouter(prefix="/api/modules", tags=["modules"])

@router.get("/")
def modules():
    return {"modules": available_modules()}

@router.post("/install/{app_name}/{module_name}")
def module_install(app_name: str, module_name: str):
    return install_module(app_name, module_name)
