from fastapi import APIRouter
from app.services.catalog import load_catalog

router = APIRouter(prefix="/api/modules", tags=["modules"])

@router.get("/catalog")
def catalog() -> dict:
    return load_catalog()
