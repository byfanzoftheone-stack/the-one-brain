from pydantic import BaseModel

class KPI(BaseModel):
    label: str
    value: str
    change: str

class ModuleSummary(BaseModel):
    category: str
    count: int
