from pathlib import Path
import json

MODULES_DIR = Path.cwd() / "modules"

def load_modules():
    modules = []
    if not MODULES_DIR.exists():
        return modules

    for module_dir in MODULES_DIR.iterdir():
        manifest = module_dir / "module.json"
        if manifest.exists():
            with open(manifest, "r", encoding="utf-8") as f:
                modules.append(json.load(f))
    return modules
