import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
CATALOG_PATH = ROOT / "modules" / "catalog.json"


def load_catalog() -> dict:
    return json.loads(CATALOG_PATH.read_text())


def get_overview() -> dict:
    catalog = load_catalog()["categories"]
    module_count = sum(len(category["modules"]) for category in catalog)
    return {
        "platform": "THE ONE",
        "tagline": "Because you are the One.",
        "structure": [
            "modules",
            "backend",
            "core",
            "frontend",
            "agents",
            "data",
            "deploy",
            "docs",
            "prompts",
        ],
        "kpis": [
            {"label": "Module Categories", "value": str(len(catalog)), "change": "+ locked"},
            {"label": "Total Modules", "value": str(module_count), "change": "+ expanded"},
            {"label": "Deploy Targets", "value": "Vercel + Railway", "change": "+ pipeline"},
            {"label": "Platform Mode", "value": "Next + FastAPI", "change": "+ restored"},
        ],
        "projects_removed": ["drifted Vite root", "nested app uploads"],
    }
