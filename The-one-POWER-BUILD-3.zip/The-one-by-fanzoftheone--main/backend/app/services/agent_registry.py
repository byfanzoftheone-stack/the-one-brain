"""Agent registry — lists all known agents in THE ONE ecosystem."""

AGENTS = {
    "strategist":  {"name": "Strategist",  "status": "ready", "task": "scores opportunities"},
    "builder":     {"name": "Builder",     "status": "ready", "task": "assembles apps from recipes"},
    "auditor":     {"name": "Auditor",     "status": "ready", "task": "verifies quality"},
    "maid":        {"name": "Maid",        "status": "ready", "task": "cleans up ecosystem"},
    "launcher":    {"name": "Launcher",    "status": "idle",  "task": "deploys to production"},
    "marketplace": {"name": "Marketplace", "status": "idle",  "task": "manages listings"},
}

def list_agents() -> dict:
    return AGENTS

def get_agent(name: str) -> dict | None:
    return AGENTS.get(name)

def agents_online() -> int:
    return sum(1 for a in AGENTS.values() if a["status"] == "ready")
