"""Companion service — thin wrapper over the root companion engine."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../.."))

try:
    from companion.companion_engine import get_state
    def get_companion_state() -> dict:
        return get_state()
except ImportError:
    def get_companion_state() -> dict:
        return {
            "id": "companion", "name": "The One Companion",
            "purpose": "growth partner", "status": "active",
            "modes": ["reflection", "guidance", "planning", "memory", "pattern-detection"],
            "notes": ["revenue engine funds growth engine", "no drift"],
        }
