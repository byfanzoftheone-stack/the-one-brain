import os
import json
import shutil
import zipfile

APP_ROOT = "apps"
EXPORT_ROOT = "exports"

def export_app(app_name):

    app_path = os.path.join(APP_ROOT, app_name)

    if not os.path.exists(app_path):
        return {"error": "app not found"}

    os.makedirs(EXPORT_ROOT, exist_ok=True)

    export_file = os.path.join(EXPORT_ROOT, f"{app_name}.zip")

    with zipfile.ZipFile(export_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(app_path):
            for file in files:
                full = os.path.join(root, file)
                rel = os.path.relpath(full, app_path)
                zipf.write(full, rel)

    return {
        "status": "exported",
        "app": app_name,
        "file": export_file
    }
