import os

APP_ROOT = "apps"

def generate_app(app_name):
    app_path = os.path.join(APP_ROOT, app_name)

    if os.path.exists(app_path):
        return {"status": "exists", "app": app_name}

    os.makedirs(app_path)

    os.makedirs(os.path.join(app_path, "modules"), exist_ok=True)
    os.makedirs(os.path.join(app_path, "config"), exist_ok=True)

    with open(os.path.join(app_path, "app.json"), "w") as f:
        f.write(
f"""{{
"name": "{app_name}",
"modules": []
}}"""
        )

    return {"status": "created", "app": app_name}
