"""
Module Registry — discovers and lists all installed modules.
Scans multiple candidate directories and deduplicates by ID.
"""
import json
from pathlib import Path

def list_modules() -> list:
    base     = Path(__file__).resolve().parents[3]
    roots    = [base / "modules", base / "backend/modules", Path("/app/modules")]
    seen_ids = set()
    modules  = []

    for root in roots:
        if not root.exists():
            continue
        for manifest in sorted(root.glob("*/module.json")):
            try:
                data      = json.loads(manifest.read_text())
                module_id = data.get("id") or manifest.parent.name
                if module_id in seen_ids:
                    continue
                seen_ids.add(module_id)
                data.setdefault("slug",        manifest.parent.name)
                data.setdefault("name",        manifest.parent.name.replace("-", " ").title())
                data.setdefault("status",      "installed")
                data.setdefault("enabled",     True)
                data.setdefault("version",     "1.0.0")
                data.setdefault("description", f"{data['name']} module")
                data.setdefault("price",       0)
                data.setdefault("tags",        [data.get("category", "general")])
                modules.append(data)
            except Exception:
                continue

    return modules

def get_module(slug: str) -> dict | None:
    for m in list_modules():
        if m.get("slug") == slug or m.get("id") == slug:
            return m
    return None
