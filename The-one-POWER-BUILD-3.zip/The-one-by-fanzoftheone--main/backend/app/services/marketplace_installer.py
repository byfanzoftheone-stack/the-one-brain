def install_module(name: str) -> dict:
    return {
        "ok": True,
        "installed": name,
        "status": "installed",
        "message": f"Module '{name}' installed successfully"
    }
