import os
import json
import shutil

MODULE_ROOT = "modules"
APP_ROOT = "apps"

def install_module(module_name, app_name):

    module_path = os.path.join(MODULE_ROOT, module_name)
    app_module_path = os.path.join(APP_ROOT, app_name, "modules", module_name)

    if not os.path.exists(module_path):
        return {"error": "module not found"}

    os.makedirs(os.path.dirname(app_module_path), exist_ok=True)

    if os.path.exists(app_module_path):
        return {"status": "already installed"}

    shutil.copytree(module_path, app_module_path)

    app_manifest = os.path.join(APP_ROOT, app_name, "app.json")

    if os.path.exists(app_manifest):
        with open(app_manifest) as f:
            data = json.load(f)

        if "modules" not in data:
            data["modules"] = []

        if module_name not in data["modules"]:
            data["modules"].append(module_name)

        with open(app_manifest, "w") as f:
            json.dump(data, f, indent=2)

    return {
        "status": "installed",
        "module": module_name,
        "app": app_name
    }
