from datetime import datetime
import json
from pathlib import Path

LOG_FILE = Path("warehouse/agent_logs.json")

def log_mission(data):
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    logs = []
    if LOG_FILE.exists():
        try:
            logs = json.loads(LOG_FILE.read_text())
        except:
            logs = []

    logs.append({
        "timestamp": datetime.utcnow().isoformat(),
        "data": data
    })

    LOG_FILE.write_text(json.dumps(logs, indent=2))
