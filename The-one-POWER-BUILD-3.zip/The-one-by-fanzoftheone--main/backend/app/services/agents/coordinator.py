def run_coordinator(plan: dict, execution: list):
    return {
        "agent": "coordinator",
        "status": "completed",
        "summary": "Plan executed successfully",
        "steps": plan.get("plan", []),
        "executed_tools": len(execution)
    }
