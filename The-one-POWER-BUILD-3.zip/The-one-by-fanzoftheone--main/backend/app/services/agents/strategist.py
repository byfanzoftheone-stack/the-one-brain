from datetime import datetime, timezone

def run_strategist(payload: dict):
    action = payload.get("action", "unknown")
    source = payload.get("source", "unknown")
    goal = payload.get("goal", "unspecified")

    if "email" in goal.lower() or "folder" in goal.lower() or "app" in goal.lower() or "deadline" in goal.lower():
        task_plan = {
            "emails": [
                "Delete spam and promotional emails older than 7 days",
                "Save or star important emails that need follow-up",
                "Reply to top 5 urgent emails",
                "Archive non-actionable threads"
            ],
            "files": [
                "Delete duplicate or unnecessary files",
                "Group files into clear folders",
                "Rename confusing file names"
            ],
            "apps": [
                "Review unused apps and remove what is not needed",
                "Update critical apps",
                "Clear notification backlog"
            ],
            "deadlines": [
                "List overdue tasks",
                "Prioritize the top 3 urgent items",
                "Create immediate next actions for each urgent item"
            ]
        }
    else:
        task_plan = {
            "tasks": [
                f"Clarify the goal: {goal}",
                "Break the goal into actionable steps",
                "Begin execution on the highest-value step"
            ]
        }

    return {
        "agent": "strategist",
        "input": {
            "action": action,
            "source": source,
            "goal": goal,
            "timestamp": datetime.now(timezone.utc).isoformat()
        },
        "plan": task_plan
    }
