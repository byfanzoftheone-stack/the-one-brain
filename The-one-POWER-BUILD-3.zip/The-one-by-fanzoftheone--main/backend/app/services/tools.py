import json
import os
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

BASE_DIR = Path.cwd()

def _resolve(path: str) -> Path:
    p = Path(path)
    return p if p.is_absolute() else BASE_DIR / p

def write_file(path: str, content: str):
    full_path = _resolve(path)
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content, encoding="utf-8")
    return {"tool": "write_file", "status": "written", "path": str(full_path)}

def read_file(path: str):
    full_path = _resolve(path)
    if not full_path.exists():
        return {"tool": "read_file", "status": "missing", "path": str(full_path)}
    return {"tool": "read_file", "status": "ok", "path": str(full_path), "content": full_path.read_text(encoding="utf-8")}

def call_api(url: str, method: str = "GET", payload=None):
    data = None
    headers = {"User-Agent": "THE-ONE/1.0"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = Request(url, data=data, method=method.upper(), headers=headers)
    with urlopen(req, timeout=15) as res:
        body = res.read().decode("utf-8", errors="replace")
        return {"tool": "call_api", "status": res.status, "url": url, "body_preview": body[:300]}

def store_memory(entry: dict):
    path = _resolve("warehouse/memory.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    data = []
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            data = []
    entry = dict(entry)
    entry["timestamp"] = datetime.now(timezone.utc).isoformat()
    data.append(entry)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return {"tool": "store_memory", "status": "stored", "path": str(path), "count": len(data)}
