import os
import json

MODULE_DIR = "modules"

def load_manifest(module):
    path = os.path.join(MODULE_DIR, module, "module.json")

    if not os.path.exists(path):
        return None

    with open(path) as f:
        return json.load(f)
