import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import json

from app.core.config import settings
from app.db.init_db import init_db
from app.services.logger import log_mission

# Routers
from app.api import agent_logs, agent_run, agent_test_log
from app.api.companion import router as companion_router
from app.api.routes.health import router as health_router
from app.api.routes.system import router as system_router
from app.api.routes.tenants import router as tenants_router
from app.api.routes.builds       import router as builds_router
from app.api.routes.deploy           import router as deploy_router
from app.api.routes.warehouse_proxy  import router as warehouse_proxy_router
from app.api.routes.payments         import router as payments_router
from app.api.routes.builder_369      import router as builder369_router
from app.api.routes.orchestrator import router as orchestrator_api_router
from app.api.legacy.marketplace_routes import router as marketplace_router
from app.api.legacy.cycle_routes import router as cycle_router
from app.routes.modules import router as modules_router
from app.routes.modules_install import router as modules_install_router
from app.routes.builder import router as builder_router
from app.routes.apps import router as apps_router
from app.routes.export import router as export_router
from app.routes.execute import router as execute_router

try:
    from app.routes.google_auth import router as google_auth_router
    from app.routes.gmail_actions import router as gmail_actions_router
    _google = True
except Exception:
    _google = False

app = FastAPI(
    title="THE ONE API",
    version="1.0.0",
    docs_url="/docs",
    openapi_url="/openapi.json",
)

# CORS — allow Vercel + Railway + local
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list + [
        "https://the-one-by-fanzoftheone.vercel.app",
        os.getenv("FRONTEND_URL", ""),
        "https://*.vercel.app",
        "http://localhost:3000",
        "http://localhost:3001",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers ONCE each
app.include_router(health_router)
app.include_router(tenants_router)
app.include_router(builds_router)
app.include_router(deploy_router)
app.include_router(warehouse_proxy_router)
app.include_router(payments_router)
app.include_router(builder369_router)
app.include_router(orchestrator_api_router)
app.include_router(system_router)
app.include_router(marketplace_router)
app.include_router(cycle_router)
app.include_router(modules_router)
app.include_router(modules_install_router)
app.include_router(companion_router)
app.include_router(builder_router)
app.include_router(apps_router)
app.include_router(export_router)
app.include_router(execute_router)
app.include_router(agent_logs.router, tags=["agents"])
app.include_router(agent_run.router, tags=["agents"])
app.include_router(agent_test_log.router, tags=["agents"])

if _google:
    app.include_router(google_auth_router)
    app.include_router(gmail_actions_router)

init_db()


@app.get("/")
def root() -> dict:
    return {"name": "THE ONE API", "status": "online", "version": "1.0.0"}


@app.get("/api/orchestrator/status")
def orchestrator_status():
    return {"status": "ready", "orchestrator": "THE ONE"}


@app.get("/api/agents/status")
def agents_status():
    return {"agents_online": 4, "status": "ok"}


@app.post("/api/execute")
def execute(payload: dict):
    action = payload.get("action", "unknown")
    source = payload.get("source", "unknown")
    result = {"action": action, "source": source, "status": "executed"}
    log_mission(result)
    return {"ok": True, "message": "Mission accepted", "result": result}


@app.get("/api/logs")
def get_logs():
    log_file = Path("warehouse/agent_logs.json")
    if not log_file.exists():
        return {"logs": []}
    try:
        return {"logs": json.loads(log_file.read_text())}
    except Exception:
        return {"logs": []}
