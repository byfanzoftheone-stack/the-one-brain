from fastapi import APIRouter
from app.services.export_generator import export_app

router = APIRouter(prefix="/api/export", tags=["export"])

@router.post("/app")
def export(name: str):
    return export_app(name)
