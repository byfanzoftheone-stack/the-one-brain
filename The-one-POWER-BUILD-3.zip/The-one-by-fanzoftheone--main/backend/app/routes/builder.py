from fastapi import APIRouter, Body
from app.services.module_installer import install_module

router = APIRouter(prefix="/api/builder", tags=["builder"])

@router.post("/install")
def builder_install(module: str = Body(...), app: str = Body(...)):
    return install_module(module, app)
