"""
Gmail Actions — read messages, labels, send replies.
Requires Google OAuth token stored at gmail_token.json (set via GMAIL_TOKEN_FILE env).
"""
from fastapi import APIRouter
from pathlib import Path
import json, os

router = APIRouter()

TOKEN_FILE = Path(os.getenv("GMAIL_TOKEN_FILE", "gmail_token.json"))

def _get_service():
    if not TOKEN_FILE.exists():
        return None
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    d = json.loads(TOKEN_FILE.read_text())
    creds = Credentials(
        token=d["token"],
        refresh_token=d.get("refresh_token"),
        token_uri=d["token_uri"],
        client_id=d["client_id"],
        client_secret=d["client_secret"],
        scopes=d["scopes"],
    )
    return build("gmail", "v1", credentials=creds)

@router.get("/api/gmail/status")
def gmail_status():
    return {"connected": TOKEN_FILE.exists(), "token_file": str(TOKEN_FILE)}

@router.get("/api/gmail/messages")
def messages(max_results: int = 10):
    service = _get_service()
    if not service:
        return {"status": "not_connected", "messages": []}
    res = service.users().messages().list(userId="me", maxResults=max_results).execute()
    return {"status": "ok", "messages": res.get("messages", []), "count": len(res.get("messages", []))}

@router.get("/api/gmail/messages/{message_id}")
def get_message(message_id: str):
    service = _get_service()
    if not service:
        return {"status": "not_connected"}
    msg = service.users().messages().get(userId="me", id=message_id, format="full").execute()
    headers = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
    return {
        "id":      msg["id"],
        "subject": headers.get("Subject", ""),
        "from":    headers.get("From", ""),
        "date":    headers.get("Date", ""),
        "snippet": msg.get("snippet", ""),
    }

@router.get("/api/gmail/labels")
def labels():
    service = _get_service()
    if not service:
        return {"status": "not_connected", "labels": []}
    res = service.users().labels().list(userId="me").execute()
    return {"status": "ok", "labels": res.get("labels", [])}

@router.get("/api/gmail/digest")
def digest(max_results: int = 10):
    """Quick digest — unread count + last N message subjects."""
    service = _get_service()
    if not service:
        return {"status": "not_connected"}
    unread = service.users().messages().list(userId="me", q="is:unread", maxResults=1).execute()
    recent = service.users().messages().list(userId="me", maxResults=max_results).execute()
    messages = []
    for m in recent.get("messages", [])[:5]:
        msg  = service.users().messages().get(userId="me", id=m["id"], format="metadata",
                                               metadataHeaders=["Subject","From"]).execute()
        hdrs = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
        messages.append({"id": m["id"], "subject": hdrs.get("Subject",""), "from": hdrs.get("From",""), "snippet": msg.get("snippet","")})
    return {
        "status": "ok",
        "unread_estimate": unread.get("resultSizeEstimate", 0),
        "recent": messages,
    }
