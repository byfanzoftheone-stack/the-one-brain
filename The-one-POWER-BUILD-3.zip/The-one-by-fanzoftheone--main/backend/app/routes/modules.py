from fastapi import APIRouter
from app.core.module_registry import list_modules

router = APIRouter(prefix="/api/modules", tags=["modules"])

@router.get("")
def get_modules():
    return {"modules": list_modules()}

@router.get("/catalog")
def get_modules_catalog():
    return {"modules": list_modules()}
