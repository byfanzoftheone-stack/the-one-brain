from fastapi import APIRouter
from app.services.module_installer import install_module

router = APIRouter(prefix="/api/modules", tags=["modules"])

@router.post("/install")
def install(module: str, app: str):
    return install_module(module, app)
