from fastapi import APIRouter, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from google_auth_oauthlib.flow import Flow
from pathlib import Path
import json
import os

router = APIRouter()

CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI")

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.modify",
]

STATE_FILE = Path("/app/google_oauth_state.json")
TOKEN_FILE = Path("/app/gmail_token.json")

def flow_factory(state: str | None = None, code_verifier: str | None = None):
    if not CLIENT_ID or not CLIENT_SECRET or not REDIRECT_URI:
        raise RuntimeError("Missing GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET / GOOGLE_REDIRECT_URI")

    flow = Flow.from_client_config(
        {
            "web": {
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
            }
        },
        scopes=SCOPES,
        state=state,
        redirect_uri=REDIRECT_URI,
    )

    if code_verifier:
        flow.code_verifier = code_verifier

    return flow

@router.get("/api/auth/google")
def auth_google():
    try:
        flow = flow_factory()
        auth_url, state = flow.authorization_url(
            access_type="offline",
            prompt="consent",
            include_granted_scopes="true",
        )

        STATE_FILE.write_text(json.dumps({
            "state": state,
            "code_verifier": flow.code_verifier,
        }))

        return RedirectResponse(auth_url)
    except Exception as e:
        return JSONResponse(status_code=500, content={"stage": "auth_google", "error": str(e)})

@router.get("/api/auth/google/callback")
def callback(code: str | None = None, state: str | None = None, error: str | None = None):
    try:
        if error:
            raise HTTPException(status_code=400, detail=f"Google returned error: {error}")
        if not code:
            raise HTTPException(status_code=400, detail="Missing authorization code")
        if not STATE_FILE.exists():
            raise RuntimeError("Missing saved OAuth state")

        saved = json.loads(STATE_FILE.read_text())
        saved_state = saved.get("state")
        code_verifier = saved.get("code_verifier")

        if state != saved_state:
            raise RuntimeError("OAuth state mismatch")

        flow = flow_factory(state=saved_state, code_verifier=code_verifier)
        flow.fetch_token(code=code)
        creds = flow.credentials

        data = {
            "token": creds.token,
            "refresh_token": creds.refresh_token,
            "token_uri": creds.token_uri,
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "scopes": list(creds.scopes or []),
        }

        TOKEN_FILE.write_text(json.dumps(data, indent=2))
        return {"status": "connected"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"stage": "google_callback", "error": str(e)})
