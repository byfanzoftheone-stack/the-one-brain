from fastapi import APIRouter
from app.services.app_generator import generate_app

router = APIRouter(prefix="/api/apps", tags=["apps"])

@router.post("/create")
def create_app(name: str):
    return generate_app(name)

@router.get("/list")
def list_apps():
    return {
        "apps": [
            {
                "id": "the-one-core",
                "name": "The One Core",
                "status": "ready",
                "type": "system"
            }
        ]
    }
