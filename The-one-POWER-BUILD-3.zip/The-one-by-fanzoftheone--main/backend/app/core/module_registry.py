from pathlib import Path
import json

def list_modules():
    candidates = [Path("backend/modules"), Path("modules"), Path("/app/modules")]
    manifests = []
    seen_ids = set()
    modules = []

    for root in candidates:
        if root.exists():
            for manifest in root.glob("*/module.json"):
                manifests.append(manifest)

    for manifest in manifests:
        try:
            data = json.loads(manifest.read_text())
            module_id = data.get("id") or manifest.parent.name
            if module_id in seen_ids:
                continue
            seen_ids.add(module_id)
            data.setdefault("slug", manifest.parent.name)
            data.setdefault("status", "installed")
            data.setdefault("enabled", True)
            modules.append(data)
        except Exception:
            continue

    return modules
