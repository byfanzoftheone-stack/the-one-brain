from app.db.session import engine, Base
from app.models.agent_log import AgentLog

def init_db():
    Base.metadata.create_all(bind=engine)
