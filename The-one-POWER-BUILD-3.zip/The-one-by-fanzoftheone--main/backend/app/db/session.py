"""
Database session — safe fallback when DATABASE_URL is not set.
Railway sets DATABASE_URL automatically when you attach a Postgres plugin.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
import os

DATABASE_URL = os.getenv("DATABASE_URL", "")

# Railway uses postgres:// but SQLAlchemy needs postgresql://
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

# Graceful fallback to SQLite so the app starts even without Postgres
if not DATABASE_URL:
    import pathlib
    pathlib.Path("warehouse").mkdir(exist_ok=True)
    DATABASE_URL = "sqlite:///./warehouse/the_one.db"

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
