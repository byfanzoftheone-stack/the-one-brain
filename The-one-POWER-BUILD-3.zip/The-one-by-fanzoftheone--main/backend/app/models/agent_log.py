from sqlalchemy import Column, Integer, String, DateTime, JSON
from datetime import datetime
from app.db.session import Base

class AgentLog(Base):
    __tablename__ = "agent_logs"

    id = Column(Integer, primary_key=True, index=True)
    agent_name = Column(String, index=True)
    event = Column(String)
    payload = Column(JSON)
    status = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)
