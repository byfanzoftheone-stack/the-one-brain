from datetime import datetime
from app.db.session import SessionLocal
from app.models.agent_log import AgentLog

def log_agent_run(agent_name, payload, status="success"):
    db = SessionLocal()
    log = AgentLog(
        agent_name=agent_name,
        event="execution",
        payload=payload,
        status=status,
        timestamp=datetime.utcnow()
    )
    db.add(log)
    db.commit()
    db.close()
