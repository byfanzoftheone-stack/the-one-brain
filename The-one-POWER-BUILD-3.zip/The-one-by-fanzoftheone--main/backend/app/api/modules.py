from fastapi import APIRouter
from app.core.module_registry import list_modules

router = APIRouter()

@router.get("/modules")
def get_modules():
    return {"modules": list_modules()}
