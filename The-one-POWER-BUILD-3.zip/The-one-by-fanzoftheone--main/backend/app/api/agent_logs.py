from fastapi import APIRouter
from app.db.session import SessionLocal
from app.models.agent_log import AgentLog

router = APIRouter()

@router.get("/api/agents/logs")
def list_agent_logs():
    db = SessionLocal()
    try:
        logs = db.query(AgentLog).order_by(AgentLog.timestamp.desc()).limit(50).all()
        return {"logs": [
            {
                "id": log.id,
                "agent": log.agent_name,
                "event": log.event,
                "status": log.status,
                "payload": log.payload,
                "timestamp": log.timestamp.isoformat() if log.timestamp else None,
            }
            for log in logs
        ]}
    finally:
        db.close()
