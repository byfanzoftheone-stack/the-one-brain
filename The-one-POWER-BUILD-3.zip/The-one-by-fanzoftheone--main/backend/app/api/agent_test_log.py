from fastapi import APIRouter
from pathlib import Path
import json
from datetime import datetime

router = APIRouter()

LOG_DIR = Path("warehouse/runtime")

@router.post("/api/agents/test-log")
def create_test_log():
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    log = {
        "timestamp": datetime.utcnow().isoformat(),
        "event": "test_log",
        "data": {
            "status": "created_from_api"
        }
    }

    file_path = LOG_DIR / f"{datetime.utcnow().timestamp()}.json"
    file_path.write_text(json.dumps(log))

    return {"status": "log_created", "file": str(file_path)}
