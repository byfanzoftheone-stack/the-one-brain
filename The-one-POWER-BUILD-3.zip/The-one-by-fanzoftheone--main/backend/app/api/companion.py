"""Companion API — exposes the companion engine over HTTP."""
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.companion_service import get_companion_state

router = APIRouter(prefix="/api/companion", tags=["companion"])

class ReflectionBody(BaseModel):
    text: str

class MemoryBody(BaseModel):
    key: str
    value: str

@router.get("")
def companion_root():
    return get_companion_state()

@router.get("/state")
def companion_state():
    return get_companion_state()

@router.get("/direction")
def daily_direction():
    try:
        import sys, os
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../.."))
        from companion.companion_engine import get_daily_direction
        return get_daily_direction()
    except Exception as e:
        return {"status": "error", "error": str(e)}

@router.post("/reflect")
def add_reflection(body: ReflectionBody):
    try:
        import sys, os
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../.."))
        from companion.companion_engine import record_reflection
        return record_reflection(body.text)
    except Exception as e:
        return {"status": "error", "error": str(e)}

@router.post("/memory")
def save_memory(body: MemoryBody):
    try:
        import sys, os
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../.."))
        from companion.companion_engine import save_memory as _save
        return _save(body.key, body.value)
    except Exception as e:
        return {"status": "error", "error": str(e)}
