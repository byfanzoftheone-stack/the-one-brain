"""
Deploy API — triggers real Vercel and Railway deployments via their APIs.
Vercel: uses VERCEL_TOKEN env var
Railway: uses RAILWAY_TOKEN env var
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import os, json, urllib.request, urllib.error
from datetime import datetime, timezone

router = APIRouter(prefix="/api/deploy", tags=["deploy"])

def _now(): return datetime.now(timezone.utc).isoformat()

def _http(url: str, method: str = "GET", body: dict = None, headers: dict = {}) -> dict:
    data = json.dumps(body).encode() if body else None
    req  = urllib.request.Request(url, data=data, method=method, headers={
        "Content-Type": "application/json", **headers
    })
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise HTTPException(status_code=e.code, detail=e.read().decode()[:400])
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))


# ── Vercel ────────────────────────────────────────────────────────────────

class VercelDeployRequest(BaseModel):
    project_name: str          # exact Vercel project name or ID
    git_branch:   Optional[str] = "main"

@router.post("/vercel")
def trigger_vercel_deploy(req: VercelDeployRequest):
    token = os.getenv("VERCEL_TOKEN", "")
    if not token:
        raise HTTPException(status_code=400, detail="VERCEL_TOKEN not set on Railway env vars")

    # Get project ID from name
    projects = _http(
        "https://api.vercel.com/v9/projects",
        headers={"Authorization": f"Bearer {token}"}
    )
    project = next(
        (p for p in projects.get("projects", []) if p["name"] == req.project_name),
        None
    )
    if not project:
        raise HTTPException(status_code=404, detail=f"Vercel project '{req.project_name}' not found")

    # Trigger redeploy via deployments API
    result = _http(
        "https://api.vercel.com/v13/deployments",
        method="POST",
        body={"name": req.project_name, "gitSource": {"type": "github", "ref": req.git_branch}},
        headers={"Authorization": f"Bearer {token}"}
    )

    return {
        "status":       "triggered",
        "provider":     "vercel",
        "project":      req.project_name,
        "deploy_id":    result.get("id"),
        "url":          result.get("url"),
        "state":        result.get("readyState", "BUILDING"),
        "triggered_at": _now(),
    }

@router.get("/vercel/status/{deploy_id}")
def vercel_deploy_status(deploy_id: str):
    token = os.getenv("VERCEL_TOKEN", "")
    if not token:
        raise HTTPException(status_code=400, detail="VERCEL_TOKEN not set")
    result = _http(
        f"https://api.vercel.com/v13/deployments/{deploy_id}",
        headers={"Authorization": f"Bearer {token}"}
    )
    return {
        "deploy_id": deploy_id,
        "state":     result.get("readyState"),
        "url":       result.get("url"),
        "created":   result.get("createdAt"),
    }

@router.get("/vercel/projects")
def list_vercel_projects():
    token = os.getenv("VERCEL_TOKEN", "")
    if not token:
        return {"error": "VERCEL_TOKEN not set", "projects": []}
    result = _http("https://api.vercel.com/v9/projects", headers={"Authorization": f"Bearer {token}"})
    return {
        "projects": [
            {"id": p["id"], "name": p["name"], "url": f"https://{p.get('alias', [p['name']])[0]}" if p.get("alias") else None}
            for p in result.get("projects", [])
        ]
    }

@router.get("/vercel/latest/{project_name}")
def vercel_latest_deploy(project_name: str):
    token = os.getenv("VERCEL_TOKEN", "")
    if not token:
        return {"error": "VERCEL_TOKEN not set"}
    result = _http(
        f"https://api.vercel.com/v6/deployments?projectId={project_name}&limit=1",
        headers={"Authorization": f"Bearer {token}"}
    )
    deploys = result.get("deployments", [])
    if not deploys:
        return {"error": "no deployments found"}
    d = deploys[0]
    return {
        "project":    project_name,
        "deploy_id":  d.get("uid"),
        "url":        f"https://{d.get('url')}",
        "state":      d.get("state"),
        "created_at": d.get("created"),
    }


# ── Railway ───────────────────────────────────────────────────────────────

RAILWAY_GQL = "https://backboard.railway.app/graphql/v2"

def _railway(query: str, variables: dict = {}) -> dict:
    token = os.getenv("RAILWAY_TOKEN", "")
    if not token:
        raise HTTPException(status_code=400, detail="RAILWAY_TOKEN not set on Railway env vars")
    return _http(
        RAILWAY_GQL,
        method="POST",
        body={"query": query, "variables": variables},
        headers={"Authorization": f"Bearer {token}"}
    )

class RailwayDeployRequest(BaseModel):
    service_id: str   # Railway service ID
    environment_id: Optional[str] = None

@router.post("/railway")
def trigger_railway_deploy(req: RailwayDeployRequest):
    result = _railway(
        """
        mutation serviceInstanceRedeploy($serviceId: String!, $environmentId: String) {
          serviceInstanceRedeploy(serviceId: $serviceId, environmentId: $environmentId)
        }
        """,
        {"serviceId": req.service_id, "environmentId": req.environment_id}
    )
    if "errors" in result:
        raise HTTPException(status_code=400, detail=str(result["errors"]))
    return {
        "status":       "triggered",
        "provider":     "railway",
        "service_id":   req.service_id,
        "triggered_at": _now(),
    }

@router.get("/railway/projects")
def list_railway_projects():
    result = _railway("{ me { projects { edges { node { id name services { edges { node { id name } } } } } } } }")
    if "errors" in result:
        return {"error": str(result["errors"]), "projects": []}
    projects = []
    for edge in result.get("data", {}).get("me", {}).get("projects", {}).get("edges", []):
        p = edge["node"]
        projects.append({
            "id":       p["id"],
            "name":     p["name"],
            "services": [s["node"] for s in p.get("services", {}).get("edges", [])],
        })
    return {"projects": projects}

@router.get("/railway/deployments/{service_id}")
def railway_deploy_status(service_id: str):
    result = _railway(
        """
        query($serviceId: String!) {
          deployments(serviceId: $serviceId, first: 3) {
            edges { node { id status createdAt url } }
          }
        }
        """,
        {"serviceId": service_id}
    )
    deploys = [e["node"] for e in result.get("data", {}).get("deployments", {}).get("edges", [])]
    return {"service_id": service_id, "deployments": deploys}
