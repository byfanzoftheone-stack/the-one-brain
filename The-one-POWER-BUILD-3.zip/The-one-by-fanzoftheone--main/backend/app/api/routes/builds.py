"""
Builds routes — create and list build records.
Supports the Warehouse Build Intake + Records cards.
"""
from fastapi import APIRouter
from pydantic import BaseModel
from datetime import datetime, timezone
from typing import Optional
import json
from pathlib import Path

router   = APIRouter(prefix="/api/builds", tags=["builds"])
DATA_DIR = Path("warehouse/builds_db")
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_FILE  = DATA_DIR / "builds.json"

def _now(): return datetime.now(timezone.utc).isoformat()

def _read() -> list:
    return json.loads(DB_FILE.read_text()) if DB_FILE.exists() else []

def _write(data: list):
    DB_FILE.write_text(json.dumps(data, indent=2))

class BuildCreate(BaseModel):
    tenant_id: str
    status: Optional[str] = "pending"
    service: Optional[str] = None

@router.get("")
def list_builds():
    return _read()

@router.post("")
def create_build(body: BuildCreate):
    builds  = _read()
    service = body.service or f"build-{len(builds)+1}"
    build   = {
        "id":         len(builds) + 1,
        "tenant_id":  body.tenant_id,
        "service":    service,
        "status":     body.status or "pending",
        "created_at": _now(),
    }
    builds.append(build)
    _write(builds)
    return build

@router.get("/{build_id}")
def get_build(build_id: int):
    for b in _read():
        if b["id"] == build_id:
            return b
    return {"error": "not found"}

@router.patch("/{build_id}/status")
def update_status(build_id: int, status: str):
    builds = _read()
    for b in builds:
        if b["id"] == build_id:
            b["status"] = status
            b["updated_at"] = _now()
            _write(builds)
            return b
    return {"error": "not found"}
