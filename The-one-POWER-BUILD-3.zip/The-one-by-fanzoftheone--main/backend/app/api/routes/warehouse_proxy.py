"""
Warehouse Proxy — proxies requests to FanzSpot so frontend avoids CORS.
Set WAREHOUSE_URL env var on Railway to point to fanzspot-production.up.railway.app
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import os, json, urllib.request, urllib.error
from datetime import datetime, timezone

router = APIRouter(prefix="/api/warehouse", tags=["warehouse"])

WAREHOUSE_URL = os.getenv("WAREHOUSE_URL", "https://fanzspot-production.up.railway.app")

def _now(): return datetime.now(timezone.utc).isoformat()

def _fanzspot(path: str, method: str = "GET", body: dict = None) -> dict:
    url  = f"{WAREHOUSE_URL.rstrip('/')}{path}"
    data = json.dumps(body).encode() if body else None
    req  = urllib.request.Request(url, data=data, method=method,
                                   headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise HTTPException(status_code=e.code, detail=e.read().decode()[:300])
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"FanzSpot unreachable: {str(e)}")

# ── Health / Status ───────────────────────────────────────────────────────
@router.get("/health")
def warehouse_health():
    try:
        data = _fanzspot("/api/health")
        return {"status": "connected", "fanzspot": data, "proxy": "the-one-backend"}
    except HTTPException as e:
        return {"status": "error", "detail": e.detail}

# ── Tenants ───────────────────────────────────────────────────────────────
@router.get("/tenants")
def list_tenants():
    return _fanzspot("/api/tenants")

class TenantCreate(BaseModel):
    business_name: str
    slug: str

@router.post("/tenants")
def create_tenant(body: TenantCreate):
    return _fanzspot("/api/tenants", method="POST", body=body.model_dump())

@router.delete("/tenants/{slug}")
def delete_tenant(slug: str):
    return _fanzspot(f"/api/tenants/{slug}", method="DELETE")

# ── Builds ────────────────────────────────────────────────────────────────
@router.get("/builds")
def list_builds():
    return _fanzspot("/api/builds")

class BuildCreate(BaseModel):
    tenant_id:  str
    status:     Optional[str] = "pending"
    service:    Optional[str] = None

@router.post("/builds")
def create_build(body: BuildCreate):
    return _fanzspot("/api/builds", method="POST", body=body.model_dump())

@router.patch("/builds/{build_id}/status")
def update_build_status(build_id: str, status: str):
    return _fanzspot(f"/api/builds/{build_id}/status", method="PATCH", body={"status": status})

# ── Ecosystem snapshot ────────────────────────────────────────────────────
@router.get("/snapshot")
def warehouse_snapshot():
    """Pull the full warehouse state in one call."""
    result = {"timestamp": _now(), "source": WAREHOUSE_URL}
    try:
        result["health"]  = _fanzspot("/api/health")
    except Exception as e:
        result["health"]  = {"error": str(e)}
    try:
        result["tenants"] = _fanzspot("/api/tenants")
    except Exception as e:
        result["tenants"] = {"error": str(e)}
    try:
        result["builds"]  = _fanzspot("/api/builds")
    except Exception as e:
        result["builds"]  = {"error": str(e)}
    return result
