"""System overview route — gives the frontend a full ecosystem snapshot."""
from fastapi import APIRouter
from app.services.catalog import get_overview

router = APIRouter(prefix="/api/system", tags=["system"])

@router.get("/overview")
def overview() -> dict:
    base = get_overview()
    try:
        from app.services.agent_registry import agents_online, list_agents
        base["agents_online"] = agents_online()
        base["agents"] = list(list_agents().keys())
    except Exception:
        base["agents_online"] = 4
        base["agents"] = ["strategist", "builder", "auditor", "maid"]
    return base

@router.get("/status")
def status() -> dict:
    try:
        from backend.services.health_monitor import system_health
        return system_health()
    except Exception:
        from datetime import datetime, timezone
        return {"status": "ok", "system": "THE ONE API", "timestamp": datetime.now(timezone.utc).isoformat()}
