from fastapi import APIRouter

router = APIRouter(prefix="/api", tags=["health"])

@router.get("/health")
def health() -> dict:
    return {"status": "ok", "system": "THE ONE API"}
