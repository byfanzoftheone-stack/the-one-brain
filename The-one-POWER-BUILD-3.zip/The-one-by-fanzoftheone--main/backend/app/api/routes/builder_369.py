"""
3-6-9 Builder — Teacher agent presents 3 block choices.
User picks one. Code stored and recycled. Progressive skill building.
No API key = smart rule-based blocks. API key = real AI-generated options.
"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
import os, json, urllib.request
from datetime import datetime, timezone
from pathlib import Path

router    = APIRouter(prefix="/api/builder369", tags=["builder369"])
CODE_BANK = Path("warehouse/code_bank")
CODE_BANK.mkdir(parents=True, exist_ok=True)

def _now(): return datetime.now(timezone.utc).isoformat()

# ── Block templates ────────────────────────────────────────────────────────
BLOCK_TEMPLATES = {
    "api_endpoint": [
        {"level": 3, "label": "Simple GET", "desc": "Basic read endpoint", "code": "from fastapi import APIRouter\nrouter = APIRouter()\n\n@router.get('/{resource}')\ndef get_resource(resource: str):\n    return {'resource': resource, 'status': 'ok'}"},
        {"level": 6, "label": "CRUD Route", "desc": "Create, read, update, delete", "code": "from fastapi import APIRouter, HTTPException\nfrom pydantic import BaseModel\nrouter = APIRouter()\nitems = {}\n\nclass Item(BaseModel):\n    name: str\n    value: str\n\n@router.get('/')\ndef list_items(): return list(items.values())\n\n@router.post('/')\ndef create_item(item: Item):\n    items[item.name] = item.dict()\n    return item\n\n@router.delete('/{name}')\ndef delete_item(name: str):\n    items.pop(name, None)\n    return {'deleted': name}"},
        {"level": 9, "label": "Full Service", "desc": "Auth + validation + DB", "code": "from fastapi import APIRouter, HTTPException, Depends\nfrom pydantic import BaseModel, Field\nfrom typing import Optional\nfrom datetime import datetime, timezone\n\nrouter = APIRouter(prefix='/api', tags=['service'])\n\nclass CreateRequest(BaseModel):\n    name: str = Field(..., min_length=2)\n    data: dict = {}\n\nclass ServiceResponse(BaseModel):\n    id: str\n    name: str\n    created_at: str\n    status: str = 'active'\n\n@router.post('/create', response_model=ServiceResponse)\ndef create(req: CreateRequest) -> ServiceResponse:\n    return ServiceResponse(\n        id=f'id_{req.name}',\n        name=req.name,\n        created_at=datetime.now(timezone.utc).isoformat()\n    )"},
    ],
    "data_model": [
        {"level": 3, "label": "Basic Model", "desc": "Simple Pydantic model", "code": "from pydantic import BaseModel\nfrom typing import Optional\n\nclass Item(BaseModel):\n    id: str\n    name: str\n    description: Optional[str] = None"},
        {"level": 6, "label": "Validated Model", "desc": "With field constraints", "code": "from pydantic import BaseModel, Field\nfrom typing import Optional\nfrom datetime import datetime\n\nclass Product(BaseModel):\n    id: str = Field(..., min_length=3)\n    name: str = Field(..., min_length=2, max_length=100)\n    price: float = Field(..., gt=0)\n    category: str\n    active: bool = True\n    created_at: datetime = Field(default_factory=datetime.utcnow)"},
        {"level": 9, "label": "Full Entity", "desc": "With relationships + methods", "code": "from pydantic import BaseModel, Field, validator\nfrom typing import Optional, List\nfrom datetime import datetime, timezone\nimport uuid\n\nclass Address(BaseModel):\n    street: str\n    city: str\n    state: str\n    zip_code: str = Field(..., regex=r'^\\d{5}$')\n\nclass Customer(BaseModel):\n    id: str = Field(default_factory=lambda: str(uuid.uuid4()))\n    name: str = Field(..., min_length=2)\n    email: str = Field(..., regex=r'^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$')\n    phone: Optional[str] = None\n    address: Optional[Address] = None\n    tags: List[str] = []\n    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())\n\n    @validator('name')\n    def name_must_have_space(cls, v):\n        if ' ' not in v:\n            raise ValueError('Full name required')\n        return v.title()"},
    ],
    "agent": [
        {"level": 3, "label": "Simple Agent", "desc": "Basic task executor", "code": "def run_agent(task: str) -> dict:\n    return {\n        'task': task,\n        'status': 'completed',\n        'result': f'Processed: {task}'\n    }"},
        {"level": 6, "label": "Tool Agent", "desc": "Agent with tool selection", "code": "def choose_tool(task: str) -> str:\n    t = task.lower()\n    if any(w in t for w in ['file', 'read', 'write']): return 'filesystem'\n    if any(w in t for w in ['api', 'fetch', 'call']): return 'api'\n    if any(w in t for w in ['analyze', 'score', 'rank']): return 'analyzer'\n    return 'shell'\n\ndef run_agent(task: str, payload: dict = {}) -> dict:\n    tool   = choose_tool(task)\n    result = f'[{tool.upper()}] executed: {task}'\n    return {'task': task, 'tool': tool, 'result': result, 'status': 'ok'}"},
        {"level": 9, "label": "Teacher/Student", "desc": "Full crew loop", "code": "from datetime import datetime, timezone\n\ndef _now(): return datetime.now(timezone.utc).isoformat()\n\ndef teacher_plan(goal: str) -> list:\n    # Teacher generates steps\n    return [\n        {'step': 1, 'task': f'Analyze: {goal}', 'agent': 'strategist'},\n        {'step': 2, 'task': f'Execute: {goal}', 'agent': 'worker'},\n        {'step': 3, 'task': f'Verify: {goal}',  'agent': 'auditor'},\n    ]\n\ndef student_execute(steps: list) -> list:\n    # Student runs each step\n    return [{'step': s['step'], 'agent': s['agent'],\n             'output': f'Completed: {s[\"task\"]}', 'ts': _now()} for s in steps]\n\ndef skip_evaluate(results: list) -> dict:\n    passed = all('Completed' in r['output'] for r in results)\n    return {'passed': passed, 'score': 90 if passed else 40, 'tasks': len(results)}\n\ndef run_crew(goal: str) -> dict:\n    steps   = teacher_plan(goal)\n    results = student_execute(steps)\n    eval_   = skip_evaluate(results)\n    return {'goal': goal, 'steps': steps, 'results': results, 'evaluation': eval_}"},
    ],
}

def _get_ai_blocks(goal: str, category: str) -> list:
    """Get real AI-generated blocks from Claude/DeepSeek."""
    key = os.getenv("ANTHROPIC_API_KEY", "")
    if not key:
        return None
    prompt = f"""You are a coding teacher. The user wants to build: "{goal}"
Category: {category}

Generate exactly 3 code block options in JSON. Each option should be a different approach:
- Option 1 (level 3): Simplest possible solution, beginner-friendly
- Option 2 (level 6): Intermediate with proper structure  
- Option 3 (level 9): Production-ready with full patterns

Return ONLY valid JSON array:
[
  {{"level": 3, "label": "Simple Name", "desc": "One line description", "code": "# python code here"}},
  {{"level": 6, "label": "Better Name", "desc": "One line description", "code": "# python code here"}},
  {{"level": 9, "label": "Pro Name", "desc": "One line description", "code": "# python code here"}}
]"""
    try:
        body = json.dumps({"model": "claude-sonnet-4-20250514", "max_tokens": 2048,
                           "messages": [{"role": "user", "content": prompt}]}).encode()
        req  = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body,
                                       headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                                "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=25) as r:
            data = json.loads(r.read())
            text = data["content"][0]["text"]
            # Parse JSON from response
            start = text.find("[")
            end   = text.rfind("]") + 1
            return json.loads(text[start:end])
    except Exception:
        return None

class BlockRequest(BaseModel):
    goal:     str
    category: str = "api_endpoint"
    session_id: Optional[str] = None

class BlockChoice(BaseModel):
    session_id: str
    goal:       str
    chosen_level: int
    chosen_code:  str
    category:   str

@router.post("/blocks")
def get_blocks(req: BlockRequest):
    """Teacher presents 3 block choices for the user's goal."""
    # Try AI first
    ai_blocks = _get_ai_blocks(req.goal, req.category)
    blocks    = ai_blocks or BLOCK_TEMPLATES.get(req.category, BLOCK_TEMPLATES["api_endpoint"])
    provider  = "claude" if ai_blocks else "templates"

    return {
        "goal":      req.goal,
        "category":  req.category,
        "blocks":    blocks,
        "provider":  provider,
        "instruction": "Pick the block that matches your current skill level. Each choice is stored and helps the system learn what patterns you prefer.",
    }

@router.post("/choose")
def save_choice(choice: BlockChoice):
    """Save user's block choice to the code bank."""
    entry = {
        "session_id":   choice.session_id,
        "goal":         choice.goal,
        "category":     choice.category,
        "chosen_level": choice.chosen_level,
        "code":         choice.chosen_code,
        "saved_at":     _now(),
    }
    # Save to code bank
    fname = CODE_BANK / f"{choice.session_id}_{choice.category}.json"
    fname.write_text(json.dumps(entry, indent=2))

    return {"status": "saved", "session_id": choice.session_id,
            "message": f"Level {choice.chosen_level} block saved to your code bank"}

@router.get("/bank/{session_id}")
def get_code_bank(session_id: str):
    """Return all saved code blocks for a session."""
    files = sorted(CODE_BANK.glob(f"{session_id}_*.json"))
    blocks = [json.loads(f.read_text()) for f in files]
    return {"session_id": session_id, "blocks": blocks, "count": len(blocks)}

@router.get("/bank")
def get_all_bank():
    """Return aggregated code bank — recycled patterns across all sessions."""
    files = sorted(CODE_BANK.glob("*.json"))
    bank  = [json.loads(f.read_text()) for f in files]
    # Aggregate by category
    by_cat: dict = {}
    for b in bank:
        cat = b.get("category", "general")
        if cat not in by_cat:
            by_cat[cat] = {"category": cat, "count": 0, "levels": []}
        by_cat[cat]["count"] += 1
        by_cat[cat]["levels"].append(b.get("chosen_level", 0))
    return {"total_choices": len(bank), "by_category": list(by_cat.values()), "bank": bank[-20:]}
