"""
Tenant routes — CRUD for Warehouse tenants.
Supports the Warehouse frontend card system.
"""
from fastapi import APIRouter
from pydantic import BaseModel
from datetime import datetime, timezone
import json
from pathlib import Path

router   = APIRouter(prefix="/api/tenants", tags=["tenants"])
DATA_DIR = Path("warehouse/tenants")
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_FILE  = DATA_DIR / "tenants.json"

def _now(): return datetime.now(timezone.utc).isoformat()

def _read() -> list:
    return json.loads(DB_FILE.read_text()) if DB_FILE.exists() else []

def _write(data: list):
    DB_FILE.write_text(json.dumps(data, indent=2))

class TenantCreate(BaseModel):
    business_name: str
    slug: str

@router.get("")
def list_tenants():
    return _read()

@router.post("")
def create_tenant(body: TenantCreate):
    tenants = _read()
    if any(t["slug"] == body.slug for t in tenants):
        return {"status": "exists", "slug": body.slug}
    tenant = {"id": len(tenants) + 1, "business_name": body.business_name, "slug": body.slug, "created_at": _now()}
    tenants.append(tenant)
    _write(tenants)
    return tenant

@router.get("/{slug}")
def get_tenant(slug: str):
    for t in _read():
        if t["slug"] == slug:
            return t
    return {"error": "not found"}

@router.delete("/{slug}")
def delete_tenant(slug: str):
    tenants = [t for t in _read() if t["slug"] != slug]
    _write(tenants)
    return {"status": "deleted", "slug": slug}
