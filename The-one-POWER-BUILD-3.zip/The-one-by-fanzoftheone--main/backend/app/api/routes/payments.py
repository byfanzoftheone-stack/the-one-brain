"""
Payments — Stripe checkout, webhooks, subscription management.
Set STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET on Railway.
"""
from fastapi import APIRouter, HTTPException, Request, Header
from pydantic import BaseModel
from typing import Optional
import os, json, urllib.request, urllib.error
from datetime import datetime, timezone
from pathlib import Path

router = APIRouter(prefix="/api/payments", tags=["payments"])

STRIPE_KEY     = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK = os.getenv("STRIPE_WEBHOOK_SECRET", "")
STRIPE_BASE    = "https://api.stripe.com/v1"

# Product → Stripe Price ID mapping (set these after creating products in Stripe)
PRICE_IDS = {
    "nervous-system":        os.getenv("STRIPE_PRICE_NERVOUS_SYSTEM",    ""),
    "fanzo-core":            os.getenv("STRIPE_PRICE_FANZO_CORE",         ""),
    "content-engine":        os.getenv("STRIPE_PRICE_CONTENT_ENGINE",     ""),
    "content-machine":       os.getenv("STRIPE_PRICE_CONTENT_MACHINE",    ""),
    "email-growth-engine":   os.getenv("STRIPE_PRICE_EMAIL_GROWTH",       ""),
    "little-pro":            os.getenv("STRIPE_PRICE_LITTLE_PRO",         ""),
    "marketing-automation":  os.getenv("STRIPE_PRICE_MARKETING_AUTO",     ""),
    "productivity-tracker":  os.getenv("STRIPE_PRICE_PRODUCTIVITY",       ""),
    "seo-automation-app":    os.getenv("STRIPE_PRICE_SEO",                ""),
    "three-six-nine-builder":os.getenv("STRIPE_PRICE_369_BUILDER",        ""),
    "construction-ops":      os.getenv("STRIPE_PRICE_CONSTRUCTION_OPS",   ""),
    "play-better":           os.getenv("STRIPE_PRICE_PLAY_BETTER",        ""),
}

# In-memory subscription store (replace with DB in production)
SUBSCRIPTIONS: dict = {}

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()

def _stripe(path: str, method: str = "GET", body: dict = None) -> dict:
    if not STRIPE_KEY:
        raise HTTPException(400, "STRIPE_SECRET_KEY not set on Railway")
    import base64
    token = base64.b64encode(f"{STRIPE_KEY}:".encode()).decode()
    data  = "&".join(f"{k}={v}" for k, v in (body or {}).items()).encode() if body else None
    req   = urllib.request.Request(
        f"{STRIPE_BASE}{path}", data=data, method=method,
        headers={"Authorization": f"Basic {token}", "Content-Type": "application/x-www-form-urlencoded"}
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise HTTPException(e.code, json.loads(e.read()).get("error", {}).get("message", "Stripe error"))

class CheckoutRequest(BaseModel):
    product_slug:  str
    customer_email: Optional[str] = None
    success_url:   str = os.getenv("FRONTEND_URL", "https://yourdomain.vercel.app") + "/market/success"
    cancel_url:    str = os.getenv("FRONTEND_URL", "https://yourdomain.vercel.app") + "/market"

@router.post("/checkout")
def create_checkout(req: CheckoutRequest):
    price_id = PRICE_IDS.get(req.product_slug)
    if not price_id:
        # Simulation mode — no Stripe keys yet
        return {
            "status": "simulation",
            "message": "Stripe not configured. Set STRIPE_SECRET_KEY and price env vars on Railway.",
            "product": req.product_slug,
            "checkout_url": f"/market/success?product={req.product_slug}&sim=true"
        }
    session = _stripe("/checkout/sessions", "POST", {
        "mode": "subscription",
        "line_items[0][price]": price_id,
        "line_items[0][quantity]": "1",
        "success_url": req.success_url + f"?session_id={{CHECKOUT_SESSION_ID}}",
        "cancel_url": req.cancel_url,
        **({"customer_email": req.customer_email} if req.customer_email else {}),
    })
    return {"checkout_url": session["url"], "session_id": session["id"]}

@router.post("/webhook")
async def stripe_webhook(request: Request, stripe_signature: str = Header(None)):
    body = await request.body()
    # Verify webhook signature
    if STRIPE_WEBHOOK and stripe_signature:
        try:
            import hmac, hashlib
            timestamp = stripe_signature.split(",")[0].split("=")[1]
            sig       = stripe_signature.split("v1=")[1].split(",")[0]
            payload   = f"{timestamp}.{body.decode()}"
            expected  = hmac.new(STRIPE_WEBHOOK.encode(), payload.encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expected, sig):
                raise HTTPException(400, "Invalid signature")
        except Exception:
            pass  # In dev, skip verification

    event = json.loads(body)
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        customer_email = session.get("customer_email") or session.get("customer_details", {}).get("email", "")
        metadata       = session.get("metadata", {})
        product        = metadata.get("product", "unknown")
        SUBSCRIPTIONS[customer_email] = {
            "active": True, "product": product,
            "session_id": session["id"], "activated_at": _now()
        }
    return {"received": True}

@router.get("/subscription/{email}")
def check_subscription(email: str):
    sub = SUBSCRIPTIONS.get(email)
    if sub and sub.get("active"):
        return {"active": True, "products": [sub.get("product")], "email": email}
    return {"active": False, "products": [], "email": email}

@router.get("/products")
def list_products():
    """Return all products with their lock status."""
    listings_dir = Path(__file__).resolve().parents[4] / "marketplace" / "listings"
    products = []
    if listings_dir.exists():
        for f in sorted(listings_dir.glob("*.json")):
            try:
                data = json.loads(f.read_text())
                data["has_stripe_price"] = bool(PRICE_IDS.get(data.get("slug", "")))
                products.append(data)
            except Exception:
                pass
    return {"products": products, "stripe_configured": bool(STRIPE_KEY)}
