"""
Orchestrator API — real AI planning using Claude, DeepSeek, or rule-based fallback.
Powers the command center chat. No key = smart fallback. Key set = real AI response.
"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
import os, json, urllib.request
from datetime import datetime, timezone

router = APIRouter(prefix="/api/orchestrator", tags=["orchestrator"])

def _now(): return datetime.now(timezone.utc).isoformat()

SYSTEM_PROMPT = """You are THE ONE — the AI command center for FanzoftheOne's ecosystem.

You have full context on these active projects:
- SubiLife (75% done): Next.js 14 PWA, WRX enthusiast platform, Socket.IO multiplayer rally game, leaderboard, photo gallery, 360° showcase. Deployed at subilife.vercel.app
- NotAlones (30% done): React + Node.js community support platform. Auth in progress.
- LegacyVault (8%): Digital archive, early planning.
- FanzSpot: Live Railway API at fanzspot-production.up.railway.app — multi-tenant build system.
- THE ONE Control Center: This app. Next.js frontend + FastAPI backend.

Your role: give sharp, specific, actionable responses. No filler. When asked to plan something, return a real structured plan with concrete steps. When asked about deployments, give honest status. You are the brain of the Revenue Engine (Builder, Modules, Marketplace, Apps) and Growth Engine (Companion, Memory, Reflection).

Keep responses concise — 2-4 sentences or a tight bullet list. Always move toward action."""

class ChatRequest(BaseModel):
    message: str
    history: Optional[list] = []

def _call_claude(message: str, history: list) -> str:
    key = os.getenv("ANTHROPIC_API_KEY", "")
    if not key:
        return None
    messages = []
    for h in history[-6:]:  # keep last 6 for context
        messages.append({"role": h.get("role", "user"), "content": h.get("text", "")})
    messages.append({"role": "user", "content": message})
    body = json.dumps({
        "model": "claude-sonnet-4-20250514",
        "max_tokens": 512,
        "system": SYSTEM_PROMPT,
        "messages": messages,
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            data = json.loads(r.read())
            return data["content"][0]["text"]
    except Exception:
        return None

def _call_deepseek(message: str, history: list) -> str:
    key = os.getenv("DEEPSEEK_API_KEY", "")
    if not key:
        return None
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for h in history[-6:]:
        messages.append({"role": h.get("role", "user"), "content": h.get("text", "")})
    messages.append({"role": "user", "content": message})
    body = json.dumps({"model": "deepseek-chat", "messages": messages, "max_tokens": 512}).encode()
    req  = urllib.request.Request(
        "https://api.deepseek.com/v1/chat/completions",
        data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            data = json.loads(r.read())
            return data["choices"][0]["message"]["content"]
    except Exception:
        return None

def _smart_fallback(message: str) -> str:
    """Rule-based responses when no API key is set — still genuinely useful."""
    msg = message.lower()

    if any(w in msg for w in ["subilife", "wRX", "rally", "leaderboard"]):
        return "SubiLife is 75% done. Next: wire the Socket.IO leaderboard (store top scores in Postgres, expose GET /api/leaderboard), then finish the 360° showcase hotspot system. Both can ship in one focused session."

    if any(w in msg for w in ["notalone", "not alone", "community", "auth"]):
        return "NotAlones needs JWT auth first — use next-auth with credentials provider, store sessions in Railway Postgres. Then build the community feed: POST /api/posts, GET /api/feed with pagination. That unblocks everything else."

    if any(w in msg for w in ["fanzspot", "warehouse", "tenant", "build"]):
        return "FanzSpot is live at fanzspot-production.up.railway.app. CORS is the blocker for Warehouse — add your Vercel domain to CORS_ORIGINS on Railway. Once that's set the build system connects end to end."

    if any(w in msg for w in ["deploy", "vercel", "railway"]):
        return "Set VERCEL_TOKEN and RAILWAY_TOKEN in your Railway env vars. Then hit POST /api/deploy/vercel with your project name and it triggers a real deploy. Status tracks via /api/deploy/vercel/status/{id}."

    if any(w in msg for w in ["plan", "sprint", "next", "what should"]):
        return "Priority order: 1) Fix FanzSpot CORS so Warehouse is live. 2) Ship SubiLife leaderboard. 3) Wire NotAlones auth. Each is a 1-2 hour focused session. Want me to break down any of these?"

    if any(w in msg for w in ["gmail", "email", "inbox"]):
        return "Gmail is connected via OAuth. Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REDIRECT_URI on Railway. Hit /api/auth/google from your frontend to authorize. After that /api/gmail/digest gives you inbox summaries."

    if any(w in msg for w in ["agent", "teacher", "student", "crew"]):
        return "THE ONE crew is active — teacher plans using the LLM planner, student executes via the tool system, skip evaluates the result. No API key required for this loop. Set ANTHROPIC_API_KEY on Railway for Claude-powered planning."

    return "THE ONE crew standing by. What's the goal — deploy, plan a feature, check a project, or run a mission?"

@router.post("/chat")
def chat(req: ChatRequest):
    message  = req.message.strip()
    history  = req.history or []
    provider = "fallback"
    response = None

    response = _call_claude(message, history)
    if response:
        provider = "claude"
    
    if not response:
        response = _call_deepseek(message, history)
        if response:
            provider = "deepseek"

    if not response:
        response = _smart_fallback(message)

    return {
        "response": response,
        "provider": provider,
        "timestamp": _now(),
    }

@router.get("/status")
def status():
    return {
        "status":      "ready",
        "orchestrator": "THE ONE",
        "ai_provider":  "claude" if os.getenv("ANTHROPIC_API_KEY") else
                        "deepseek" if os.getenv("DEEPSEEK_API_KEY") else "rule-based",
        "crew":         ["teacher", "student", "skip", "auditor"],
        "timestamp":    _now(),
    }
