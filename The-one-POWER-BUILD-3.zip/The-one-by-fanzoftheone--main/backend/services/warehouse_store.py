import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
WAREHOUSE_DIR = BASE_DIR / "warehouse"

WAREHOUSE_DIR.mkdir(exist_ok=True)

def save_record(name, data):
    file = WAREHOUSE_DIR / f"{name}.json"

    with open(file, "w") as f:
        json.dump(data, f)

    return {"status": "saved", "file": name}
