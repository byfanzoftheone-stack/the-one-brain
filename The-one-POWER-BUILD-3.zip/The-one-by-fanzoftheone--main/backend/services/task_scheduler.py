import time
from threading import Thread
from typing import Callable, Dict

tasks: Dict[str, Callable] = {}
running = False

def register_task(name: str, handler: Callable):
    tasks[name] = handler

def run_task(name: str):
    if name not in tasks:
        return {"error": "task_not_found"}

    try:
        return tasks[name]()
    except Exception as e:
        return {"error": str(e)}

def scheduler_loop():
    global running
    running = True

    while running:
        time.sleep(60)

def start_scheduler():
    thread = Thread(target=scheduler_loop, daemon=True)
    thread.start()
