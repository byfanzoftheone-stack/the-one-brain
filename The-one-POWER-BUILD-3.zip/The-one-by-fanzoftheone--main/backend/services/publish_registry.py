from pathlib import Path
import json
from datetime import datetime, UTC

BASE_DIR = Path(__file__).resolve().parents[2]
PUBLISH_DIR = BASE_DIR / "receipts" / "publish"

def _now():
    return datetime.now(UTC).isoformat()

def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

def publish_app(app_name: str, version: str = "1.0.0"):
    receipt = {
        "app": app_name,
        "version": version,
        "published_at": _now(),
        "status": "published"
    }

    path = PUBLISH_DIR / f"{app_name}.json"
    _write(path, receipt)

    return receipt
