import json
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parents[2]
LOG_DIR = BASE_DIR / "warehouse" / "logs"

LOG_DIR.mkdir(parents=True, exist_ok=True)

def log_event(event_type: str, payload: dict):
    log_file = LOG_DIR / "execution.log"

    record = {
        "time": datetime.utcnow().isoformat(),
        "type": event_type,
        "payload": payload
    }

    with open(log_file, "a") as f:
        f.write(json.dumps(record) + "\n")
