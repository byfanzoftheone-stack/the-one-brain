"""
Module Installer — installs modules from the registry into app directories.
"""
import json
from pathlib import Path
from datetime import datetime, timezone

BASE_DIR     = Path(__file__).resolve().parents[2]
MODULES_DIR  = BASE_DIR / "modules"
APPS_DIR     = BASE_DIR / "apps"
RECEIPTS_DIR = BASE_DIR / "warehouse/receipts/installs"
RECEIPTS_DIR.mkdir(parents=True, exist_ok=True)

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()

def available_modules() -> list:
    if not MODULES_DIR.exists():
        return []
    return sorted([
        d.name for d in MODULES_DIR.iterdir()
        if d.is_dir() and not d.name.startswith("_")
    ])

def install_module(module_name: str, app_name: str) -> dict:
    app_dir    = APPS_DIR / app_name
    module_dir = MODULES_DIR / module_name

    if not app_dir.exists():
        return {"status": "error", "error": f"App '{app_name}' not found. Create it first."}
    if not module_dir.exists():
        return {"status": "error", "error": f"Module '{module_name}' not found in registry."}

    # Load or create app manifest
    manifest_path = app_dir / "modules.json"
    manifest = {"name": app_name, "modules": [], "created_at": _now()}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text())
        except Exception:
            pass

    modules = manifest.get("modules", [])
    if module_name in modules:
        return {"status": "already_installed", "app": app_name, "module": module_name}

    modules.append(module_name)
    manifest["modules"]    = modules
    manifest["updated_at"] = _now()
    manifest_path.write_text(json.dumps(manifest, indent=2))

    # Write receipt
    receipt = {"app": app_name, "module": module_name, "installed_at": _now(), "status": "installed"}
    (RECEIPTS_DIR / f"{app_name}--{module_name}.json").write_text(json.dumps(receipt, indent=2))

    return {"status": "installed", "app": app_name, "module": module_name, "total_modules": len(modules)}

def uninstall_module(module_name: str, app_name: str) -> dict:
    manifest_path = APPS_DIR / app_name / "modules.json"
    if not manifest_path.exists():
        return {"status": "not_found", "app": app_name}
    manifest = json.loads(manifest_path.read_text())
    before   = len(manifest.get("modules", []))
    manifest["modules"]    = [m for m in manifest.get("modules", []) if m != module_name]
    manifest["updated_at"] = _now()
    manifest_path.write_text(json.dumps(manifest, indent=2))
    return {"status": "uninstalled", "app": app_name, "module": module_name, "removed": before > len(manifest["modules"])}

def get_installed(app_name: str) -> dict:
    manifest_path = APPS_DIR / app_name / "modules.json"
    if not manifest_path.exists():
        return {"app": app_name, "modules": [], "error": "no manifest"}
    manifest = json.loads(manifest_path.read_text())
    return {"app": app_name, "modules": manifest.get("modules", []), "status": "ok"}

if __name__ == "__main__":
    print("Available:", available_modules())
