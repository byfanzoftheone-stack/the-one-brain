from app.services.tool_registry import run_tool

class AgentRuntime:

    def __init__(self, name: str):
        self.name = name

    def run(self, tool: str, payload: dict):
        return {
            "agent": self.name,
            "tool": tool,
            "result": run_tool(tool, payload)
        }
