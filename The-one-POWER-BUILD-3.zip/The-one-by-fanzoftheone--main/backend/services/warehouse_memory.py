from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parents[2]
WAREHOUSE_DIR = BASE_DIR / "warehouse"

WAREHOUSE_DIR.mkdir(exist_ok=True)

def store(key: str, data):
    file = WAREHOUSE_DIR / f"{key}.json"
    file.write_text(json.dumps(data, indent=2))
    return {"stored": key}

def fetch(key: str):
    file = WAREHOUSE_DIR / f"{key}.json"

    if not file.exists():
        return {"error": "not_found"}

    try:
        return json.loads(file.read_text())
    except Exception:
        return {"error": "invalid_data"}

def list_keys():
    keys = []

    for f in WAREHOUSE_DIR.glob("*.json"):
        keys.append(f.stem)

    return sorted(keys)
