"""Export Generator — exports app data as JSON/CSV packages."""
import json
import csv
import io
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]

def _now(): return datetime.now(timezone.utc).isoformat()

def export_app(app_name: str, fmt: str = "json") -> dict:
    app_dir = ROOT / "apps" / app_name
    if not app_dir.exists():
        return {"status": "error", "error": f"App '{app_name}' not found"}

    manifest = {}
    if (app_dir / "modules.json").exists():
        try:
            manifest = json.loads((app_dir / "modules.json").read_text())
        except Exception:
            pass

    export_data = {
        "app":         app_name,
        "manifest":    manifest,
        "exported_at": _now(),
        "format":      fmt,
    }

    out_dir = ROOT / "warehouse/exports"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"{app_name}.json").write_text(json.dumps(export_data, indent=2))

    return {"status": "exported", "app": app_name, "format": fmt, "path": f"warehouse/exports/{app_name}.json"}
