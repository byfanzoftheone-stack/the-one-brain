from app.services.module_registry import modules

def build_app(module: str):
    if module not in modules():
        return {"status": "module_not_found"}

    return {
        "status": "app_generated",
        "module": module
    }
