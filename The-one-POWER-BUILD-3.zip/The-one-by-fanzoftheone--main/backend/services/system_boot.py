from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parents[2]
RECEIPTS = BASE_DIR / "receipts"

def boot_scan():
    state = {
        "installs": [],
        "publish": []
    }

    installs = RECEIPTS / "installs"
    publish = RECEIPTS / "publish"

    if installs.exists():
        for f in installs.glob("*.json"):
            state["installs"].append(json.loads(f.read_text()))

    if publish.exists():
        for f in publish.glob("*.json"):
            state["publish"].append(json.loads(f.read_text()))

    return state
