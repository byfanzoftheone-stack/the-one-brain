"""Health monitor — checks all system components and returns a full status."""
import os
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]

def _now(): return datetime.now(timezone.utc).isoformat()

def system_health() -> dict:
    checks = {}

    # Key directories
    for name in ["modules", "apps", "agents", "warehouse", "runtime"]:
        path = ROOT / name
        checks[name] = {"exists": path.exists(), "path": str(path)}

    # Key files
    for name, rel in [("backend_main", "backend/app/main.py"), ("modules_catalog", "modules/catalog.json")]:
        path = ROOT / rel
        checks[name] = {"exists": path.exists(), "size": path.stat().st_size if path.exists() else 0}

    # Providers
    providers = {
        "claude":  "set" if os.getenv("ANTHROPIC_API_KEY") else "missing",
        "openai":  "set" if os.getenv("OPENAI_API_KEY") else "missing",
        "ollama":  "available" if not os.getenv("DISABLE_OLLAMA") else "disabled",
    }

    passed = sum(1 for v in checks.values() if v.get("exists"))

    return {
        "status":    "ok" if passed >= len(checks) * 0.7 else "degraded",
        "system":    "THE ONE API",
        "version":   "1.0.0",
        "timestamp": _now(),
        "checks":    checks,
        "providers": providers,
        "summary":   {"total": len(checks), "passed": passed, "health_pct": round(passed / len(checks) * 100)},
    }
