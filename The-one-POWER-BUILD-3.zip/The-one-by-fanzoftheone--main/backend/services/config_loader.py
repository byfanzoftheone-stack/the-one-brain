import os

def get_config():
    return {
        "environment": os.getenv("ENV", "development"),
        "version": "1.0"
    }
