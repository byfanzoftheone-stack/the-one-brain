from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
AGENTS_DIR = BASE_DIR / "agents"

def list_agents():
    agents = []

    if not AGENTS_DIR.exists():
        return agents

    for agent in AGENTS_DIR.iterdir():
        if agent.is_dir():
            agents.append(agent.name)

    return sorted(agents)
