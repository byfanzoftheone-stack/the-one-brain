"""Task Memory — stores and retrieves task execution history."""
import json
from pathlib import Path
from datetime import datetime, timezone

MEMORY_FILE = Path("warehouse/task_memory.json")

def _now(): return datetime.now(timezone.utc).isoformat()

def _read() -> list:
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    return json.loads(MEMORY_FILE.read_text()) if MEMORY_FILE.exists() else []

def _write(data: list):
    MEMORY_FILE.write_text(json.dumps(data, indent=2))

def remember(task: str, result: dict, agent: str = "system") -> dict:
    mem     = _read()
    entry   = {"id": len(mem) + 1, "task": task, "result": result, "agent": agent, "timestamp": _now()}
    mem.append(entry)
    _write(mem[-500:])  # keep last 500
    return entry

def recall(limit: int = 20) -> list:
    return _read()[-limit:]

def recall_by_agent(agent: str, limit: int = 10) -> list:
    return [m for m in _read() if m.get("agent") == agent][-limit:]

def clear() -> dict:
    _write([])
    return {"status": "cleared"}
