from app.services.agent_registry import list_agents

def run_agent(name: str):
    agents = list_agents()

    if name not in agents:
        return {"status": "not_found"}

    return {
        "status": "executed",
        "agent": name
    }
