"""
Autonomous Builder — runs continuous build cycles.
Discovers modules, builds apps from approved opportunities, publishes receipts.
"""
import time
import json
from pathlib import Path
from datetime import datetime, timezone
from app.services.marketplace_registry import discover_modules
from app.services.publish_registry import publish_app

BASE_DIR = Path(__file__).resolve().parents[2]
LOG_FILE = BASE_DIR / "warehouse/runtime/autonomous_builder.json"
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

RUNNING  = True
INTERVAL = 60  # seconds between cycles

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()

def _log(event: str, data: dict):
    LOG_FILE.write_text(json.dumps({"timestamp": _now(), "event": event, "data": data}, indent=2))

def run_build_cycle() -> dict:
    modules = discover_modules()
    built   = []
    errors  = []

    for m in modules:
        slug = m.get("slug", "")
        if not slug:
            continue
        try:
            receipt = publish_app(slug)
            built.append({"module": slug, "receipt": receipt})
        except Exception as e:
            errors.append({"module": slug, "error": str(e)})

    result = {"timestamp": _now(), "modules_found": len(modules), "built": len(built), "errors": len(errors)}
    _log("cycle_complete", result)
    return result

def run_autonomous_builder() -> None:
    """Run the build loop. Designed to be run in a background thread/process."""
    global RUNNING
    _log("started", {"interval": INTERVAL})

    while RUNNING:
        try:
            result = run_build_cycle()
            _log("cycle", result)
        except Exception as e:
            _log("cycle_error", {"error": str(e)})
        time.sleep(INTERVAL)

def run_once() -> dict:
    """Run a single build cycle (useful for API triggers)."""
    return run_build_cycle()

if __name__ == "__main__":
    print(json.dumps(run_once(), indent=2))
