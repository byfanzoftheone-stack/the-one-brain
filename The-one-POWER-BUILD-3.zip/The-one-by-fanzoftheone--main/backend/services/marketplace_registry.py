"""
Marketplace Registry — discovers and indexes modules available for deployment.
"""
import json
from pathlib import Path
from datetime import datetime, timezone

BASE_DIR    = Path(__file__).resolve().parents[2]
MODULES_DIR = BASE_DIR / "modules"
REGISTRY    = BASE_DIR / "warehouse/registry.json"

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()

def discover_modules() -> list:
    modules = []
    if not MODULES_DIR.exists():
        return modules

    for item in MODULES_DIR.iterdir():
        if not item.is_dir() or item.name.startswith("_"):
            continue
        manifest_path = item / "module.json"
        data = {
            "slug":        item.name,
            "path":        str(item),
            "has_manifest": manifest_path.exists(),
            "manifest":    None,
        }
        if manifest_path.exists():
            try:
                data["manifest"] = json.loads(manifest_path.read_text())
                data.update({
                    "name":     data["manifest"].get("name", item.name),
                    "version":  data["manifest"].get("version", "1.0.0"),
                    "status":   data["manifest"].get("status", "installed"),
                    "category": data["manifest"].get("category", "general"),
                })
            except Exception:
                pass
        modules.append(data)

    return sorted(modules, key=lambda x: x["slug"])

def sync_registry() -> dict:
    modules  = discover_modules()
    registry = {
        "modules":    modules,
        "count":      len(modules),
        "updated_at": _now(),
    }
    REGISTRY.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY.write_text(json.dumps(registry, indent=2))
    return {"status": "synced", "count": len(modules)}

def get_registry() -> dict:
    if REGISTRY.exists():
        try:
            return json.loads(REGISTRY.read_text())
        except Exception:
            pass
    return sync_registry()

if __name__ == "__main__":
    print(json.dumps(sync_registry(), indent=2))
