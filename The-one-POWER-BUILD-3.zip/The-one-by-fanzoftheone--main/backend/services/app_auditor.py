from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parents[2]
APPS_DIR = BASE_DIR / "apps"

def audit_all_apps():
    results = []

    if not APPS_DIR.exists():
        return {"apps": [], "summary": {"total": 0, "pass": 0, "fail": 0}}

    for app_dir in APPS_DIR.iterdir():
        if not app_dir.is_dir():
            continue

        manifest = app_dir / "modules.json"
        readme = app_dir / "README.md"

        result = {
            "name": app_dir.name,
            "has_manifest": manifest.exists(),
            "has_readme": readme.exists(),
            "modules_valid": False,
            "status": "fail",
            "notes": []
        }

        if manifest.exists():
            try:
                data = json.loads(manifest.read_text())
                modules = data.get("modules", [])
                result["modules_valid"] = isinstance(modules, list) and len(modules) > 0
                if not result["modules_valid"]:
                    result["notes"].append("modules missing or invalid")
            except Exception as e:
                result["notes"].append(f"manifest parse error: {e}")

        if not readme.exists():
            result["notes"].append("README.md missing")

        if result["has_manifest"] and result["has_readme"] and result["modules_valid"]:
            result["status"] = "pass"

        results.append(result)

    passed = len([r for r in results if r["status"] == "pass"])
    failed = len(results) - passed

    return {
        "apps": results,
        "summary": {
            "total": len(results),
            "pass": passed,
            "fail": failed
        }
    }
