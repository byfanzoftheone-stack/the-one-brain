from app.services.autonomous_builder import autonomous_cycle
from app.services.maid_service import run_maid_scan
from app.services.system_watchdog import system_health

def run_agent_cycle():
    result = {
        "builder": None,
        "maid": None,
        "health": None
    }

    try:
        autonomous_cycle()
        result["builder"] = "ok"
    except Exception as e:
        result["builder"] = str(e)

    try:
        result["maid"] = run_maid_scan()
    except Exception as e:
        result["maid"] = str(e)

    try:
        result["health"] = system_health()
    except Exception as e:
        result["health"] = str(e)

    return result
