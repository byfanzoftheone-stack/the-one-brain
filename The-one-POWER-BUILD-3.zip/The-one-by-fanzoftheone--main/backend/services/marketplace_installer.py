from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
MODULES_DIR = BASE_DIR / "modules"
APPS_DIR = BASE_DIR / "apps"

APPS_DIR.mkdir(exist_ok=True)

def install_module(name: str):
    module = MODULES_DIR / name

    if not module.exists():
        return {"status": "not_found"}

    app_dir = APPS_DIR / name
    app_dir.mkdir(exist_ok=True)

    return {"status": "installed", "app": name}
