from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
APPS_DIR = BASE_DIR / "apps"

def services():
    items = []

    if not APPS_DIR.exists():
        return items

    for app in APPS_DIR.iterdir():
        if app.is_dir():
            items.append(app.name)

    return sorted(items)
