"""
Maid Service — scans the ecosystem for clutter and reports it.
Identifies empty dirs, leftover zips, tmp files, and orphaned receipts.
"""
from pathlib import Path
import shutil
import json
from datetime import datetime, timezone

BASE_DIR  = Path(__file__).resolve().parents[2]
SCAN_DIRS = [BASE_DIR / d for d in ("apps", "modules", "warehouse", "recipes")]

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()

def run_maid_scan() -> dict:
    report = {"scanned": [], "empty_dirs": [], "zip_files": [], "tmp_files": [], "timestamp": _now()}

    for scan_dir in SCAN_DIRS:
        if not scan_dir.exists():
            continue
        report["scanned"].append(str(scan_dir))

        for item in scan_dir.rglob("*"):
            if item.is_dir() and not any(item.iterdir()):
                report["empty_dirs"].append(str(item.relative_to(BASE_DIR)))
            elif item.suffix == ".zip":
                report["zip_files"].append({"file": str(item.relative_to(BASE_DIR)), "size": item.stat().st_size})
            elif item.suffix in (".tmp", ".bak"):
                report["tmp_files"].append(str(item.relative_to(BASE_DIR)))

    report["summary"] = {
        "dirs_scanned": len(report["scanned"]),
        "empty_dirs": len(report["empty_dirs"]),
        "zip_files": len(report["zip_files"]),
        "tmp_files": len(report["tmp_files"]),
        "action_needed": len(report["empty_dirs"]) + len(report["tmp_files"]) > 0,
    }

    out = BASE_DIR / "warehouse/maid"
    out.mkdir(parents=True, exist_ok=True)
    (out / "latest_scan.json").write_text(json.dumps(report, indent=2))

    return report

def clean_empty_dirs(dry_run: bool = True) -> dict:
    report = run_maid_scan()
    removed = []
    if not dry_run:
        for d in report["empty_dirs"]:
            try:
                path = BASE_DIR / d
                if path.exists() and path.is_dir():
                    path.rmdir()
                    removed.append(d)
            except Exception:
                pass
    return {"status": "dry_run" if dry_run else "cleaned", "removed": removed, "found": report["empty_dirs"]}

if __name__ == "__main__":
    print(json.dumps(run_maid_scan()["summary"], indent=2))
