from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parents[2]
APPS_DIR = BASE_DIR / "apps"

def list_apps():
    apps = []

    if not APPS_DIR.exists():
        return apps

    for app in APPS_DIR.iterdir():
        if app.is_dir():
            apps.append(app.name)

    return sorted(apps)

def app_manifest(app_name):
    path = APPS_DIR / app_name / "modules.json"

    if not path.exists():
        return {"name": app_name, "modules": []}

    try:
        return json.loads(path.read_text())
    except Exception:
        return {"name": app_name, "modules": []}
