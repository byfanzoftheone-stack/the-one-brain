from app.services.config_loader import get_config
from app.services.health_monitor import system_health

def boot():
    config = get_config()
    health = system_health()

    return {
        "boot": "success",
        "config": config,
        "health": health
    }
