from app.services.agent_registry import list_agents

class AgentCycle:
    def __init__(self):
        self.teachers = []
        self.students = []
        self.index = 0

    def load(self):
        agents = list_agents()
        half = len(agents) // 2

        self.teachers = agents[:half]
        self.students = agents[half:]

    def next_teacher(self):
        if not self.teachers:
            return None

        teacher = self.teachers[self.index % len(self.teachers)]
        self.index += 1
        return teacher

    def next_student(self):
        if not self.students:
            return None

        return self.students[self.index % len(self.students)]
