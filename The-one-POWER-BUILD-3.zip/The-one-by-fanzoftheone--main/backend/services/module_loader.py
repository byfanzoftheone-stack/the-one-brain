from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parents[2]
CATALOG_PATH = BASE_DIR / "modules" / "catalog.json"

def load_catalog():
    if not CATALOG_PATH.exists():
        return {"categories": []}

    with open(CATALOG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)
