from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
MODULES_DIR = BASE_DIR / "modules"

def modules():
    if not MODULES_DIR.exists():
        return []

    return [m.name for m in MODULES_DIR.iterdir() if m.is_dir()]
