from typing import Callable, Dict, Any

tool_registry: Dict[str, Callable] = {}

def register_tool(name: str, handler: Callable):
    tool_registry[name] = handler

def list_tools():
    return sorted(tool_registry.keys())

def run_tool(name: str, payload: Any):
    if name not in tool_registry:
        return {"error": "tool_not_found"}

    try:
        return tool_registry[name](payload)
    except Exception as e:
        return {"error": str(e)}
