from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
APPS_DIR = BASE_DIR / "apps"

def list_apps():
    if not APPS_DIR.exists():
        return []

    return [a.name for a in APPS_DIR.iterdir() if a.is_dir()]
