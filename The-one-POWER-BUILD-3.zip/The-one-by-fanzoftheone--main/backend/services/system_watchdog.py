from app.services.maid_service import run_maid_scan

def system_health():
    report = run_maid_scan()

    return {
        "status": "ok",
        "scan": report["summary"]
    }
