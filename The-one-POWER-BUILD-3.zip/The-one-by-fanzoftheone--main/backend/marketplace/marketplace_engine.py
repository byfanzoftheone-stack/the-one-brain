import json
import os

REGISTRY_PATH = os.path.join(os.getcwd(), "backend/marketplace/marketplace_registry.json")

def load_marketplace():
    with open(REGISTRY_PATH) as f:
        return json.load(f)

def list_modules():
    data = load_marketplace()
    return data["modules"]

def get_module(module_id):
    modules = list_modules()
    for m in modules:
        if m["id"] == module_id:
            return m
    return None

def install_module(module_id, app):
    module = get_module(module_id)
    if not module:
        return {"status": "error", "message": "module not found"}

    return {
        "status": "installed",
        "module": module_id,
        "target_app": app
    }
