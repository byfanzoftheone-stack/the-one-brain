import os
import json

REGISTRY_PATH = os.path.join(os.getcwd(), "backend/marketplace/marketplace_registry.json")
APPS_DIR = os.path.join(os.getcwd(), "apps")

def load_registry():
    with open(REGISTRY_PATH) as f:
        return json.load(f)

def get_module(module_id):
    data = load_registry()
    for m in data["modules"]:
        if m["id"] == module_id:
            return m
    return None

def install_module(module_id, app_name):
    module = get_module(module_id)
    if not module:
        return {"status": "error", "message": "module not found"}

    app_path = os.path.join(APPS_DIR, app_name)
    os.makedirs(app_path, exist_ok=True)

    manifest_path = os.path.join(app_path, "modules.json")

    if os.path.exists(manifest_path):
        with open(manifest_path) as f:
            manifest = json.load(f)
    else:
        manifest = {"modules": []}

    if module_id not in manifest["modules"]:
        manifest["modules"].append(module_id)

    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    return {
        "status": "installed",
        "module": module_id,
        "app": app_name
    }
