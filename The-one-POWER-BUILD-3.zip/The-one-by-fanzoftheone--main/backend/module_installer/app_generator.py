import os
import json

APPS_DIR = os.path.join(os.getcwd(), "apps")

def create_app(app_name):
    app_path = os.path.join(APPS_DIR, app_name)
    os.makedirs(app_path, exist_ok=True)

    manifest = {
        "name": app_name,
        "modules": []
    }

    with open(os.path.join(app_path, "modules.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    return {
        "status": "created",
        "app": app_name
    }
