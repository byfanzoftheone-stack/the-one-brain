from fastapi import APIRouter
from app.services.app_registry import list_apps

router = APIRouter(prefix="/api/apps", tags=["apps"])

@router.get("/")
def apps():
    return {"apps": list_apps()}
