from fastapi import APIRouter
from app.services.agent_runner import run_agent

router = APIRouter(prefix="/api/agents", tags=["agents"])

@router.post("/run/{name}")
def run(name: str):
    return run_agent(name)
