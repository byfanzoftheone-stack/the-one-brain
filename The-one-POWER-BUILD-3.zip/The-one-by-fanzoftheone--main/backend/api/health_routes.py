from fastapi import APIRouter
from app.services.health_monitor import system_health

router = APIRouter(prefix="/api/health", tags=["health"])

@router.get("/")
def health():
    return system_health()
