from fastapi import APIRouter
from app.services.agent_cycle import AgentCycle

router = APIRouter(prefix="/api/cycle", tags=["cycle"])

cycle = AgentCycle()
cycle.load()

@router.get("/teacher")
def teacher():
    return {"teacher": cycle.next_teacher()}

@router.get("/student")
def student():
    return {"student": cycle.next_student()}
