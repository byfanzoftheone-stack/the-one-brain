from fastapi import APIRouter
from app.services.module_loader import load_catalog
from app.services.app_registry import list_apps

router = APIRouter(prefix="/api")

@router.get("/modules")
def get_modules():
    return load_catalog()

@router.get("/apps")
def get_apps():
    return list_apps()
