from fastapi import APIRouter
from app.services.agent_runtime import AgentRuntime

router = APIRouter(prefix="/api/runtime", tags=["runtime"])

runtime = AgentRuntime("default")

@router.post("/run/{tool}")
def run(tool: str, payload: dict):
    return runtime.run(tool, payload)
