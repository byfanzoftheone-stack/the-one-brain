from fastapi import APIRouter
from app.services.builder_engine import build_app

router = APIRouter(prefix="/api/builder", tags=["builder"])

@router.post("/build/{module}")
def build(module: str):
    return build_app(module)
