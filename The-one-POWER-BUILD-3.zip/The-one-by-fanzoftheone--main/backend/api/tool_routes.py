from fastapi import APIRouter
from app.services.tool_registry import list_tools, run_tool

router = APIRouter(prefix="/api/tools", tags=["tools"])

@router.get("/")
def tools():
    return {"tools": list_tools()}

@router.post("/{tool_name}")
def execute(tool_name: str, payload: dict):
    return run_tool(tool_name, payload)
