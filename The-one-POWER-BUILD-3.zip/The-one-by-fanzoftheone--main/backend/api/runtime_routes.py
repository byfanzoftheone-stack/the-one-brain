from fastapi import APIRouter
from app.services.agent_runner import run_agent

router = APIRouter(prefix="/api/runtime", tags=["runtime"])

@router.post("/agent/{name}")
def run(name: str):
    return run_agent(name)
