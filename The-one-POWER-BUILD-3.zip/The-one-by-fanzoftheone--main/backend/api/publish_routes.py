from fastapi import APIRouter
from app.services.publish_registry import publish_app

router = APIRouter(prefix="/api/publish", tags=["publish"])

@router.post("/app/{app_name}")
def publish(app_name: str):
    return publish_app(app_name)
