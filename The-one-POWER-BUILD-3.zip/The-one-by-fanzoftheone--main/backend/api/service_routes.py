from fastapi import APIRouter
from app.services.service_registry import services

router = APIRouter(prefix="/api/services", tags=["services"])

@router.get("/")
def list_services():
    return {"services": services()}
