from fastapi import APIRouter
from app.services.forge_builder import build_from_recipe

router = APIRouter(prefix="/api/forge", tags=["forge"])

@router.post("/build/{recipe_name}")
def build_recipe(recipe_name: str):
    return build_from_recipe(recipe_name)
