from fastapi import APIRouter
from app.services.task_memory import store_task, list_tasks

router = APIRouter(prefix="/api/tasks", tags=["tasks"])

@router.post("/")
def create(task: dict):
    store_task(task)
    return {"status": "stored"}

@router.get("/")
def tasks():
    return {"tasks": list_tasks()}
