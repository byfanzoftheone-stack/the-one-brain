from fastapi import APIRouter
from app.services.module_installer import list_installable_modules, install_module

router = APIRouter(prefix="/api/installer", tags=["installer"])

@router.get("/modules")
def get_installable_modules():
    return {"modules": list_installable_modules()}

@router.post("/install/{app_name}/{module_slug}")
def install_module_route(app_name: str, module_slug: str):
    return install_module(app_name, module_slug)
