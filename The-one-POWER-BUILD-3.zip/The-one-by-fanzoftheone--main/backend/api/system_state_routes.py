from fastapi import APIRouter
from app.services.system_boot import boot_scan
from app.services.system_watchdog import system_health

router = APIRouter(prefix="/api/system", tags=["system"])

@router.get("/state")
def system_state():
    return boot_scan()

@router.get("/health")
def health():
    return system_health()
