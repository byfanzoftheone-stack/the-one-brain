from fastapi import APIRouter
from app.services.task_scheduler import tasks, run_task

router = APIRouter(prefix="/api/scheduler", tags=["scheduler"])

@router.get("/")
def list_tasks():
    return {"tasks": list(tasks.keys())}

@router.post("/run/{task}")
def run(task: str):
    return run_task(task)
