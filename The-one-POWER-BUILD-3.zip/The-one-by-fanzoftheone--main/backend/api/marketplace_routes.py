from fastapi import APIRouter
from app.services.marketplace_installer import install_module

router = APIRouter(prefix="/api/marketplace", tags=["marketplace"])

@router.post("/install/{name}")
def install(name: str):
    return install_module(name)


@router.get("")
def list_marketplace():
    return {
        "modules": [
            {
                "id": "the-one-crew",
                "name": "The One Crew",
                "description": "Core agent system with strategist, builder, auditor",
                "price": 49,
                "status": "available",
                "type": "core"
            },
            {
                "id": "automation-pack",
                "name": "Automation Pack",
                "description": "Prebuilt workflows and task execution modules",
                "price": 29,
                "status": "available",
                "type": "utility"
            }
        ]
    }
