from fastapi import APIRouter
from app.services.warehouse_store import save_record

router = APIRouter(prefix="/api/warehouse", tags=["warehouse"])

@router.post("/save/{name}")
def save(name: str, payload: dict):
    return save_record(name, payload)
