from fastapi import APIRouter
from app.services.health_monitor import system_health
from app.services.app_registry import list_apps

router = APIRouter(prefix="/api/system", tags=["system"])

@router.get("/status")
def status():
    return {
        "health": system_health(),
        "apps": list_apps()
    }
