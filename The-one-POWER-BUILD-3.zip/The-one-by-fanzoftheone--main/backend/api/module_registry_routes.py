from fastapi import APIRouter
from app.services.module_registry import registry

router = APIRouter(prefix="/api/registry", tags=["registry"])

@router.get("/modules")
def modules():
    return {"modules": registry()}
