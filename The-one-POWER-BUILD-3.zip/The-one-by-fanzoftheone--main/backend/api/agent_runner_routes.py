from fastapi import APIRouter
from app.services.agent_runner import run_agent

router = APIRouter(prefix="/api/agents/run", tags=["agent-runner"])

@router.post("/{tool}")
def run(tool: str, payload: dict):
    return run_agent(tool, payload)
