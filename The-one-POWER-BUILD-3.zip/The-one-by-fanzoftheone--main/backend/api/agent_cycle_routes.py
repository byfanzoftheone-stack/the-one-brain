from fastapi import APIRouter
from app.services.agent_bridge import run_agent_cycle

router = APIRouter(prefix="/api/agents", tags=["agents"])

@router.post("/cycle")
def run_cycle():
    return run_agent_cycle()
