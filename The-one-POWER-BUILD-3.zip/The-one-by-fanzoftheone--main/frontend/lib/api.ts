const BASE = typeof window !== "undefined"
  ? ""
  : (process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000");

export async function request(path: string, options: RequestInit = {}) {
  const url = `${BASE}/api${path}`;
  const res = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    cache: "no-store",
  });
  const text = await res.text();
  if (!res.ok) throw new Error(text || `Request failed: ${res.status}`);
  return text ? JSON.parse(text) : null;
}

export const fetchHealth = () => request("/health");
export const fetchSystem = () => request("/system/overview");
export const fetchApps = () => request("/apps/list");
export const fetchModules = () => request("/modules");
export const fetchMarketplace = () => request("/marketplace");
export const fetchTeacher = () => request("/teacher");
export const fetchStudent = () => request("/student");
export const fetchAgentLogs = () => request("/agents/logs");
export const fetchOrchestratorStatus = () => request("/orchestrator/status");
export const fetchAgentsStatus = () => request("/agents/status");

export const runMission = (payload: Record<string, unknown>) =>
  request("/execute", { method: "POST", body: JSON.stringify(payload) });
