export const navItems = [
  { label: "Dashboard",   href: "/dashboard"  },
  { label: "Apps",        href: "/apps"        },
  { label: "Builder",     href: "/builder"     },
  { label: "Modules",     href: "/modules"     },
  { label: "Marketplace", href: "/marketplace" },
  { label: "Agents",      href: "/agents"      },
  { label: "Mission",     href: "/mission"     },
  { label: "Warehouse",   href: "/warehouse"   },
  { label: "Gmail",       href: "/gmail"       },
  { label: "Companion",   href: "/companion"   },
  { label: "Labs",        href: "/labs"        },
  { label: "Settings",    href: "/settings"    },
];

export const dockItems = [
  { href: "/dashboard", label: "Hub"      },
  { href: "/apps",      label: "Apps"     },
  { href: "/builder",   label: "Build"    },
  { href: "/agents",    label: "Agents"   },
  { href: "/warehouse", label: "Warehouse" },
];
