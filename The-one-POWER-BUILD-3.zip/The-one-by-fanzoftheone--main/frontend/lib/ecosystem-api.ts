import { request } from "@/lib/api";

export async function getModules() {
  const data = await request("/modules");
  return data?.modules || [];
}

export async function getLogs() {
  const data = await request("/agents/logs");
  return data?.logs || [];
}

export async function runExecute(payload: Record<string, unknown>) {
  return request("/execute", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}
