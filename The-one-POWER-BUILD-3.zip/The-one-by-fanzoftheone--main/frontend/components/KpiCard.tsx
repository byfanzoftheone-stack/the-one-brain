type Props = { label: string; value: string; change: string };

export default function KpiCard({ label, value, change }: Props) {
  return (
    <div className="card">
      <h3>{label}</h3>
      <div className="kpi-value">{value}</div>
      <div className="kpi-change">{change}</div>
    </div>
  );
}
