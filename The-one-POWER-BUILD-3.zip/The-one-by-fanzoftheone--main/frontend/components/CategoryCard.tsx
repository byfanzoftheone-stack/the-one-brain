type Module = { slug: string; title: string; summary: string };
type Props = { title: string; slug: string; modules: Module[] };

export default function CategoryCard({ title, slug, modules }: Props) {
  return (
    <section className="card">
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
        <div>
          <h3>{title}</h3>
          <div className="muted small">/{slug}</div>
        </div>
        <span className="badge">{modules.length} modules</span>
      </div>
      <div className="module-list">
        {modules.slice(0, 6).map((module) => (
          <div className="module-item" key={module.slug}>
            <strong>{module.title}</strong>
            <div className="muted small">{module.summary}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
