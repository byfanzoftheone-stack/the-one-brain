type AgentLog = { id?: number; agent?: string; event?: string; status?: string; payload?: Record<string, unknown>; timestamp?: string; };

export default function AgentActivityPanel({ logs }: { logs: AgentLog[] }) {
  return (
    <div className="section-card" style={{ padding: 0, overflow: "hidden" }}>
      <div style={{ padding: "14px 18px", borderBottom: "2px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div className="section-title" style={{ marginBottom: 0 }}>Agent Activity</div>
        <span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>{logs.length} RECORDS</span>
      </div>
      {logs.length === 0 ? (
        <div style={{ textAlign: "center", padding: 28, color: "var(--text3)", fontSize: 12, fontWeight: 600 }}>No agent activity yet.</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column" }}>
          {logs.map((log, i) => (
            <div key={`${log.id ?? "x"}-${i}`} style={{ padding: "11px 18px", borderBottom: "2px solid var(--border)" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                <div style={{ fontSize: 12, fontWeight: 800, color: "var(--text)", fontFamily: "Nunito, sans-serif" }}>{log.agent ?? "unknown-agent"}</div>
                <div style={{ fontSize: 9, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>{log.timestamp ?? "no timestamp"}</div>
              </div>
              <div style={{ marginTop: 3, fontSize: 10, fontWeight: 700, color: log.status === "ok" ? "var(--green)" : "var(--blue)", textTransform: "uppercase", letterSpacing: "0.1em" }}>{log.status ?? "unknown"}</div>
              <div style={{ marginTop: 3, fontSize: 12, color: "var(--text2)", fontWeight: 600 }}>{log.event ?? "execution"}</div>
              {log.payload && (
                <pre style={{ marginTop: 8, fontFamily: "DM Mono, monospace", fontSize: 10, color: "var(--text2)", background: "var(--bg)", borderRadius: 6, padding: 10, overflowX: "auto", lineHeight: 1.6 }}>
                  {JSON.stringify(log.payload, null, 2)}
                </pre>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
