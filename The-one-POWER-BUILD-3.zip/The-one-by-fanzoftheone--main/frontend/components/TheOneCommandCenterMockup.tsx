export default function TheOneCommandCenterMockup() {
  const leftCards = ["Strategist", "Builder", "Maid", "Launcher"];
  const rightCards = ["Filesystem", "Templates", "Forge", "Shell", "Registry", "Warehouse"];
  const bottomCards = ["Modules", "Apps", "Marketplace", "Memory", "Runtime"];
  const topCards = ["Mission Queue", "Active Plan", "Audit", "Cost", "Local First"];

  const ExtrudedTitle = ({ line1, line2 }: { line1: string; line2: string }) => {
    const layers = Array.from({ length: 8 });
    return (
      <div className="relative inline-block select-none">
        {layers.map((_, i) => (
          <div
            key={i}
            className="absolute left-0 top-0 font-black tracking-tight text-black/20"
            style={{ transform: `translate(${i * 1.4}px, ${i * 1.4}px)` }}
          >
            <div className="text-4xl md:text-6xl leading-none">{line1}</div>
            <div className="text-3xl md:text-5xl leading-none">{line2}</div>
          </div>
        ))}
        <div className="relative font-black tracking-tight text-black">
          <div className="text-4xl md:text-6xl leading-none">{line1}</div>
          <div className="text-3xl md:text-5xl leading-none">{line2}</div>
        </div>
      </div>
    );
  };

  const FloatingCard = ({
    title,
    subtitle,
    className = "",
    tilt = "rotate-0",
  }: {
    title: string;
    subtitle?: string;
    className?: string;
    tilt?: string;
  }) => (
    <div
      className={`rounded-[2rem] border border-black/5 bg-white/80 backdrop-blur-md shadow-[10px_10px_24px_rgba(15,23,42,0.08),-8px_-8px_18px_rgba(255,255,255,0.8)] ${tilt} ${className}`}
    >
      <div className="p-4 md:p-5">
        <div className="text-sm md:text-base font-semibold text-slate-800">{title}</div>
        {subtitle ? <div className="mt-2 text-xs md:text-sm text-slate-500">{subtitle}</div> : null}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen w-full overflow-hidden bg-[#eef1f5] text-slate-900">
      <div className="mx-auto max-w-[1600px] p-4 md:p-8">
        <div className="text-center">
          <ExtrudedTitle line1="The One" line2="By FanzoftheOne" />
        </div>
      </div>
    </div>
  );
}
