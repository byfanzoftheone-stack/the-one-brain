"use client";

import { useEffect, useState } from "react";
import { request } from "@/lib/api";

type ModuleEntry = {
  slug?: string;
  name?: string;
  description?: string;
  price?: number | string;
};

export default function ModulesPanel() {
  const [modules, setModules] = useState<ModuleEntry[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    request("/modules")
      .then((data) => setModules(Array.isArray(data?.modules) ? data.modules : data?.modules?.modules || []))
      .catch((err) => setError(err.message || "Failed to load modules"));
  }, []);

  return (
    <section className="rounded-3xl border border-white/10 bg-gradient-to-b from-[#121a23] to-[#0c131a] p-6 shadow-[0_20px_60px_rgba(0,0,0,0.5)]">
      <div className="text-xs uppercase tracking-[0.3em] text-white/40">Modules</div>
      <h2 className="mt-3 text-2xl font-bold text-white">Available Modules</h2>

      {error ? (
        <div className="mt-4 text-sm text-red-400 break-words">{error}</div>
      ) : modules.length === 0 ? (
        <div className="mt-4 text-sm text-white/50">No modules available.</div>
      ) : (
        <div className="mt-4 grid gap-3">
          {modules.map((m, i) => (
            <div
              key={`${m.slug || m.name || "module"}-${i}`}
              className="rounded-xl border border-white/10 bg-black/20 p-4 text-white/80"
            >
              <h3 className="text-lg font-semibold text-white">{m.name || "Unnamed Module"}</h3>
              <p className="mt-1 text-sm text-white/60">{m.description || "No description"}</p>
              <strong className="mt-2 block text-green-400">
                {m.price !== undefined ? `$${m.price}` : "No price"}
              </strong>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
