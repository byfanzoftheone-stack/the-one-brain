type Module = {
  id: string;
  name: string;
  description: string;
  price: number;
  tags: string[];
};

export default function ModuleCard({ module }: { module: Module }) {
  return (
    <div style={{
      border: "1px solid #333",
      borderRadius: "12px",
      padding: "16px",
      marginBottom: "12px"
    }}>
      <h3>{module.name}</h3>
      <p>{module.description}</p>
      <div>💰 ${module.price}</div>
      <div>{module.tags?.join(", ")}</div>
    </div>
  );
}
