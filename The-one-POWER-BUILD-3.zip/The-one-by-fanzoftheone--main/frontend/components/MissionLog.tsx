"use client";

import { useEffect, useState } from "react";
import { request } from "@/lib/api";

type MissionLogEntry = {
  timestamp?: string;
  data?: {
    action?: string;
    status?: string;
    source?: string;
  };
};

export default function MissionLog() {
  const [logs, setLogs] = useState<MissionLogEntry[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    request("/agents/logs")
      .then((data) => setLogs(data?.logs || []))
      .catch((err) => setError(err.message || "Failed to load logs"));
  }, []);

  return (
    <section className="rounded-3xl border border-white/10 bg-gradient-to-b from-[#121a23] to-[#0c131a] p-6 shadow-[0_20px_60px_rgba(0,0,0,0.5)]">
      <div className="text-xs uppercase tracking-[0.3em] text-white/40">Mission History</div>
      <h2 className="mt-3 text-2xl font-bold text-white">Recent Runs</h2>

      {error ? (
        <div className="mt-4 text-sm text-red-400 break-words">{error}</div>
      ) : logs.length === 0 ? (
        <div className="mt-4 text-sm text-white/50">No mission history yet.</div>
      ) : (
        <div className="mt-4 space-y-3">
          {logs.map((log, i) => (
            <div
              key={`${log.timestamp || "no-time"}-${i}`}
              className="rounded-xl border border-white/10 bg-black/20 p-3 text-sm text-white/80"
            >
              <div>{log.timestamp || "No timestamp"}</div>
              <div>{log.data?.action || "unknown"} → {log.data?.status || "unknown"}</div>
              <div className="text-white/50">{log.data?.source || ""}</div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
