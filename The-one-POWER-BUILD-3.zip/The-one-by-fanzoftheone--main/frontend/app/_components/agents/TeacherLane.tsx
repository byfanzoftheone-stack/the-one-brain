"use client";
import { useState } from "react";
export default function TeacherLane() {
  const [active, setActive] = useState("Claude");
  const teachers = ["Claude", "ChatGPT", "Gemini"];
  return (
    <div className="lane">
      <div className="lane-title">Teacher Blocks</div>
      <div style={{ fontSize: 11, color: "var(--text3)", fontWeight: 600, marginBottom: 10 }}>
        Active teacher rotates context to the student block below.
      </div>
      <div className="chip-row">
        {teachers.map(t => (
          <button key={t} onClick={() => setActive(t)} className={`chip${active === t ? " chip-accent" : ""}`}>{t} Teacher</button>
        ))}
        <button className="chip chip-accent" style={{ background: "var(--purple)", borderColor: "var(--purple)" }}>↻ Rotate</button>
      </div>
      <div style={{ marginTop: 10, fontSize: 10, color: "var(--text3)", fontWeight: 700 }}>
        ACTIVE: <span style={{ color: "#111", textShadow: "var(--puff-xs)" }}>{active}</span>
      </div>
    </div>
  );
}
