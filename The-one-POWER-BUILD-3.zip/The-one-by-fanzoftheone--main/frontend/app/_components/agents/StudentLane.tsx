"use client";
import { useState } from "react";
export default function StudentLane() {
  const [active, setActive] = useState<string|null>(null);
  const students = ["Student A", "Student B", "Student C"];
  return (
    <div className="lane">
      <div className="lane-title">Student Blocks</div>
      <div style={{ fontSize: 11, color: "var(--text3)", fontWeight: 600, marginBottom: 10 }}>
        Student receives context from teacher and attempts the task.
      </div>
      <div className="chip-row">
        {students.map(s => (
          <button key={s} onClick={() => setActive(s)} className={`chip${active === s ? " chip-accent" : ""}`}>{s}</button>
        ))}
      </div>
    </div>
  );
}
