export default function BackpackPanel() {
  const items = ["accepted routing pattern", "working auth snippet", "validated module shell", "Prisma schema template"];
  return (
    <div className="section-card">
      <div className="section-title">Backpack — Saved Patterns</div>
      <ul className="simple-list">
        {items.map((item, i) => <li key={i}>{item}</li>)}
      </ul>
    </div>
  );
}
