"use client";
import { useState } from "react";
export default function SkipConsole() {
  const [log, setLog] = useState(["$ waiting for teacher block...", "$ waiting for student attempt...", "$ ready to run test"]);
  const [running, setRunning] = useState(false);
  async function run() {
    setRunning(true);
    setLog(prev => [...prev, "$ running test via Ollama...", "$ evaluating output..."]);
    await new Promise(r => setTimeout(r, 1200));
    setLog(prev => [...prev, "✓ test passed · saving to backpack"]);
    setRunning(false);
  }
  return (
    <div className="section-card">
      <div className="section-title">Skip Console (Ollama)</div>
      <div className="console-box">{log.map((l, i) => <div key={i}>{l}</div>)}</div>
      <div className="chip-row">
        <button className="chip chip-accent" onClick={run} disabled={running}>{running ? "Running..." : "▶ Run"}</button>
        <button className="chip">⬡ Test</button>
        <button className="chip" onClick={() => setLog(["$ ready"])}>Clear</button>
        <button className="chip">Save Good Code</button>
      </div>
    </div>
  );
}
