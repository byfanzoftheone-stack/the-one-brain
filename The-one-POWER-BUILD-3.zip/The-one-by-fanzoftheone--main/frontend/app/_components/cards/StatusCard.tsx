export default function StatusCard({ title, value, note }: { title: string; value: string; note?: string }) {
  return (
    <div className="panel-card">
      <div className="card-label">{title}</div>
      <div className="card-value">{value}</div>
      {note && <div className="card-note">{note}</div>}
    </div>
  );
}
