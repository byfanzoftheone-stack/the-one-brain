import Link from "next/link";
export default function LaunchCard({ title, href, desc }: { title: string; href: string; desc: string }) {
  return (
    <Link href={href} className="panel-card launch-card">
      <div className="card-value" style={{ fontSize: 14 }}>{title}</div>
      <div className="card-note">{desc}</div>
    </Link>
  );
}
