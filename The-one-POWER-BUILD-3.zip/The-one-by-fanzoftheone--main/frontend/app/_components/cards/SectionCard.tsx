import type { ReactNode } from "react";
export default function SectionCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="section-card">
      <div className="section-title">{title}</div>
      {children}
    </div>
  );
}
