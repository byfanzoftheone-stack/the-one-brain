export default function TopBar() {
  return (
    <header className="topnav">
      <div className="brand">
        <div className="brand-logo">TO</div>
        <div className="brand-text">
          <div className="brand-main">THE ONE</div>
          <div className="brand-sub">FanzoftheOne Command Station</div>
        </div>
      </div>
      <div className="nav-status">
        <div className="sp sp-b">
          <span className="sp-dot" style={{ background: "var(--blue)" }}></span>
          LIVE CORE
        </div>
        <div className="sp sp-g">
          <span className="sp-dot" style={{ background: "var(--green)" }}></span>
          ALL SYSTEMS GO
        </div>
      </div>
    </header>
  );
}
