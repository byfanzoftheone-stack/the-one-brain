import TopBar from "./TopBar";
import Sidebar from "./Sidebar";
import MobileDock from "./MobileDock";
import type { ReactNode } from "react";

export default function WorkspaceShell({
  title,
  subtitle,
  children,
  rightPanel,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  rightPanel?: ReactNode;
}) {
  return (
    <div className="shell">
      <TopBar />
      <div className={`shell-body${rightPanel ? " with-panel" : ""}`}>
        <Sidebar />
        <div className="shell-main">
          <main className="workspace">
            <div className="workspace-header">
              <h1>{title}</h1>
              {subtitle && <p>{subtitle}</p>}
            </div>
            {children}
          </main>
        </div>
        {rightPanel && (
          <aside className="rpanel">{rightPanel}</aside>
        )}
      </div>
      <MobileDock />
    </div>
  );
}
