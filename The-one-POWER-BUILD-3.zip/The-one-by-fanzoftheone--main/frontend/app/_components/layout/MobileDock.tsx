"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const dock = [
  { href: "/dashboard", label: "Hub"      },
  { href: "/apps",      label: "Apps"     },
  { href: "/builder",   label: "Build"    },
  { href: "/agents",    label: "Agents"   },
  { href: "/warehouse", label: "Warehouse" },
];

export default function MobileDock() {
  const pathname = usePathname();
  return (
    <nav className="mobile-dock">
      {dock.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={pathname === item.href ? "dock-link active" : "dock-link"}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
