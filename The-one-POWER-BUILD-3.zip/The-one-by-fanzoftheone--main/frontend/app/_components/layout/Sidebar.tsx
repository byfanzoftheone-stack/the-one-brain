"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const navItems = [
  { href: "/dashboard",   label: "Dashboard",   icon: "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z" },
  { href: "/apps",        label: "Apps",         icon: "M4 6h16M4 10h16M4 14h16M4 18h16" },
  { href: "/builder",     label: "Builder",      icon: "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" },
  { href: "/modules",     label: "Modules",      icon: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" },
  { href: "/marketplace", label: "Marketplace",  icon: "M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" },
  { href: "/agents",      label: "Agents",       icon: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" },
  { href: "/mission",     label: "Mission",      icon: "M22 12h-4l-3 9L9 3l-3 9H2" },
  { href: "/warehouse",   label: "Warehouse",    icon: "M2 7h20v14H2zM16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" },
  { href: "/gmail",       label: "Gmail",        icon: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" },
  { href: "/companion",   label: "Companion",    icon: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" },
  { href: "/labs",        label: "3-6-9 Builder",         icon: "M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18" },
  { href: "/market",      label: "Marketplace →", icon: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" },
  { href: "/settings",    label: "Settings",     icon: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const isActive = (href: string) =>
    href === "/dashboard" ? pathname === href : pathname.startsWith(href);

  return (
    <aside className="sidebar">
      <div style={{ padding: "0 10px 12px", borderBottom: "2px solid var(--border)", marginBottom: 10 }}>
        <div style={{ fontSize: 9, color: "var(--text3)", letterSpacing: "2.5px", fontWeight: 700, textTransform: "uppercase", marginBottom: 3 }}>FanzoftheOne</div>
        <div style={{ fontSize: 15, fontWeight: 900, color: "#111", textShadow: "var(--puff-sm)", letterSpacing: -0.5, fontFamily: "Nunito, sans-serif" }}>THE ONE</div>
      </div>
      <div style={{ fontSize: 9, color: "var(--text3)", letterSpacing: "2.5px", fontWeight: 700, textTransform: "uppercase", padding: "0 17px", marginBottom: 6 }}>Navigation</div>
      <nav className="sidebar-nav">
        {navItems.map(item => (
          <Link key={item.href} href={item.href} className={`sb-item${isActive(item.href) ? " active" : ""}`}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ flexShrink: 0 }}>
              <path d={item.icon} />
            </svg>
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="sb-footer">THE ONE <span>v2</span> · FANZOFTHEONE</div>
    </aside>
  );
}
