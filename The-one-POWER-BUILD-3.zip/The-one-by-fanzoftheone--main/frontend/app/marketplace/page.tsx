"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState } from "react";

type Listing = { slug: string; title: string; desc: string; category: string; price: number; status: "active" | "draft" | "coming"; modules: string[]; };

const LISTINGS: Listing[] = [
  { slug: "construction-ops",         title: "Construction Ops",         desc: "Full field service management — quotes, scheduling, invoices, crew dispatch",    category: "Service Business",  price: 99,  status: "active",  modules: ["crm","scheduling","payments","analytics"] },
  { slug: "play-better",              title: "Play Better",              desc: "Performance coaching system with tracking, sessions, and progress metrics",       category: "Coaching",          price: 79,  status: "active",  modules: ["scheduling","analytics","companion"] },
  { slug: "not-alone",                title: "Not Alone",                desc: "Community support platform — forums, messaging, groups, shared journeys",         category: "Community",         price: 49,  status: "coming",  modules: ["messaging","analytics"] },
  { slug: "little-pro",               title: "Little Pro",               desc: "Productivity and team management for small businesses",                           category: "Productivity",      price: 59,  status: "active",  modules: ["crm","scheduling","analytics"] },
  { slug: "email-growth-engine",      title: "Email Growth Engine",      desc: "AI-powered email marketing with sequences, templates, and analytics",              category: "Marketing",         price: 89,  status: "active",  modules: ["email-agent","analytics"] },
  { slug: "content-machine",          title: "Content Machine",          desc: "Automated content creation, scheduling, and SEO optimization",                   category: "Content",           price: 99,  status: "active",  modules: ["content-agent","seo-agent","analytics"] },
  { slug: "seo-automation-app",       title: "SEO Automation",          desc: "Rank higher with automated keyword research, content, and backlink tracking",      category: "Marketing",         price: 79,  status: "active",  modules: ["seo-agent","analytics"] },
  { slug: "nervous-system",  title: "Nervous System",      desc: "Real-time IoT & fleet monitoring with autonomous agent response — Redis queue, FastAPI, AI workers",  category: "Infrastructure",      price: 149, status: "active",  modules: ["analytics","messaging","ai-tools"] },
  { slug: "fanzo-core",      title: "Fanzo Core Template", desc: "Hardened Docker microservice. Iron Core standard — strict typing, health checks, defensive coding",          category: "Developer Tools",     price: 49,  status: "active",  modules: ["analytics"] },
  { slug: "content-engine",  title: "Content Engine",      desc: "AI video pipeline — Script → Image (Leonardo) → Voice (ElevenLabs) → Video. Two avatar profiles included",  category: "Content & Marketing", price: 129, status: "active",  modules: ["content-agent","email-agent","analytics"] },
  { slug: "subilife",                 title: "SubiLife",                 desc: "WRX enthusiast platform — build logs, gallery, multiplayer rally, community",     category: "Community",         price: 29,  status: "active",  modules: ["analytics","messaging"] },
];

const CATEGORIES = ["All", ...Array.from(new Set(LISTINGS.map(l => l.category)))];
const STATUS_STYLE: Record<string, { bg: string; color: string; border: string }> = {
  active:  { bg: "#f0fdf4", color: "var(--green)",  border: "#bbf7d0" },
  coming:  { bg: "#fff7ed", color: "var(--orange)", border: "#fed7aa" },
  draft:   { bg: "var(--bg)", color: "var(--text3)", border: "var(--border)" },
};

export default function MarketplacePage() {
  const [cat, setCat]           = useState("All");
  const [search, setSearch]     = useState("");
  const [selected, setSelected] = useState<Listing | null>(null);
  const [cart, setCart]         = useState<string[]>([]);
  const [installing, setInstalling] = useState<string | null>(null);

  const filtered = LISTINGS.filter(l =>
    (cat === "All" || l.category === cat) &&
    (!search || l.title.toLowerCase().includes(search.toLowerCase()) || l.desc.toLowerCase().includes(search.toLowerCase()))
  );

  async function addToCart(slug: string) {
    if (cart.includes(slug)) return;
    setInstalling(slug);
    await new Promise(r => setTimeout(r, 500));
    setCart(c => [...c, slug]);
    setInstalling(null);
  }

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">Catalog</div>
          <div className="mrow"><span className="mlabel">Total Apps</span><span className="mval">{LISTINGS.length}</span></div>
          <div className="mrow"><span className="mlabel">Active</span><span className="mval" style={{ color: "var(--green)" }}>{LISTINGS.filter(l => l.status === "active").length}</span></div>
          <div className="mrow"><span className="mlabel">Coming</span><span className="mval" style={{ color: "var(--orange)" }}>{LISTINGS.filter(l => l.status === "coming").length}</span></div>
          <div className="mrow"><span className="mlabel">Cart</span><span className="mval" style={{ color: "var(--purple)" }}>{cart.length}</span></div>
        </div>
        {cart.length > 0 && (
          <div className="rcard" style={{ borderLeft: "3px solid var(--purple)" }}>
            <div className="rt" style={{ color: "var(--purple)" }}>Cart</div>
            {cart.map(slug => {
              const l = LISTINGS.find(x => x.slug === slug);
              return l ? (
                <div key={slug} className="mrow">
                  <span className="mlabel">{l.title}</span>
                  <span style={{ fontSize: 10, fontWeight: 800, color: "var(--green)", fontFamily: "Nunito, sans-serif" }}>${l.price}/mo</span>
                </div>
              ) : null;
            })}
            <div style={{ borderTop: "2px solid var(--border)", paddingTop: 8, marginTop: 6 }}>
              <div className="mrow">
                <span style={{ fontSize: 12, fontWeight: 800, color: "#111", fontFamily: "Nunito, sans-serif" }}>Total</span>
                <span style={{ fontSize: 13, fontWeight: 900, color: "#111", fontFamily: "Nunito, sans-serif", textShadow: "var(--puff-xs)" }}>
                  ${cart.reduce((sum, slug) => sum + (LISTINGS.find(l => l.slug === slug)?.price ?? 0), 0)}/mo
                </span>
              </div>
              <button className="btn btn-p" style={{ width: "100%", marginTop: 8, fontSize: 11 }}>Checkout →</button>
            </div>
          </div>
        )}
        {selected && (
          <div className="rcard">
            <div className="rt">Details</div>
            <div style={{ fontSize: 12, fontWeight: 800, color: "#111", fontFamily: "Nunito, sans-serif", marginBottom: 6 }}>{selected.title}</div>
            <div style={{ fontSize: 11, color: "var(--text2)", fontWeight: 600, lineHeight: 1.6, marginBottom: 10 }}>{selected.desc}</div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "var(--text3)", marginBottom: 6, textTransform: "uppercase" }}>Includes</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
              {selected.modules.map(m => <span key={m} className="chip" style={{ fontSize: 9, padding: "3px 8px" }}>{m}</span>)}
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <WorkspaceShell title="Marketplace" subtitle="Apps, modules, and templates for your ecosystem" rightPanel={<RightPanel />}>

      {/* Search + category */}
      <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search marketplace…"
          style={{ background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "8px 12px", fontSize: 12, fontWeight: 600, color: "var(--text)", outline: "none", flex: 1, minWidth: 160, fontFamily: "Nunito Sans, sans-serif" }} />
        <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
          {CATEGORIES.map(c => (
            <button key={c} onClick={() => setCat(c)} className={cat === c ? "chip chip-accent" : "chip"} style={{ fontSize: 10 }}>{c}</button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px,1fr))", gap: 12 }}>
        {filtered.map(l => {
          const ss       = STATUS_STYLE[l.status];
          const inCart   = cart.includes(l.slug);
          const isSelected = selected?.slug === l.slug;
          return (
            <div key={l.slug} className="panel-card" onClick={() => setSelected(isSelected ? null : l)}
              style={{ cursor: "pointer", borderLeft: isSelected ? "4px solid #111" : undefined, position: "relative" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)", textTransform: "uppercase" }}>{l.category}</span>
                <span style={{ fontSize: 8, fontWeight: 800, padding: "2px 7px", borderRadius: 20, background: ss.bg, color: ss.color, border: `2px solid ${ss.border}`, fontFamily: "Nunito, sans-serif" }}>
                  {l.status === "active" ? "AVAILABLE" : l.status === "coming" ? "COMING SOON" : "DRAFT"}
                </span>
              </div>
              <div className="card-value" style={{ fontSize: 14, marginBottom: 4 }}>{l.title}</div>
              <div className="card-note" style={{ marginBottom: 12, lineHeight: 1.5 }}>{l.desc}</div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 16, fontWeight: 900, color: "#111", textShadow: "var(--puff-xs)", fontFamily: "Nunito, sans-serif" }}>
                  ${l.price}<span style={{ fontSize: 9, color: "var(--text3)", fontWeight: 600 }}>/mo</span>
                </span>
                {l.status === "active" && (
                  <button onClick={e => { e.stopPropagation(); addToCart(l.slug); }} disabled={inCart || installing === l.slug}
                    className={inCart ? "chip" : "chip chip-accent"} style={{ fontSize: 9 }}>
                    {installing === l.slug ? "…" : inCart ? "✓ In Cart" : "+ Add"}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </WorkspaceShell>
  );
}
