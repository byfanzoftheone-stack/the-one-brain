import WorkspaceShell from "../../_components/layout/WorkspaceShell";
import Link from "next/link";

export default function ContentEnginePage() {
  return (
    <WorkspaceShell title="Content Engine" subtitle="AI Video Pipeline · Script → Voice → Video · $129/mo">
      {/* Hero */}
      <div style={{ background: "linear-gradient(135deg, #7c3aed 0%, #2563eb 100%)", borderRadius: 14, padding: "24px 28px", marginBottom: 18, color: "#fff" }}>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.5)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "2px", marginBottom: 8 }}>Content & Marketing · AI-Powered</div>
        <h2 style={{ fontSize: 22, fontWeight: 900, marginBottom: 10, fontFamily: "Nunito, sans-serif" }}>One Prompt. Finished Video.</h2>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.8)", lineHeight: 1.7, maxWidth: 560, marginBottom: 16 }}>
          The engine writes the script, generates the visuals, synthesizes the voice, and assembles the video. Two avatar profiles included — The Fixer and The Siren.
        </p>
        <div style={{ display: "flex", gap: 10 }}>
          <Link href="/marketplace" className="btn btn-p" style={{ textDecoration: "none", fontSize: 12, background: "#fff", color: "#7c3aed" }}>Get Started — $129/mo</Link>
        </div>
      </div>

      {/* Pipeline */}
      <div className="sh"><span className="st">The Pipeline</span><div className="sl"></div></div>
      <div style={{ display: "flex", alignItems: "center", gap: 0, marginBottom: 18, overflowX: "auto" }}>
        {[
          { step: "1", label: "Script",   tool: "Claude / DeepSeek", icon: "✍️" },
          { step: "→", label: "",          tool: "",                  icon: ""   },
          { step: "2", label: "Visuals",  tool: "Leonardo.ai",       icon: "🎨" },
          { step: "→", label: "",          tool: "",                  icon: ""   },
          { step: "3", label: "Voice",    tool: "ElevenLabs",        icon: "🎙️" },
          { step: "→", label: "",          tool: "",                  icon: ""   },
          { step: "4", label: "Video",    tool: "FFmpeg",            icon: "🎬" },
        ].map((s, i) => s.step === "→" ? (
          <div key={i} style={{ fontSize: 24, color: "var(--text3)", padding: "0 8px" }}>→</div>
        ) : (
          <div key={i} className="panel-card" style={{ flex: 1, textAlign: "center", minWidth: 100 }}>
            <div style={{ fontSize: 26, marginBottom: 6 }}>{s.icon}</div>
            <div style={{ fontSize: 12, fontWeight: 900, color: "#111", fontFamily: "Nunito, sans-serif" }}>{s.label}</div>
            <div style={{ fontSize: 10, color: "var(--text3)" }}>{s.tool}</div>
          </div>
        ))}
      </div>

      {/* Avatars */}
      <div className="sh"><span className="st">Avatar Profiles</span><div className="sl"></div></div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 18 }}>
        <div className="panel-card" style={{ borderTop: "4px solid var(--orange)" }}>
          <div className="card-label" style={{ color: "var(--orange)" }}>Male Avatar</div>
          <div className="card-value" style={{ fontSize: 16 }}>The Fixer</div>
          <div className="card-note" style={{ marginBottom: 10 }}>Rugged, authoritative, technical. Deep raspy voice.</div>
          <div style={{ fontSize: 10, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>ElevenLabs · stability: 0.45</div>
        </div>
        <div className="panel-card" style={{ borderTop: "4px solid var(--purple)" }}>
          <div className="card-label" style={{ color: "var(--purple)" }}>Female Avatar</div>
          <div className="card-value" style={{ fontSize: 16 }}>The Siren</div>
          <div className="card-note" style={{ marginBottom: 10 }}>Engaging, energetic, lifestyle. Smooth breathless voice.</div>
          <div style={{ fontSize: 10, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>ElevenLabs · stability: 0.35</div>
        </div>
      </div>

      <div className="section-card">
        <div className="section-title">Pricing</div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 8 }}>
          <span style={{ fontSize: 32, fontWeight: 900, color: "#111", fontFamily: "Nunito, sans-serif", textShadow: "var(--puff-xs)" }}>$129</span>
          <span style={{ fontSize: 14, color: "var(--text3)" }}>/month</span>
        </div>
        <ul className="simple-list">
          <li>Unlimited content generation</li>
          <li>Both avatar profiles included</li>
          <li>All integrations: Leonardo, ElevenLabs, FFmpeg</li>
          <li>Simulation mode — test without API keys</li>
        </ul>
        <Link href="/marketplace" className="btn btn-p" style={{ textDecoration: "none", display: "inline-block", marginTop: 14, fontSize: 12 }}>Add to Cart →</Link>
      </div>
    </WorkspaceShell>
  );
}
