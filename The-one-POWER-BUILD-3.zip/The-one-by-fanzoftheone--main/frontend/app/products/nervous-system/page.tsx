import WorkspaceShell from "../../_components/layout/WorkspaceShell";
import Link from "next/link";

export default function NervousSystemPage() {
  return (
    <WorkspaceShell title="Nervous System" subtitle="IoT & Fleet Monitoring · Autonomous Agent Response · $149/mo">
      {/* Hero */}
      <div style={{ background: "linear-gradient(135deg, #111 0%, #1a1a2e 100%)", borderRadius: 14, padding: "24px 28px", marginBottom: 18, color: "#fff" }}>
        <div style={{ fontSize: 10, color: "#666", fontWeight: 700, textTransform: "uppercase", letterSpacing: "2px", marginBottom: 8 }}>Infrastructure · Real-time</div>
        <h2 style={{ fontSize: 22, fontWeight: 900, marginBottom: 10, fontFamily: "Nunito, sans-serif", textShadow: "var(--puff-sm)" }}>Your Assets Think For Themselves</h2>
        <p style={{ fontSize: 13, color: "#aaa", lineHeight: 1.7, maxWidth: 560, marginBottom: 16 }}>
          Connect trucks, sensors, and software to an AI brain that detects problems and deploys fixes automatically. No human required. 100ms response time.
        </p>
        <div style={{ display: "flex", gap: 10 }}>
          <Link href="/marketplace" className="btn btn-p" style={{ textDecoration: "none", fontSize: 12 }}>Get Started — $149/mo</Link>
          <span style={{ padding: "8px 14px", borderRadius: 8, border: "2px solid #333", fontSize: 11, color: "#888" }}>Docker · Redis · FastAPI</span>
        </div>
      </div>

      {/* Architecture */}
      <div className="sh"><span className="st">How It Works</span><div className="sl"></div></div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginBottom: 18 }}>
        {[
          { icon: "👂", label: "The Ears",  desc: "FastAPI receives signals from trucks and sensors" },
          { icon: "🦴", label: "The Spine", desc: "Redis queue — zero latency, nothing lost" },
          { icon: "🧠", label: "The Brain", desc: "AI agents wake up and plan the response" },
          { icon: "⚡", label: "The Hands", desc: "Override API deploys fixes automatically" },
        ].map(s => (
          <div key={s.label} className="panel-card" style={{ textAlign: "center" }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
            <div style={{ fontSize: 13, fontWeight: 900, color: "#111", fontFamily: "Nunito, sans-serif", marginBottom: 4 }}>{s.label}</div>
            <div style={{ fontSize: 11, color: "var(--text3)", lineHeight: 1.5 }}>{s.desc}</div>
          </div>
        ))}
      </div>

      {/* Use cases */}
      <div className="sh"><span className="st">Use Cases</span><div className="sl"></div></div>
      <div className="grid-cards" style={{ marginBottom: 18 }}>
        {[
          { title: "Fleet Management",       desc: "Monitor trucks, reroute on breakdown, track cargo temperature" },
          { title: "Field Service",           desc: "Track technicians, detect equipment failures, dispatch automatically" },
          { title: "Cold Chain",              desc: "Monitor temperature-sensitive cargo, auto-alert on threshold breach" },
          { title: "Software Monitoring",     desc: "Watch API health, detect latency spikes, auto-restart services" },
        ].map(u => (
          <div key={u.title} className="panel-card">
            <div className="card-value" style={{ fontSize: 13 }}>{u.title}</div>
            <div className="card-note">{u.desc}</div>
          </div>
        ))}
      </div>

      {/* Pricing */}
      <div className="section-card">
        <div className="section-title">Pricing</div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 8 }}>
          <span style={{ fontSize: 32, fontWeight: 900, color: "#111", fontFamily: "Nunito, sans-serif", textShadow: "var(--puff-xs)" }}>$149</span>
          <span style={{ fontSize: 14, color: "var(--text3)" }}>/month</span>
        </div>
        <ul className="simple-list">
          <li>Up to 50 monitored units</li>
          <li>Unlimited signal processing</li>
          <li>Full source code — deploy anywhere</li>
          <li>Redis + Docker included</li>
        </ul>
        <Link href="/marketplace" className="btn btn-p" style={{ textDecoration: "none", display: "inline-block", marginTop: 14, fontSize: 12 }}>Add to Cart →</Link>
      </div>
    </WorkspaceShell>
  );
}
