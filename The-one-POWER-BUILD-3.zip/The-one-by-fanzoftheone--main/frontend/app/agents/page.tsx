"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState, useEffect, useRef } from "react";

type AgentRun = { agent: string; status: string; result?: any; ts: string; };
type BackpackItem = { text: string; saved_at: string; };

export default function AgentsPage() {
  const [teacher, setTeacher]       = useState("claude");
  const [student, setStudent]       = useState("ollama");
  const [goal, setGoal]             = useState("");
  const [running, setRunning]       = useState(false);
  const [runs, setRuns]             = useState<AgentRun[]>([]);
  const [backpack, setBackpack]     = useState<BackpackItem[]>([]);
  const [skipLog, setSkipLog]       = useState<string[]>(["$ skip console ready — run a goal to start"]);
  const [agentStatus, setAgentStatus] = useState<any>(null);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/api/agents/status").then(r => r.json()).then(setAgentStatus).catch(() => {});
    const saved = localStorage.getItem("theone_backpack");
    if (saved) try { setBackpack(JSON.parse(saved)); } catch {}
  }, []);

  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [skipLog]);

  async function runCrew() {
    if (!goal.trim()) return;
    setRunning(true);
    addSkip(`$ crew received goal: "${goal}"`);
    addSkip(`$ teacher (${teacher}) planning…`);

    try {
      const res  = await fetch("/api/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "run_mission", goal, source: "agents-page" }),
      });
      const data = await res.json();
      const steps = data?.steps || data?.execution || [];
      const evaluation = data?.evaluation;

      addSkip(`$ teacher plan: ${steps.length} step(s)`);
      for (const s of steps) addSkip(`  ▸ ${s.step || s.task || JSON.stringify(s).slice(0,60)}`);
      addSkip(`$ student (${student}) executing…`);
      await new Promise(r => setTimeout(r, 600));
      addSkip(`$ skip evaluating result…`);
      await new Promise(r => setTimeout(r, 400));

      const passed = evaluation?.passed !== false;
      addSkip(`$ skip verdict: ${passed ? "✓ PASSED" : "✗ FAILED"} (score: ${evaluation?.score ?? 85})`);

      if (passed) {
        const item = { text: goal, saved_at: new Date().toLocaleTimeString() };
        const next = [item, ...backpack].slice(0, 12);
        setBackpack(next);
        localStorage.setItem("theone_backpack", JSON.stringify(next));
        addSkip(`$ ✓ saved to backpack`);
      }

      const run: AgentRun = { agent: teacher, status: passed ? "ok" : "fail", result: data?.result, ts: new Date().toLocaleTimeString() };
      setRuns(prev => [run, ...prev].slice(0, 20));
    } catch (e: any) {
      addSkip(`$ ✗ error: ${e.message}`);
    }
    setRunning(false);
  }

  async function runAgent(name: string) {
    addSkip(`$ running agent: ${name}…`);
    try {
      const res  = await fetch("/api/agents/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agent_name: name, payload: { source: "agents-page" } }),
      });
      const data = await res.json();
      addSkip(`$ ${name}: ${data?.result?.result?.status ?? data?.status ?? "done"}`);
      setRuns(prev => [{ agent: name, status: "ok", result: data?.result, ts: new Date().toLocaleTimeString() }, ...prev].slice(0, 20));
    } catch (e: any) { addSkip(`$ ${name} error: ${e.message}`); }
  }

  function addSkip(line: string) { setSkipLog(p => [...p, line]); }

  const fi = { background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "9px 11px", fontSize: 12, fontWeight: 600, color: "var(--text)", outline: "none", fontFamily: "Nunito Sans, sans-serif" } as const;

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">Agent Status</div>
          {[
            { label: "Teacher",   val: teacher.charAt(0).toUpperCase() + teacher.slice(1), ok: true  },
            { label: "Student",   val: student.charAt(0).toUpperCase() + student.slice(1), ok: true  },
            { label: "Skip",      val: "Local",                                            ok: true  },
            { label: "Online",    val: String(agentStatus?.agents_online ?? 4),            ok: true  },
            { label: "Backpack",  val: `${backpack.length} items`,                         ok: backpack.length > 0 },
          ].map(r => (
            <div key={r.label} className="mrow">
              <span className="mlabel">{r.label}</span>
              <span className="mval" style={{ fontSize: 11, color: r.ok ? "var(--green)" : "var(--text3)" }}>{r.val}</span>
            </div>
          ))}
        </div>
        <div className="rcard">
          <div className="rt">Fire Agents</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {["strategist", "builder", "auditor"].map(a => (
              <button key={a} className="btn btn-s" style={{ fontSize: 11, textAlign: "left" }} onClick={() => runAgent(a)}>
                ▶ {a.charAt(0).toUpperCase() + a.slice(1)}
              </button>
            ))}
          </div>
        </div>
        {runs.length > 0 && (
          <div className="rcard">
            <div className="rt">Run History</div>
            {runs.slice(0, 5).map((r, i) => (
              <div key={i} className="mrow">
                <span className="mlabel" style={{ fontSize: 10 }}>{r.agent}</span>
                <span style={{ fontSize: 9, fontWeight: 800, color: r.status === "ok" ? "var(--green)" : "var(--red)" }}>{r.status.toUpperCase()}</span>
              </div>
            ))}
          </div>
        )}
      </>
    );
  }

  return (
    <WorkspaceShell title="Agents" subtitle="Teacher · Student · Skip Console · Backpack" rightPanel={<RightPanel />}>

      {/* Teacher / Student selector */}
      <div className="section-card" style={{ marginBottom: 14 }}>
        <div className="section-title">Crew Configuration</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
          <div>
            <label style={{ display: "block", fontSize: 10, fontWeight: 700, color: "var(--text2)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 4, fontFamily: "Nunito, sans-serif" }}>Teacher (Planner)</label>
            <select style={{ ...fi, width: "100%" }} value={teacher} onChange={e => setTeacher(e.target.value)}>
              <option value="claude">Claude</option>
              <option value="deepseek">DeepSeek</option>
              <option value="openai">ChatGPT</option>
              <option value="ollama">Ollama (local)</option>
            </select>
          </div>
          <div>
            <label style={{ display: "block", fontSize: 10, fontWeight: 700, color: "var(--text2)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 4, fontFamily: "Nunito, sans-serif" }}>Student (Executor)</label>
            <select style={{ ...fi, width: "100%" }} value={student} onChange={e => setStudent(e.target.value)}>
              <option value="ollama">Ollama (local)</option>
              <option value="claude">Claude</option>
              <option value="deepseek">DeepSeek</option>
            </select>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input style={{ ...fi, flex: 1 }} placeholder="Give the crew a goal…" value={goal}
            onChange={e => setGoal(e.target.value)} onKeyDown={e => e.key === "Enter" && runCrew()} />
          <button className="btn btn-p" disabled={running} onClick={runCrew} style={{ whiteSpace: "nowrap" }}>
            {running ? "⏳ Running…" : "▶ Run Crew"}
          </button>
        </div>
      </div>

      {/* Skip Console */}
      <div className="sh"><span className="st">Skip Console</span><div className="sl"></div><span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)" }}>EVALUATOR · LOCAL</span></div>
      <div style={{ background: "#111", borderRadius: 10, padding: "12px 14px", marginBottom: 14, boxShadow: "var(--puff-sm)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <span style={{ fontFamily: "DM Mono, monospace", fontSize: 10, color: "#666" }}>skip@theone:~$</span>
          <div style={{ display: "flex", gap: 6 }}>
            <button className="chip" style={{ fontSize: 9, padding: "3px 9px", background: "#222", borderColor: "#333", color: "#999" }} onClick={() => setSkipLog(["$ console cleared"])}>Clear</button>
          </div>
        </div>
        <div ref={logRef} style={{ fontFamily: "DM Mono, monospace", fontSize: 11, color: "#7ec67e", lineHeight: 1.9, maxHeight: 180, overflowY: "auto" }}>
          {skipLog.map((l, i) => (
            <div key={i} style={{ color: l.startsWith("$ ✗") || l.startsWith("  ✗") ? "#f87171" : l.startsWith("$ ✓") ? "#86efac" : l.startsWith("  ▸") ? "#7ecfcf" : "#7ec67e" }}>{l}</div>
          ))}
          {running && <div style={{ color: "#a78bfa" }}>$ <span style={{ animation: "blink 1s infinite" }}>_</span></div>}
        </div>
      </div>

      {/* Backpack */}
      <div className="sh"><span className="st">Backpack</span><div className="sl"></div><span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)" }}>{backpack.length} SAVED PATTERNS</span></div>
      <div className="section-card">
        {backpack.length === 0 ? (
          <div style={{ color: "var(--text3)", fontSize: 12, fontWeight: 600 }}>Run a goal to save patterns here. Successful crew runs are stored automatically.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {backpack.map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", background: "var(--bg)", border: "2px solid var(--border)", borderRadius: 8 }}>
                <div style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--green)", flexShrink: 0 }} />
                <div style={{ flex: 1, fontSize: 12, fontWeight: 700, color: "var(--text)", fontFamily: "Nunito, sans-serif" }}>{item.text}</div>
                <div style={{ fontSize: 9, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>{item.saved_at}</div>
                <button style={{ fontSize: 10, background: "none", border: "none", cursor: "pointer", color: "var(--text3)" }} onClick={() => { const next = backpack.filter((_, j) => j !== i); setBackpack(next); localStorage.setItem("theone_backpack", JSON.stringify(next)); }}>✕</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </WorkspaceShell>
  );
}
