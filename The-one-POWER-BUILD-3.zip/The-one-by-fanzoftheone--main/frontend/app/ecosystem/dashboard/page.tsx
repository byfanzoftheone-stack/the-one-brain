import WorkspaceShell from "../../_components/layout/WorkspaceShell";
import { fetchHealth, fetchSystem, fetchApps, fetchModules, fetchMarketplace, fetchTeacher, fetchStudent } from "@/lib/api";

export const dynamic = "force-dynamic";

export default async function EcosystemDashboardPage() {
  const results = await Promise.allSettled([fetchHealth(), fetchSystem(), fetchApps(), fetchModules(), fetchMarketplace(), fetchTeacher(), fetchStudent()]);
  const [health, system, apps, modules, marketplace, teacher, student] = results.map(r => r.status === "fulfilled" ? r.value : null);

  return (
    <WorkspaceShell title="Ecosystem Dashboard" subtitle="Live frontend ↔ backend connection proof">
      {[
        { label: "Backend Health", data: health },
        { label: "System",         data: system },
        { label: "Apps",           data: apps   },
        { label: "Modules",        data: modules },
        { label: "Marketplace",    data: marketplace },
        { label: "Teacher",        data: teacher },
        { label: "Student",        data: student },
      ].map(({ label, data }) => (
        <div key={label} className="section-card" style={{ marginBottom: 10 }}>
          <div className="section-title">{label}</div>
          <pre style={{ fontFamily: "DM Mono, monospace", fontSize: 11, color: "var(--text2)", background: "var(--bg)", borderRadius: 8, padding: 12, overflowX: "auto", lineHeight: 1.6 }}>
            {JSON.stringify(data, null, 2)}
          </pre>
        </div>
      ))}
    </WorkspaceShell>
  );
}
