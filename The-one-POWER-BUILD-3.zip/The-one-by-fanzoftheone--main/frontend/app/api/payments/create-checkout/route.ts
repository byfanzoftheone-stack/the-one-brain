import { proxyJson } from "@/lib/proxy";

export async function POST(req: Request) {
  return proxyJson("/payments/create-checkout", {
    method: "POST",
    body: await req.text(),
  });
}
