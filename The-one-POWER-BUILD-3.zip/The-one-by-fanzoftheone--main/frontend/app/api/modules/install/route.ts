import { proxyJson } from "@/lib/proxy";
export async function POST(req: Request) {
  return proxyJson("/modules/install", {
    method: "POST",
    body: await req.text(),
  });
}
