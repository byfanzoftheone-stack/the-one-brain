import { proxyJson } from "@/lib/proxy";

export async function POST(req: Request) {
  return proxyJson("/execute", {
    method: "POST",
    body: await req.text(),
  });
}
