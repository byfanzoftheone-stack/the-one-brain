"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState, useEffect } from "react";

type Message = { id: string; subject: string; from: string; snippet: string; };

function RightPanel({ connected, unread }: { connected: boolean; unread: number }) {
  return (
    <>
      <div className="rcard">
        <div className="rt">Gmail</div>
        <div className="mrow">
          <span className="mlabel">Status</span>
          <span className="mval" style={{ fontSize: 11, color: connected ? "var(--green)" : "var(--red)" }}>
            {connected ? "Connected" : "Not connected"}
          </span>
        </div>
        <div className="mrow"><span className="mlabel">Unread</span><span className="mval">{unread}</span></div>
      </div>
      <div className="rcard">
        <div className="rt">Actions</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <a href="/api/auth/google" className="btn btn-p" style={{ textAlign: "center", textDecoration: "none", fontSize: 11 }}>
            🔗 Connect Gmail
          </a>
        </div>
      </div>
    </>
  );
}

export default function GmailPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [connected, setConnected] = useState(false);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Message | null>(null);

  useEffect(() => {
    fetch("/api/gmail/digest")
      .then(r => r.json())
      .then(d => {
        if (d.status === "ok") {
          setConnected(true);
          setMessages(d.recent || []);
          setUnread(d.unread_estimate || 0);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <WorkspaceShell title="Gmail Agent" subtitle="Read inbox · Digest · Labels · Daily summary" rightPanel={<RightPanel connected={connected} unread={unread} />}>

      {!connected && (
        <div className="section-card" style={{ borderLeft: "4px solid var(--orange)" }}>
          <div className="section-title">Connect Gmail</div>
          <p style={{ fontSize: 13, color: "var(--text2)", fontWeight: 600, marginBottom: 14, lineHeight: 1.6 }}>
            Gmail is not connected yet. Click below to authorize THE ONE to read your inbox.
            You'll need <code style={{ background: "var(--bg)", padding: "1px 6px", borderRadius: 4, fontSize: 11 }}>GOOGLE_CLIENT_ID</code>, <code style={{ background: "var(--bg)", padding: "1px 6px", borderRadius: 4, fontSize: 11 }}>GOOGLE_CLIENT_SECRET</code>, and <code style={{ background: "var(--bg)", padding: "1px 6px", borderRadius: 4, fontSize: 11 }}>GOOGLE_REDIRECT_URI</code> set on Railway.
          </p>
          <a href="/api/auth/google" className="btn btn-p" style={{ textDecoration: "none", display: "inline-block" }}>
            🔗 Connect Google Account
          </a>
        </div>
      )}

      {loading && (
        <div className="section-card"><div style={{ color: "var(--text3)", fontSize: 12 }}>Loading inbox...</div></div>
      )}

      {connected && !loading && (
        <>
          <div className="sh"><span className="st">Recent Messages</span><div className="sl"></div><span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)" }}>{messages.length} SHOWN</span></div>

          <div style={{ display: "grid", gridTemplateColumns: selected ? "1fr 1fr" : "1fr", gap: 12 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {messages.length === 0 ? (
                <div className="section-card"><div style={{ color: "var(--text3)", fontSize: 12 }}>No messages found.</div></div>
              ) : messages.map(m => (
                <div key={m.id} className="panel-card" style={{ cursor: "pointer", borderLeft: selected?.id === m.id ? "4px solid #111" : undefined }} onClick={() => setSelected(selected?.id === m.id ? null : m)}>
                  <div style={{ fontSize: 12, fontWeight: 800, color: "var(--text)", marginBottom: 3, fontFamily: "Nunito, sans-serif" }}>{m.subject || "(no subject)"}</div>
                  <div style={{ fontSize: 10, color: "var(--blue)", fontWeight: 700, marginBottom: 4 }}>{m.from}</div>
                  <div style={{ fontSize: 11, color: "var(--text2)", fontWeight: 600, lineHeight: 1.5 }}>{m.snippet}</div>
                </div>
              ))}
            </div>

            {selected && (
              <div className="section-card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                  <div className="section-title" style={{ marginBottom: 0 }}>Message</div>
                  <button className="btn btn-s" style={{ fontSize: 10, padding: "4px 10px" }} onClick={() => setSelected(null)}>✕ Close</button>
                </div>
                <div style={{ fontSize: 13, fontWeight: 800, color: "#111", fontFamily: "Nunito, sans-serif", marginBottom: 6 }}>{selected.subject}</div>
                <div style={{ fontSize: 11, color: "var(--blue)", fontWeight: 700, marginBottom: 10 }}>{selected.from}</div>
                <div style={{ fontSize: 12, color: "var(--text2)", fontWeight: 600, lineHeight: 1.7, background: "var(--bg)", borderRadius: 8, padding: 12 }}>{selected.snippet}</div>
                <div style={{ display: "flex", gap: 6, marginTop: 14 }}>
                  <button className="btn btn-s" style={{ fontSize: 11 }}>↩ Reply</button>
                  <button className="btn btn-s" style={{ fontSize: 11 }}>🗄 Archive</button>
                  <button className="btn btn-d" style={{ fontSize: 11 }}>🗑 Delete</button>
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </WorkspaceShell>
  );
}
