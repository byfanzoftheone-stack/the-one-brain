"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useEffect, useState } from "react";

const DEFAULT_URL = "https://fanzspot-production.up.railway.app";
const PROXY_BASE = "/api/warehouse"; // routes through our backend — no CORS
const API_KEY     = "theone_warehouse_url";
const fi = { width: "100%", background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "9px 11px", color: "var(--text)", fontFamily: "Nunito Sans, sans-serif", fontSize: 12, fontWeight: 600, outline: "none" } as const;
const fl = { display: "block" as const, fontSize: 10, fontWeight: 700, color: "var(--text2)", textTransform: "uppercase" as const, letterSpacing: "0.5px", marginBottom: 4, fontFamily: "Nunito, sans-serif" };

function fmtDate(s?: string) {
  if (!s) return "—";
  try { return new Date(s).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); }
  catch { return s; }
}

export default function WarehousePage() {
  const [base, setBase]               = useState(DEFAULT_URL);
  const [inputUrl, setInputUrl]       = useState(DEFAULT_URL);
  const [status, setStatus]           = useState<"idle"|"load"|"ok"|"err">("idle");
  const [statusMsg, setStatusMsg]     = useState("not connected");
  const [tenants, setTenants]         = useState<any[]>([]);
  const [builds, setBuilds]           = useState<any[]>([]);
  const [tenantName, setTenantName]   = useState("");
  const [tenantSlug, setTenantSlug]   = useState("");
  const [selectedTenant, setSelectedTenant] = useState("");
  const [executing, setExecuting]     = useState(false);
  const [panel, setPanel]             = useState<string|null>(null);
  const [corsNote, setCorsNote]       = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(API_KEY) || DEFAULT_URL;
    setBase(saved); setInputUrl(saved);
    ping(saved);
  }, []);

  async function ping(url?: string) {
    // Use our backend proxy — completely avoids CORS
    setStatus("load"); setStatusMsg("connecting via proxy…"); setCorsNote(false);
    try {
      const r = await fetch("/api/warehouse/health");
      if (r.ok) {
        const d = await r.json();
        if (d.status === "connected") {
          setStatus("ok"); setStatusMsg("connected via proxy ✓");
          loadTenants(); loadBuilds();
        } else {
          setStatus("err"); setStatusMsg("proxy error: " + (d.detail || "unknown"));
        }
      } else {
        // Proxy is down — try direct (will show CORS note if blocked)
        const u2 = (url ?? base).replace(/\/$/, "");
        try {
          const r2 = await fetch(`${u2}/api/health`, { mode: "cors" });
          if (r2.ok) { setStatus("ok"); setStatusMsg("direct connected ✓"); loadTenants(u2); loadBuilds(u2); }
          else { setStatus("err"); setStatusMsg(`HTTP ${r.status}`); }
        } catch (e2: any) {
          setStatus("err"); setStatusMsg("CORS blocked — proxy also down"); setCorsNote(true);
        }
      }
    } catch {
      setStatus("err"); setStatusMsg("backend offline");
    }
  }

  function save() {
    const u = inputUrl.replace(/\/$/, "");
    setBase(u); localStorage.setItem(API_KEY, u); ping(u);
  }

  async function apiFetch(path: string, opts: RequestInit = {}) {
    const r = await fetch(`${base.replace(/\/$/, "")}${path}`, { headers: { "Content-Type": "application/json" }, ...opts });
    if (!r.ok) throw new Error(String(r.status));
    return r.json();
  }

  async function loadTenants(url?: string) {
    try {
      const r = await fetch("/api/warehouse/tenants");
      if (r.ok) { const d = await r.json(); setTenants(Array.isArray(d) ? d : d?.tenants ?? []); return; }
    } catch {}
    // Direct fallback
    try {
      const u = (url ?? base).replace(/\/$/, "");
      const d = await (await fetch(`${u}/api/tenants`, { mode: "cors" })).json();
      setTenants(Array.isArray(d) ? d : d?.tenants ?? []);
    } catch {}
  }

  async function loadBuilds(url?: string) {
    try {
      const r = await fetch("/api/warehouse/builds");
      if (r.ok) { const d = await r.json(); setBuilds(Array.isArray(d) ? d : d?.builds ?? []); return; }
    } catch {}
    // Direct fallback
    try {
      const u = (url ?? base).replace(/\/$/, "");
      const d = await (await fetch(`${u}/api/builds`, { mode: "cors" })).json();
      setBuilds(Array.isArray(d) ? d : d?.builds ?? []);
    } catch {}
  }

  async function createTenant() {
    if (!tenantName.trim()) return;
    const slug = tenantSlug || tenantName.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
    try { await apiFetch("/api/tenants", { method: "POST", body: JSON.stringify({ business_name: tenantName, slug }) }); setTenantName(""); setTenantSlug(""); loadTenants(); }
    catch (e: any) { alert("Error: " + e.message); }
  }

  async function lockAndExecute() {
    if (!selectedTenant) { alert("Select a tenant first"); return; }
    setExecuting(true);
    try { await apiFetch("/api/builds", { method: "POST", body: JSON.stringify({ tenant_id: selectedTenant, status: "pending" }) }); loadBuilds(); setPanel("builds"); }
    catch (e: any) { alert("Build error: " + e.message); }
    setExecuting(false);
  }

  const sc = { idle: "var(--text3)", load: "var(--gold)", ok: "var(--green)", err: "var(--red)" } as const;

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">FanzSpot API</div>
          <div className="mrow"><span className="mlabel">Status</span><span style={{ fontSize: 11, color: sc[status], fontWeight: 800 }}>{statusMsg}</span></div>
          <div className="mrow"><span className="mlabel">Tenants</span><span className="mval">{tenants.length}</span></div>
          <div className="mrow"><span className="mlabel">Builds</span><span className="mval">{builds.length}</span></div>
          <div style={{ marginTop: 10 }}>
            <a href="https://fanzspot-production.up.railway.app/docs" target="_blank" rel="noreferrer" className="btn btn-s" style={{ fontSize: 10, textDecoration: "none", display: "block", textAlign: "center" }}>⚡ API Docs</a>
          </div>
        </div>
        <div className="rcard">
          <div className="rt">Nodes</div>
          {["Config", "Tenants", "Intake", "Builds"].map(n => (
            <div key={n} className="mrow" style={{ cursor: "pointer" }} onClick={() => setPanel(panel === n.toLowerCase() ? null : n.toLowerCase())}>
              <span className="mlabel">{n}</span><span style={{ fontSize: 10, color: "var(--blue)", fontWeight: 700 }}>⤢</span>
            </div>
          ))}
        </div>
      </>
    );
  }

  return (
    <WorkspaceShell title="Warehouse" subtitle={`FanzSpot API · ${DEFAULT_URL}`} rightPanel={<RightPanel />}>

      {/* Connection bar */}
      <div className="section-card" style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", marginBottom: 14 }}>
        <div style={{ flex: "0 0 auto" }}>
          <div className="section-title" style={{ marginBottom: 2 }}>FanzSpot Railway API</div>
          <div style={{ fontSize: 10, color: sc[status], fontWeight: 700 }}>{status === "ok" ? "✓ " : status === "err" ? "✕ " : status === "load" ? "⠸ " : "○ "}{statusMsg}</div>
        </div>
        <input style={{ ...fi, flex: 1, minWidth: 220 }} value={inputUrl} onChange={e => setInputUrl(e.target.value)} placeholder="https://your-api.railway.app" />
        <button className="btn btn-p" style={{ fontSize: 11, flexShrink: 0 }} onClick={save}>Connect</button>
      </div>

      {/* CORS note */}
      {corsNote && (
        <div className="section-card" style={{ borderLeft: "4px solid var(--orange)", marginBottom: 14 }}>
          <div className="section-title" style={{ color: "var(--orange)" }}>CORS Issue Detected</div>
          <p style={{ fontSize: 12, color: "var(--text2)", fontWeight: 600, lineHeight: 1.7 }}>
            The Warehouse API at <strong>{base}</strong> is blocking requests from this frontend.<br />
            On Railway, add this env var to your FanzSpot backend:
          </p>
          <div style={{ fontFamily: "DM Mono, monospace", fontSize: 11, background: "#111", color: "#7ec67e", borderRadius: 8, padding: "10px 14px", margin: "10px 0" }}>
            CORS_ORIGINS={typeof window !== "undefined" ? window.location.origin : "https://your-app.vercel.app"}
          </div>
          <p style={{ fontSize: 11, color: "var(--text3)", fontWeight: 600 }}>
            Or set <code>allow_origins=["*"]</code> in the FanzSpot FastAPI CORS middleware for development.
          </p>
        </div>
      )}

      {/* 4 node cards */}
      <div className="qgrid" style={{ marginBottom: 14 }}>
        {[
          { id: "config",  label: "API Config",  badge: "⚙",  desc: status === "ok" ? "Connected to FanzSpot" : "Set URL above" },
          { id: "tenants", label: "Tenants",      badge: "👤", desc: `${tenants.length} tenant${tenants.length !== 1 ? "s" : ""}` },
          { id: "intake",  label: "Build Intake", badge: "⚡", desc: "Lock & execute builds" },
          { id: "builds",  label: "Builds",       badge: "📦", desc: `${builds.length} record${builds.length !== 1 ? "s" : ""}` },
        ].map(n => (
          <div key={n.id} className="qcard" style={{ borderTop: panel === n.id ? "4px solid #111" : undefined }} onClick={() => setPanel(panel === n.id ? null : n.id)}>
            <span className="qi" style={{ fontSize: 20 }}>{n.badge}</span>
            <span className="ql">{n.label}</span>
            <span className="qs">{n.desc}</span>
          </div>
        ))}
      </div>

      {/* Expanded panels */}
      {panel === "config" && (
        <div className="section-card">
          <div className="section-title">API Configuration</div>
          <div style={{ display: "flex", gap: 8 }}>
            <input style={fi} value={inputUrl} onChange={e => setInputUrl(e.target.value)} placeholder="https://fanzspot-production.up.railway.app" />
            <button className="btn btn-p" style={{ fontSize: 11, flexShrink: 0 }} onClick={save}>Save & Connect</button>
          </div>
          <div style={{ marginTop: 10, fontSize: 11, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>Currently connected to: {base}</div>
        </div>
      )}

      {panel === "tenants" && (
        <div className="section-card">
          <div className="section-title">Tenant Management</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
            <div><label style={fl}>Business Name</label><input style={fi} value={tenantName} onChange={e => { setTenantName(e.target.value); if (!tenantSlug) setTenantSlug(e.target.value.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")); }} placeholder="Acme Corp" /></div>
            <div><label style={fl}>Slug</label><input style={fi} value={tenantSlug} onChange={e => setTenantSlug(e.target.value)} placeholder="acme-corp" /></div>
          </div>
          <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
            <button className="btn btn-p" style={{ fontSize: 11 }} onClick={createTenant}>+ Add Tenant</button>
            <button className="btn btn-s" style={{ fontSize: 11 }} onClick={() => loadTenants()}>↻ Reload</button>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={fl}>Select Tenant for Build</label>
            <select style={fi} value={selectedTenant} onChange={e => setSelectedTenant(e.target.value)}>
              <option value="">— choose —</option>
              {tenants.map((t, i) => <option key={i} value={t.id ?? t.slug}>{t.business_name ?? t.name ?? t.slug}</option>)}
            </select>
          </div>
          {tenants.length > 0 && <ul className="simple-list">{tenants.map((t, i) => <li key={i}>{t.business_name ?? t.slug}</li>)}</ul>}
        </div>
      )}

      {panel === "intake" && (
        <div className="section-card">
          <div className="section-title">Build Intake — Lock &amp; Execute</div>
          <p style={{ fontSize: 13, color: "var(--text2)", fontWeight: 600, marginBottom: 16, lineHeight: 1.6 }}>Select a tenant then fire a build to FanzSpot.</p>
          <div style={{ marginBottom: 14 }}>
            <label style={fl}>Tenant</label>
            <select style={fi} value={selectedTenant} onChange={e => setSelectedTenant(e.target.value)}>
              <option value="">— choose —</option>
              {tenants.map((t, i) => <option key={i} value={t.id ?? t.slug}>{t.business_name ?? t.slug}</option>)}
            </select>
          </div>
          <button className="btn btn-p" disabled={executing} onClick={lockAndExecute} style={{ fontSize: 13, padding: "12px 22px" }}>
            {executing ? "⏳ Executing…" : "⚡ Lock & Execute"}
          </button>
        </div>
      )}

      {panel === "builds" && (
        <div className="section-card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "13px 18px", borderBottom: "2px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div className="section-title" style={{ marginBottom: 0 }}>Build Records</div>
            <button className="btn btn-s" style={{ fontSize: 11, padding: "5px 11px" }} onClick={() => loadBuilds()}>↻ Refresh</button>
          </div>
          {builds.length === 0 ? (
            <div style={{ textAlign: "center", padding: 26, color: "var(--text3)", fontSize: 12 }}>No builds yet.</div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead><tr>{["ID", "Tenant", "Service", "Status", "Created"].map(h => <th key={h} style={{ fontFamily: "DM Mono, monospace", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--text3)", textAlign: "left", padding: "8px 14px", borderBottom: "2px solid var(--border)", background: "var(--bg)" }}>{h}</th>)}</tr></thead>
              <tbody>
                {builds.map((b, i) => (
                  <tr key={i} style={{ borderBottom: "1px solid var(--border)" }}>
                    <td style={{ padding: "9px 14px", fontFamily: "DM Mono, monospace", fontSize: 11, color: "var(--blue)" }}>{String(b.id).slice(0, 8)}</td>
                    <td style={{ padding: "9px 14px", fontSize: 12, fontWeight: 700 }}>{b.tenant ?? b.tenant_id ?? "—"}</td>
                    <td style={{ padding: "9px 14px", fontSize: 12, color: "var(--text2)" }}>{b.service ?? "—"}</td>
                    <td style={{ padding: "9px 14px" }}>
                      <span style={{ fontFamily: "DM Mono, monospace", fontSize: 10, padding: "2px 8px", borderRadius: 100, fontWeight: 600, textTransform: "uppercase", background: b.status === "done" ? "#f0fdf4" : b.status === "failed" ? "#fff5f5" : "#fff7ed", color: b.status === "done" ? "var(--green)" : b.status === "failed" ? "var(--red)" : "var(--gold)", border: `2px solid ${b.status === "done" ? "#bbf7d0" : b.status === "failed" ? "#fecaca" : "#fed7aa"}` }}>{b.status ?? "pending"}</span>
                    </td>
                    <td style={{ padding: "9px 14px", fontFamily: "DM Mono, monospace", fontSize: 11, color: "var(--text3)" }}>{fmtDate(b.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </WorkspaceShell>
  );
}
