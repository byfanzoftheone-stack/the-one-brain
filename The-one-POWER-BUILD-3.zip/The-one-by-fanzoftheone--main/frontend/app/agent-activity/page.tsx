import WorkspaceShell from "../_components/layout/WorkspaceShell";
import AgentActivityPanel from "@/components/control/AgentActivityPanel";
import { fetchAgentLogs } from "@/lib/api";

export const dynamic = "force-dynamic";

export default async function AgentActivityPage() {
  let logs: any[] = [];
  try { const r = await fetchAgentLogs(); logs = r?.logs ?? []; } catch {}
  return (
    <WorkspaceShell title="Agent Activity" subtitle="Persistent execution history from Railway">
      <AgentActivityPanel logs={logs} />
    </WorkspaceShell>
  );
}
