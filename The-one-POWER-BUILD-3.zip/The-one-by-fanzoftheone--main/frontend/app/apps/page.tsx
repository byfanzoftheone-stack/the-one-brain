"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState, useEffect, useRef } from "react";

type AppStatus = "live" | "building" | "ready" | "paused";

type SavedApp = {
  id:           string;
  name:         string;
  desc:         string;
  status:       AppStatus;
  vercel_url?:  string;
  vercel_project?: string;
  railway_url?: string;
  railway_service_id?: string;
  repo_url?:    string;
  added_at:     string;
};

type DeployLog = { ts: string; msg: string; ok: boolean; };

const STORAGE_KEY = "theone_apps_v2";

const DEFAULTS: SavedApp[] = [
  { id: "subilife", name: "SubiLife", desc: "WRX enthusiast platform — Next.js 14 PWA", status: "live",
    vercel_url: "https://subilife.vercel.app", vercel_project: "subilife",
    repo_url: "https://github.com/tradebitsix/SubiLife", added_at: new Date().toISOString() },
  { id: "not-alone", name: "Not Alone", desc: "Community support platform", status: "building",
    vercel_url: "", repo_url: "", added_at: new Date().toISOString() },
  { id: "nervous-system",  name: "Nervous System",      desc: "IoT & fleet monitoring",        status: "active",   vercel_url: "", repo_url: "", added_at: new Date().toISOString() },
  { id: "fanzo-core",      name: "Fanzo Core Template", desc: "Iron Core microservice scaffold", status: "active",   vercel_url: "", repo_url: "", added_at: new Date().toISOString() },
  { id: "content-engine",  name: "Content Engine",      desc: "AI video pipeline",               status: "building", vercel_url: "", repo_url: "", added_at: new Date().toISOString() },
  { id: "legacy-vault", name: "LegacyVault", desc: "Digital archive project", status: "ready",
    vercel_url: "", repo_url: "", added_at: new Date().toISOString() },
];

const SC: Record<AppStatus, string> = {
  live:     "var(--green)",
  ready:    "var(--blue)",
  building: "var(--orange)",
  paused:   "var(--text3)",
};

const fi = { background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8,
  padding: "9px 11px", fontSize: 12, fontWeight: 600, color: "var(--text)", outline: "none",
  width: "100%", fontFamily: "Nunito Sans, sans-serif" } as const;
const fl = { display: "block" as const, fontSize: 10, fontWeight: 700, color: "var(--text2)",
  textTransform: "uppercase" as const, letterSpacing: "0.5px", marginBottom: 4,
  fontFamily: "Nunito, sans-serif" };

function useApps() {
  const [apps, setApps] = useState<SavedApp[]>([]);
  useEffect(() => {
    try { setApps(JSON.parse(localStorage.getItem(STORAGE_KEY) || "null") ?? DEFAULTS); }
    catch { setApps(DEFAULTS); }
  }, []);
  const save = (next: SavedApp[]) => {
    setApps(next);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch {}
  };
  return { apps, save };
}

export default function AppsPage() {
  const { apps, save }            = useApps();
  const [selected, setSelected]   = useState<SavedApp | null>(null);
  const [adding, setAdding]       = useState(false);
  const [draft, setDraft]         = useState<Partial<SavedApp>>({});
  const [deployLogs, setDeployLogs] = useState<DeployLog[]>([]);
  const [deploying, setDeploying] = useState<"vercel" | "railway" | null>(null);
  const [latestDeploy, setLatestDeploy] = useState<any>(null);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [deployLogs]);

  function addLog(msg: string, ok = true) {
    setDeployLogs(l => [...l, { ts: new Date().toLocaleTimeString(), msg, ok }]);
  }

  async function triggerVercelDeploy(app: SavedApp) {
    if (!app.vercel_project) { addLog("No Vercel project name set — edit the app first", false); return; }
    setDeploying("vercel");
    addLog(`🚀 Triggering Vercel deploy for ${app.vercel_project}…`);
    try {
      const res = await fetch("/api/deploy/vercel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ project_name: app.vercel_project }),
      });
      const data = await res.json();
      if (!res.ok) { addLog(`✕ ${data.detail || "Deploy failed"}`, false); return; }
      addLog(`✓ Deploy triggered — ID: ${data.deploy_id}`);
      addLog(`↗ URL: https://${data.url}`);
      pollVercelStatus(data.deploy_id, app);
    } catch (e: any) { addLog(`✕ Error: ${e.message}`, false); }
    setDeploying(null);
  }

  async function pollVercelStatus(deployId: string, app: SavedApp) {
    for (let i = 0; i < 12; i++) {
      await new Promise(r => setTimeout(r, 5000));
      try {
        const res  = await fetch(`/api/deploy/vercel/status/${deployId}`);
        const data = await res.json();
        addLog(`  State: ${data.state}`);
        if (data.state === "READY") {
          addLog(`✓ Deployed! Live at https://${data.url}`);
          save(apps.map(a => a.id === app.id ? { ...a, status: "live" } : a));
          setSelected(prev => prev?.id === app.id ? { ...prev, status: "live" } : prev);
          break;
        }
        if (data.state === "ERROR") { addLog("✕ Deploy failed on Vercel", false); break; }
      } catch {}
    }
  }

  async function triggerRailwayDeploy(app: SavedApp) {
    if (!app.railway_service_id) { addLog("No Railway service ID set — edit the app first", false); return; }
    setDeploying("railway");
    addLog(`🚂 Triggering Railway redeploy for service ${app.railway_service_id}…`);
    try {
      const res  = await fetch("/api/deploy/railway", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ service_id: app.railway_service_id }),
      });
      const data = await res.json();
      if (!res.ok) { addLog(`✕ ${data.detail || "Deploy failed"}`, false); return; }
      addLog(`✓ Railway redeploy triggered`);
    } catch (e: any) { addLog(`✕ Error: ${e.message}`, false); }
    setDeploying(null);
  }

  async function fetchLatestDeploy(app: SavedApp) {
    if (!app.vercel_project) return;
    try {
      const res  = await fetch(`/api/deploy/vercel/latest/${app.vercel_project}`);
      const data = await res.json();
      setLatestDeploy(data);
    } catch {}
  }

  function selectApp(app: SavedApp) {
    setSelected(prev => prev?.id === app.id ? null : app);
    setDeployLogs([]);
    setLatestDeploy(null);
    fetchLatestDeploy(app);
  }

  function updateField(key: keyof SavedApp, value: string) {
    if (!selected) return;
    const updated = { ...selected, [key]: value };
    setSelected(updated);
    save(apps.map(a => a.id === updated.id ? updated : a));
  }

  function addApp() {
    if (!draft.name) return;
    const app: SavedApp = {
      id:         draft.name.toLowerCase().replace(/\s+/g, "-"),
      name:       draft.name,
      desc:       draft.desc || "",
      status:     (draft.status as AppStatus) || "ready",
      vercel_url: draft.vercel_url || "",
      vercel_project: draft.vercel_project || "",
      railway_url: draft.railway_url || "",
      railway_service_id: draft.railway_service_id || "",
      repo_url:   draft.repo_url || "",
      added_at:   new Date().toISOString(),
    };
    save([...apps, app]);
    setDraft({});
    setAdding(false);
  }

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">Apps</div>
          {apps.map(a => (
            <div key={a.id} className="mrow" style={{ cursor: "pointer" }} onClick={() => selectApp(a)}>
              <span className="mlabel">{a.name}</span>
              <span style={{ fontSize: 9, fontWeight: 800, color: SC[a.status], fontFamily: "Nunito, sans-serif" }}>{a.status.toUpperCase()}</span>
            </div>
          ))}
        </div>
        <div className="rcard">
          <div className="rt">Actions</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <button className="btn btn-p" style={{ fontSize: 11 }} onClick={() => { setAdding(true); setSelected(null); }}>+ Add App</button>
            <a href="/builder" className="btn btn-s" style={{ textAlign: "center", textDecoration: "none", fontSize: 11 }}>⚒ Build New</a>
            <a href="/warehouse" className="btn btn-s" style={{ textAlign: "center", textDecoration: "none", fontSize: 11 }}>📦 Warehouse</a>
          </div>
        </div>
        {selected?.vercel_url && (
          <div className="rcard">
            <div className="rt">Live Deploy</div>
            <a href={selected.vercel_url} target="_blank" rel="noreferrer"
              style={{ display: "block", fontSize: 12, fontWeight: 800, color: "var(--green)",
                textDecoration: "none", wordBreak: "break-all", lineHeight: 1.5 }}>
              ↗ {selected.vercel_url.replace("https://", "")}
            </a>
            {latestDeploy && (
              <div style={{ marginTop: 8, fontSize: 10, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>
                State: {latestDeploy.state}<br />
                {latestDeploy.created_at && new Date(latestDeploy.created_at).toLocaleDateString()}
              </div>
            )}
          </div>
        )}
      </>
    );
  }

  return (
    <WorkspaceShell title="Apps" subtitle="Deploy manager — Vercel · Railway · GitHub" rightPanel={<RightPanel />}>

      {/* Add form */}
      {adding && (
        <div className="section-card" style={{ borderLeft: "4px solid var(--blue)", marginBottom: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14 }}>
            <div className="section-title" style={{ marginBottom: 0 }}>New App</div>
            <button className="btn btn-s" style={{ fontSize: 10, padding: "4px 10px" }} onClick={() => setAdding(false)}>✕</button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
            {[
              { label: "App Name *",      key: "name",               ph: "SubiLife" },
              { label: "Description",     key: "desc",               ph: "What it does" },
              { label: "Vercel URL",      key: "vercel_url",         ph: "https://app.vercel.app" },
              { label: "Vercel Project",  key: "vercel_project",     ph: "project-name-on-vercel" },
              { label: "Railway URL",     key: "railway_url",        ph: "https://app.railway.app" },
              { label: "Railway Svc ID",  key: "railway_service_id", ph: "xxxxxxxx-xxxx-xxxx" },
              { label: "GitHub Repo",     key: "repo_url",           ph: "https://github.com/..." },
            ].map(f => (
              <div key={f.key}>
                <label style={fl}>{f.label}</label>
                <input style={fi} placeholder={f.ph} value={(draft as any)[f.key] || ""}
                  onChange={e => setDraft(d => ({ ...d, [f.key]: e.target.value }))} />
              </div>
            ))}
            <div>
              <label style={fl}>Status</label>
              <select style={fi} value={draft.status || "ready"} onChange={e => setDraft(d => ({ ...d, status: e.target.value as AppStatus }))}>
                <option value="live">Live</option><option value="ready">Ready</option>
                <option value="building">Building</option><option value="paused">Paused</option>
              </select>
            </div>
          </div>
          <button className="btn btn-p" onClick={addApp}>Save App</button>
        </div>
      )}

      {/* App grid + detail */}
      <div className="sh"><span className="st">Ecosystem Apps</span><div className="sl"></div>
        <span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)" }}>{apps.length} APPS</span>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: selected ? "280px 1fr" : "repeat(auto-fill,minmax(210px,1fr))", gap: 12, marginBottom: 18 }}>

        {/* App cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {apps.map(app => (
            <div key={app.id} className="panel-card" onClick={() => selectApp(app)}
              style={{ cursor: "pointer", borderTop: `4px solid ${SC[app.status]}`,
                borderLeft: selected?.id === app.id ? "4px solid #111" : undefined, transition: "all .15s" }}>
              <div className="card-label" style={{ color: SC[app.status] }}>{app.status.toUpperCase()}</div>
              <div className="card-value" style={{ fontSize: 14 }}>{app.name}</div>
              <div className="card-note">{app.desc}</div>
              {app.vercel_url && (
                <div style={{ marginTop: 6, fontSize: 9, color: "var(--blue)", fontFamily: "DM Mono, monospace",
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  ↗ {app.vercel_url.replace("https://", "")}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Detail + deploy panel */}
        {selected && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>

            {/* Live link banner */}
            {selected.vercel_url && (
              <div style={{ background: "#f0fdf4", border: "2px solid #bbf7d0", borderRadius: 12,
                padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div>
                  <div style={{ fontSize: 10, fontWeight: 700, color: "var(--green)", marginBottom: 3, textTransform: "uppercase" }}>Latest Deploy</div>
                  <a href={selected.vercel_url} target="_blank" rel="noreferrer"
                    style={{ fontSize: 14, fontWeight: 900, color: "var(--green)", textDecoration: "none", fontFamily: "Nunito, sans-serif" }}>
                    ↗ Open {selected.name}
                  </a>
                </div>
                {latestDeploy?.state && (
                  <span className="cbadge" style={{ background: latestDeploy.state === "READY" ? "#f0fdf4" : "#fff7ed",
                    color: latestDeploy.state === "READY" ? "var(--green)" : "var(--orange)",
                    border: `2px solid ${latestDeploy.state === "READY" ? "#bbf7d0" : "#fed7aa"}` }}>
                    {latestDeploy.state}
                  </span>
                )}
              </div>
            )}

            {/* Edit fields */}
            <div className="section-card">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                <div className="section-title" style={{ marginBottom: 0 }}>{selected.name}</div>
                <button className="btn btn-s" style={{ fontSize: 10, padding: "4px 10px" }} onClick={() => setSelected(null)}>✕</button>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                {[
                  { label: "Vercel URL",     key: "vercel_url",         ph: "https://app.vercel.app" },
                  { label: "Vercel Project", key: "vercel_project",     ph: "project-name-on-vercel" },
                  { label: "Railway URL",    key: "railway_url",        ph: "https://app.railway.app" },
                  { label: "Railway Svc ID", key: "railway_service_id", ph: "xxxxxxxx-xxxx-xxxx" },
                  { label: "GitHub Repo",    key: "repo_url",           ph: "https://github.com/..." },
                ].map(f => (
                  <div key={f.key}>
                    <label style={fl}>{f.label}</label>
                    <input style={fi} placeholder={f.ph} value={(selected as any)[f.key] || ""}
                      onChange={e => updateField(f.key as keyof SavedApp, e.target.value)} />
                  </div>
                ))}
              </div>

              {/* Deploy buttons */}
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button className="btn btn-p" disabled={!!deploying}
                  onClick={() => triggerVercelDeploy(selected)}
                  style={{ fontSize: 11, background: deploying === "vercel" ? "var(--orange)" : "#111" }}>
                  {deploying === "vercel" ? "⏳ Deploying…" : "🚀 Deploy to Vercel"}
                </button>
                <button className="btn btn-s" disabled={!!deploying}
                  onClick={() => triggerRailwayDeploy(selected)} style={{ fontSize: 11 }}>
                  {deploying === "railway" ? "⏳ Deploying…" : "🚂 Redeploy Railway"}
                </button>
                {selected.repo_url && (
                  <a href={selected.repo_url} target="_blank" rel="noreferrer"
                    className="btn btn-s" style={{ fontSize: 11, textDecoration: "none" }}>⎇ GitHub</a>
                )}
                {selected.railway_url && (
                  <a href={`${selected.railway_url}/docs`} target="_blank" rel="noreferrer"
                    className="btn btn-s" style={{ fontSize: 11, textDecoration: "none" }}>⚡ API</a>
                )}
                <button className="btn btn-d" style={{ fontSize: 10, marginLeft: "auto" }}
                  onClick={() => { save(apps.filter(a => a.id !== selected.id)); setSelected(null); }}>
                  Remove
                </button>
              </div>
            </div>

            {/* Deploy log */}
            {deployLogs.length > 0 && (
              <div className="section-card" style={{ padding: 0, overflow: "hidden" }}>
                <div style={{ padding: "10px 14px", borderBottom: "2px solid var(--border)", fontSize: 11, fontWeight: 800, color: "#111", fontFamily: "Nunito, sans-serif" }}>
                  Deploy Log
                </div>
                <div ref={logRef} style={{ background: "#111", padding: "12px 14px", maxHeight: 200,
                  overflowY: "auto", fontFamily: "DM Mono, monospace", fontSize: 11, lineHeight: 1.9 }}>
                  {deployLogs.map((l, i) => (
                    <div key={i} style={{ color: l.ok ? "#7ec67e" : "#f87171" }}>
                      <span style={{ color: "#666", marginRight: 8 }}>{l.ts}</span>{l.msg}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </WorkspaceShell>
  );
}
