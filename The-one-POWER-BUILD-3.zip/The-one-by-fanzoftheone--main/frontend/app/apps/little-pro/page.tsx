export default function LittleProPage() {
  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="mx-auto max-w-4xl space-y-6">
        <div>
          <div className="text-sm uppercase tracking-widest text-white/50">App</div>
          <h1 className="text-4xl font-bold">Little Pro</h1>
          <p className="mt-2 text-white/60">
            First live app inside THE ONE ecosystem.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="text-lg font-semibold">Learning Flow</div>
            <div className="mt-2 text-white/60">Prompts, reflection, growth paths.</div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="text-lg font-semibold">Agent Interaction</div>
            <div className="mt-2 text-white/60">Teacher / student / skip model later connects here.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
