"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useEffect, useMemo, useState } from "react";
import { runMission } from "@/lib/api";

type PlanMap = Record<string, string[]>;
type SavedRun = { id: string; goal: string; timestamp: string; progress: number; completed: number; total: number; };

const KEYS = { checked: "theone.mission.checked", plan: "theone.mission.plan", result: "theone.mission.result", runs: "theone.mission.runs" };
const DEFAULT_GOAL = "Clean emails, organize folders, review apps, catch up missed deadlines";

function normalizePlan(result: any): PlanMap {
  const nested = result?.plan?.plan;
  if (!nested) return {};
  if (Array.isArray(nested)) return { tasks: nested.map(String) };
  if (typeof nested !== "object") return {};
  const out: PlanMap = {};
  for (const [k, v] of Object.entries(nested)) out[k] = Array.isArray(v) ? v.map(String) : [];
  return out;
}

function titleCase(s: string) { return s.charAt(0).toUpperCase() + s.slice(1); }

export default function MissionPage() {
  const [loading, setLoading] = useState(false);
  const [goal, setGoal] = useState(DEFAULT_GOAL);
  const [result, setResult] = useState<any>(null);
  const [plan, setPlan] = useState<PlanMap>({});
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const [recentRuns, setRecentRuns] = useState<SavedRun[]>([]);

  useEffect(() => {
    try {
      const sc = localStorage.getItem(KEYS.checked); if (sc) setChecked(JSON.parse(sc));
      const sp = localStorage.getItem(KEYS.plan);    if (sp) setPlan(JSON.parse(sp));
      const sr = localStorage.getItem(KEYS.result);  if (sr) setResult(JSON.parse(sr));
      const rr = localStorage.getItem(KEYS.runs);    if (rr) setRecentRuns(JSON.parse(rr));
    } catch {}
  }, []);

  useEffect(() => { try { localStorage.setItem(KEYS.checked, JSON.stringify(checked)); } catch {} }, [checked]);
  useEffect(() => { try { localStorage.setItem(KEYS.plan, JSON.stringify(plan)); } catch {} }, [plan]);
  useEffect(() => { try { localStorage.setItem(KEYS.result, JSON.stringify(result)); } catch {} }, [result]);
  useEffect(() => { try { localStorage.setItem(KEYS.runs, JSON.stringify(recentRuns)); } catch {} }, [recentRuns]);

  const taskEntries = useMemo(() => {
    const out: { id: string; section: string; text: string }[] = [];
    for (const [s, items] of Object.entries(plan)) items.forEach((text, i) => out.push({ id: `${s}-${i}`, section: s, text }));
    return out;
  }, [plan]);

  const totalTasks = taskEntries.length;
  const completedTasks = taskEntries.filter(t => checked[t.id]).length;
  const progress = totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0;

  async function handleRun() {
    setLoading(true);
    try {
      const r = await runMission({ action: "run_mission", source: "frontend-mission-page", goal, timestamp: new Date().toISOString() });
      const normalized = normalizePlan(r);
      setResult(r); setPlan(normalized); setChecked({});
      setRecentRuns(prev => [{ id: crypto.randomUUID(), goal, timestamp: r?.plan?.input?.timestamp || new Date().toISOString(), progress: 0, completed: 0, total: Object.values(normalized).flat().length }, ...prev].slice(0, 8));
    } catch { alert("Mission failed"); }
    setLoading(false);
  }

  function clearMission() { setPlan({}); setResult(null); setChecked({}); try { [KEYS.checked, KEYS.plan, KEYS.result].forEach(k => localStorage.removeItem(k)); } catch {} }

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">Progress</div>
          <div style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, fontWeight: 700, marginBottom: 4 }}><span>Overall</span><span style={{ textShadow: "var(--puff-xs)" }}>{progress}%</span></div>
            <div className="pbw"><div className="pb" style={{ width: `${progress}%` }}></div></div>
          </div>
          <div className="mrow"><span className="mlabel">Completed</span><span className="mval" style={{ color: "var(--green)" }}>{completedTasks}</span></div>
          <div className="mrow"><span className="mlabel">Remaining</span><span className="mval">{totalTasks - completedTasks}</span></div>
          <div className="mrow"><span className="mlabel">Total</span><span className="mval">{totalTasks}</span></div>
        </div>
        <div className="rcard">
          <div className="rt">Recent Runs</div>
          {recentRuns.slice(0,3).map(r => (
            <div key={r.id} style={{ padding: "7px 0", borderBottom: "2px solid var(--border)" }}>
              <div style={{ fontSize: 9, color: "var(--text3)", fontWeight: 600, fontFamily: "DM Mono, monospace" }}>{r.timestamp.slice(0,10)}</div>
              <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text)", fontFamily: "Nunito, sans-serif" }}>{r.goal.slice(0,40)}…</div>
            </div>
          ))}
          {recentRuns.length === 0 && <div style={{ fontSize: 11, color: "var(--text3)", fontWeight: 600 }}>No runs yet.</div>}
        </div>
      </>
    );
  }

  return (
    <WorkspaceShell title="Mission Dashboard" subtitle="Turn your backlog into a structured action plan" rightPanel={<RightPanel />}>
      <div className="section-card">
        <div className="section-title">Mission Goal</div>
        <textarea value={goal} onChange={e => setGoal(e.target.value)} rows={3}
          style={{ width: "100%", background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "9px 11px", color: "var(--text)", fontSize: 13, fontWeight: 600, outline: "none", resize: "vertical", fontFamily: "Nunito Sans, sans-serif" }} />
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <button onClick={handleRun} disabled={loading} className="btn btn-p">{loading ? "Running…" : "▶ Run Mission"}</button>
          <button onClick={clearMission} className="btn btn-s">Clear</button>
        </div>
        {totalTasks > 0 && (
          <div style={{ marginTop: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, fontWeight: 700, marginBottom: 4 }}><span>Progress</span><span>{progress}%</span></div>
            <div className="pbw"><div className="pb" style={{ width: `${progress}%` }}></div></div>
            <div style={{ fontSize: 10, color: "var(--text3)", fontWeight: 600, marginTop: 4 }}>{completedTasks} of {totalTasks} tasks completed</div>
          </div>
        )}
      </div>

      {result && (
        <div className="section-card">
          <div className="section-title">Live Run Summary</div>
          <div className="grid-cards">
            {[{ label: "Crew", v: result.crew ?? "Unknown" }, { label: "Status", v: result.result?.status ?? result.status ?? "Unknown" }, { label: "Tools Run", v: String(result.result?.executed_tools ?? result.execution?.length ?? 0) }].map(c => (
              <div key={c.label} className="panel-card"><div className="card-label">{c.label}</div><div className="card-value" style={{ fontSize: 16 }}>{c.v}</div></div>
            ))}
          </div>
        </div>
      )}

      {Object.keys(plan).length > 0 && (
        <div className="section-card">
          <div className="section-title">Action Breakdown</div>
          {Object.entries(plan).map(([section, items]) => (
            <div key={section} style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: "#111", textShadow: "var(--puff-xs)", marginBottom: 8, fontFamily: "Nunito, sans-serif" }}>{titleCase(section)}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                {items.map((item, i) => {
                  const id = `${section}-${i}`;
                  const done = !!checked[id];
                  return (
                    <button key={id} onClick={() => setChecked(p => ({ ...p, [id]: !p[id] }))}
                      style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 13px", borderRadius: 9, border: `2px solid ${done ? "#bbf7d0" : "var(--border)"}`, background: done ? "#f0fdf4" : "#fff", cursor: "pointer", textAlign: "left", fontSize: 12, fontWeight: 700, color: "var(--text)", boxShadow: "var(--sh)", transition: "all .15s", fontFamily: "Nunito, sans-serif" }}>
                      <span>{item}</span>
                      <span style={{ fontSize: 16, color: done ? "var(--green)" : "var(--text3)" }}>{done ? "✓" : "○"}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </WorkspaceShell>
  );
}
