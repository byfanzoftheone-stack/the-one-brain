"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import SectionCard from "../_components/cards/SectionCard";
import { useState, useEffect } from "react";

type EnvStatus = { key: string; status: "set" | "missing"; label: string; hint: string; };

export default function SettingsPage() {
  const [envStatus, setEnvStatus]   = useState<EnvStatus[]>([]);
  const [orchStatus, setOrchStatus] = useState<any>(null);
  const [health, setHealth]         = useState<any>(null);
  const [checking, setChecking]     = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/orchestrator/status").then(r => r.json()).catch(() => null),
      fetch("/api/health").then(r => r.json()).catch(() => null),
    ]).then(([orch, h]) => {
      setOrchStatus(orch);
      setHealth(h);
      setEnvStatus([
        { key: "NEXT_PUBLIC_API_URL",  status: h ? "set" : "missing",                               label: "Backend URL (Vercel)",   hint: "Your Railway backend URL" },
        { key: "ANTHROPIC_API_KEY",    status: orch?.ai_provider === "claude"   ? "set" : "missing", label: "Anthropic API Key",     hint: "Enables Claude as AI brain" },
        { key: "DEEPSEEK_API_KEY",     status: orch?.ai_provider === "deepseek" ? "set" : "missing", label: "DeepSeek API Key",      hint: "Alternative AI brain" },
        { key: "VERCEL_TOKEN",         status: "missing",                                             label: "Vercel Token",          hint: "Enables deploy triggers from Apps page" },
        { key: "RAILWAY_TOKEN",        status: "missing",                                             label: "Railway Token",         hint: "Enables Railway redeploy from Apps page" },
        { key: "DATABASE_URL",         status: h?.status === "ok" ? "set" : "missing",               label: "Database URL",          hint: "Railway Postgres connection" },
        { key: "WAREHOUSE_URL",        status: "missing",                                             label: "Warehouse URL",         hint: "FanzSpot Railway URL for proxy" },
        { key: "GOOGLE_CLIENT_ID",     status: "missing",                                             label: "Google Client ID",      hint: "Gmail OAuth" },
      ]);
      setChecking(false);
    });
  }, []);

  const fi = { background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "9px 11px", fontSize: 12, fontWeight: 600, color: "var(--text)", outline: "none", width: "100%", fontFamily: "Nunito Sans, sans-serif" } as const;

  const setCount = envStatus.filter(e => e.status === "set").length;
  const total    = envStatus.length;

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">System Health</div>
          {[
            { label: "Backend",    val: health?.status === "ok" ? "Online" : "Offline",        ok: health?.status === "ok" },
            { label: "AI Brain",   val: orchStatus?.ai_provider ?? "checking",                 ok: orchStatus?.ai_provider && orchStatus.ai_provider !== "fallback" },
            { label: "Database",   val: health?.status === "ok" ? "Connected" : "No DB",      ok: health?.status === "ok" },
            { label: "Env Vars",   val: checking ? "Checking…" : `${setCount}/${total}`,       ok: !checking && setCount >= 3 },
          ].map(r => (
            <div key={r.label} className="mrow">
              <span className="mlabel">{r.label}</span>
              <span className="mval" style={{ fontSize: 11, color: r.ok ? "var(--green)" : "var(--orange)" }}>{r.val}</span>
            </div>
          ))}
        </div>
        <div className="rcard">
          <div className="rt">Docs</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {[
              { label: "Vercel Tokens",   url: "https://vercel.com/account/tokens" },
              { label: "Railway Tokens",  url: "https://railway.app/account/tokens" },
              { label: "Anthropic Keys",  url: "https://console.anthropic.com" },
              { label: "DeepSeek Keys",   url: "https://platform.deepseek.com" },
              { label: "Google Console",  url: "https://console.cloud.google.com" },
            ].map(l => (
              <a key={l.label} href={l.url} target="_blank" rel="noreferrer"
                style={{ fontSize: 11, color: "var(--blue)", fontWeight: 700, textDecoration: "none", padding: "5px 0", borderBottom: "1px solid var(--border)" }}>
                ↗ {l.label}
              </a>
            ))}
          </div>
        </div>
      </>
    );
  }

  return (
    <WorkspaceShell title="Settings" subtitle="Environment, providers, and system config" rightPanel={<RightPanel />}>

      {/* Env health bar */}
      <div className="section-card" style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div className="section-title" style={{ marginBottom: 0 }}>Environment Variables</div>
          <span style={{ fontSize: 11, fontWeight: 800, color: setCount >= 3 ? "var(--green)" : "var(--orange)", fontFamily: "Nunito, sans-serif" }}>
            {checking ? "Checking…" : `${setCount}/${total} set`}
          </span>
        </div>
        <div className="pbw"><div className="pb" style={{ width: `${total ? (setCount/total)*100 : 0}%`, background: setCount >= total * 0.7 ? "var(--green)" : "var(--orange)" }} /></div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 14 }}>
          {envStatus.map(e => (
            <div key={e.key} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", background: "var(--bg)", border: `2px solid ${e.status === "set" ? "#bbf7d0" : "var(--border)"}`, borderRadius: 8 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: e.status === "set" ? "var(--green)" : "var(--text3)", flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 800, color: "#111", fontFamily: "DM Mono, monospace" }}>{e.key}</div>
                <div style={{ fontSize: 9, color: "var(--text3)", fontWeight: 600 }}>{e.hint}</div>
              </div>
              <span style={{ fontSize: 9, fontWeight: 800, padding: "2px 8px", borderRadius: 20, background: e.status === "set" ? "#f0fdf4" : "#fff7ed", color: e.status === "set" ? "var(--green)" : "var(--orange)", border: `2px solid ${e.status === "set" ? "#bbf7d0" : "#fed7aa"}`, fontFamily: "Nunito, sans-serif" }}>
                {e.status.toUpperCase()}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Env var setup guide */}
      <SectionCard title="How to Set Env Vars on Railway">
        <div style={{ fontFamily: "DM Mono, monospace", fontSize: 11, background: "#111", color: "#7ec67e", borderRadius: 8, padding: "12px 14px", lineHeight: 1.9 }}>
          <div style={{ color: "#666", marginBottom: 4 }}># Railway → your backend service → Variables</div>
          <div>ANTHROPIC_API_KEY=sk-ant-...</div>
          <div>DEEPSEEK_API_KEY=sk-...</div>
          <div>VERCEL_TOKEN=your_token</div>
          <div>RAILWAY_TOKEN=your_token</div>
          <div>WAREHOUSE_URL=https://fanzspot-production.up.railway.app</div>
          <div>GOOGLE_CLIENT_ID=your_client_id</div>
          <div style={{ color: "#666", marginTop: 4 }}># Vercel → your project → Settings → Environment Variables</div>
          <div>NEXT_PUBLIC_API_URL=https://your-backend.railway.app</div>
        </div>
      </SectionCard>

      <SectionCard title="AI Providers">
        <div className="grid-cards">
          {[
            { name: "Claude",      role: "Teacher · Brain",  color: "var(--purple)", active: orchStatus?.ai_provider === "claude" },
            { name: "DeepSeek",    role: "Teacher · Alt",    color: "var(--blue)",   active: orchStatus?.ai_provider === "deepseek" },
            { name: "Ollama",      role: "Student · Local",  color: "var(--orange)", active: true },
          ].map(p => (
            <div key={p.name} className="panel-card" style={{ borderTop: p.active ? `4px solid ${p.color}` : undefined }}>
              <div className="card-label" style={{ color: p.color }}>{p.role}</div>
              <div className="card-value" style={{ fontSize: 14 }}>{p.name}</div>
              <div className="card-note">{p.active ? "Active" : "Set API key to enable"}</div>
            </div>
          ))}
        </div>
      </SectionCard>
    </WorkspaceShell>
  );
}
