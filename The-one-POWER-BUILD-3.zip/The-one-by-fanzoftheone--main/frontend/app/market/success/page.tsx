"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function SuccessPage() {
  const [product, setProduct] = useState("");

  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get("product") || "your product";
    setProduct(p.replace(/-/g, " "));
  }, []);

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ textAlign: "center", maxWidth: 480 }}>
        <div style={{ fontSize: 64, marginBottom: 24, filter: "drop-shadow(0 0 20px rgba(104,211,145,0.6))", animation: "float 3s ease-in-out infinite" }}>✓</div>
        <h1 style={{ fontFamily: "Syne, sans-serif", fontSize: 36, fontWeight: 900, marginBottom: 16, background: "linear-gradient(135deg, #68d391, #63b3ed)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
          You're in.
        </h1>
        <p style={{ fontSize: 16, color: "rgba(240,244,255,0.6)", lineHeight: 1.7, marginBottom: 32 }}>
          <strong style={{ color: "#f0f4ff", textTransform: "capitalize" }}>{product}</strong> is now active on your account. Check your email for setup instructions.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <Link href="/market" style={{ padding: "12px 24px", borderRadius: 10, background: "rgba(99,179,237,0.12)", border: "1px solid rgba(99,179,237,0.3)", color: "#63b3ed", textDecoration: "none", fontWeight: 700 }}>Browse More →</Link>
          <Link href="/dashboard" style={{ padding: "12px 24px", borderRadius: 10, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "#f0f4ff", textDecoration: "none", fontWeight: 700 }}>Go to Dashboard</Link>
        </div>
      </div>
    </div>
  );
}
