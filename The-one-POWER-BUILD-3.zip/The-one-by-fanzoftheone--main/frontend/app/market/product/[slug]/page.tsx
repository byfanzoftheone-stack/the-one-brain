"use client";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useState } from "react";

const PRODUCTS: Record<string, any> = {
  "three-six-nine-builder": { name: "3-6-9 Builder", price: 59, color: "#63b3ed", icon: "⚡", tagline: "Learn to build by building. No tutorials. No syntax hell. Just choices.", features: ["Teacher agent presents 3 code block options per decision", "Pick level 3 (simple), 6 (intermediate), or 9 (pro)", "All choices stored in your code bank and recycled", "Gets smarter the more you build", "Works with Claude, DeepSeek, or no key"], who: ["Developers learning patterns", "Solo builders who want code fast", "Teams wanting consistent standards"] },
  "nervous-system": { name: "Nervous System", price: 149, color: "#76e4f7", icon: "🧠", tagline: "Infrastructure that thinks. Problems fixed before you know they exist.", features: ["FastAPI receiver — The Ears", "Redis zero-latency queue — The Spine", "AI worker agents — The Brain", "Override API — The Hands", "Docker Compose — one command to run"], who: ["Fleet operators", "Field service companies", "DevOps teams"] },
  "content-engine": { name: "Content Engine", price: 129, color: "#b794f4", icon: "🎬", tagline: "One prompt in. Finished video out.", features: ["Script via Claude or DeepSeek", "Visuals via Leonardo.ai", "Voice via ElevenLabs", "Assembly via FFmpeg", "The Fixer + The Siren avatar profiles included"], who: ["Content creators", "Marketing teams", "Social media agencies"] },
  "construction-ops": { name: "Construction Ops", price: 99, color: "#f6ad55", icon: "🏗️", tagline: "Stop losing jobs to admin.", features: ["Quotes and estimates", "Crew scheduling", "Invoice and payment tracking", "Permit tracking", "Materials management"], who: ["Contractors", "Field service companies", "Roofing and construction"] },
  "email-growth-engine": { name: "Email Growth Engine", price: 79, color: "#68d391", icon: "📧", tagline: "AI email sequences that actually convert.", features: ["AI personalization at scale", "Automated drip sequences", "Analytics and open rates", "Template library"], who: ["SaaS founders", "E-commerce", "Marketing teams"] },
  "little-pro": { name: "Little Pro", price: 49, color: "#ecc94b", icon: "⚒️", tagline: "Personal OS for builders who ship.", features: ["Daily ledger", "Session starter and closer", "Opportunity capture", "No-drift check", "Mastery loop"], who: ["Solo builders", "Indie hackers", "Freelancers"] },
  "fanzo-core": { name: "Fanzo Core", price: 49, color: "#63b3ed", icon: "🔩", tagline: "Iron Core microservice scaffold. One-time purchase.", features: ["Hardened Dockerfile", "Pydantic strict typing", "Health check endpoint", "Defensive error handling", "Integrity test suite"], who: ["Developers", "DevOps engineers", "SaaS builders"] },
  "marketing-automation-app": { name: "Marketing Automation", price: 99, color: "#f6ad55", icon: "📈", tagline: "SEO + Content + Email agents running your growth 24/7.", features: ["SEO agent", "Content agent", "Email agent", "Analytics dashboard"], who: ["Marketing teams", "SaaS companies", "E-commerce"] },
  "seo-automation-app": { name: "SEO Automation", price: 69, color: "#76e4f7", icon: "🔍", tagline: "Rank without effort.", features: ["Keyword research automation", "AI content generation", "On-page optimization", "Backlink tracking"], who: ["Content marketers", "SEO agencies", "SaaS founders"] },
  "play-better": { name: "Play Better", price: 79, color: "#fc8181", icon: "🏆", tagline: "AI coaching platform.", features: ["Session tracking", "Progress metrics", "AI performance analysis", "Athlete profiles", "Data-driven coaching"], who: ["Sports coaches", "Personal trainers", "Athletic programs"] },
  "productivity-tracker": { name: "Productivity Tracker", price: 29, color: "#68d391", icon: "📊", tagline: "Track what matters. Kill drift.", features: ["Daily session tracking", "Goal monitoring", "Pattern detection", "Progress streaks"], who: ["Freelancers", "Solo founders", "Remote workers"] },
  "content-machine": { name: "Content Machine", price: 89, color: "#b794f4", icon: "✍️", tagline: "Never write content manually again.", features: ["AI content generation", "Scheduling automation", "SEO optimization", "News aggregation"], who: ["Content teams", "Bloggers", "Media companies"] },
};

export default function ProductPage() {
  const params  = useParams();
  const slug    = params?.slug as string;
  const product = PRODUCTS[slug] || { name: slug?.replace(/-/g," "), price: 0, color: "#63b3ed", icon: "⬡", tagline: "", features: [], who: [] };
  const [checking, setChecking] = useState(false);

  async function getAccess() {
    setChecking(true);
    try {
      const res  = await fetch("/api/payments/checkout", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product_slug: slug }),
      });
      const data = await res.json();
      if (data.checkout_url) window.location.href = data.checkout_url;
    } catch {}
    setChecking(false);
  }

  return (
    <div style={{ maxWidth: 800, margin: "0 auto", padding: "60px 24px" }}>
      <Link href="/market" style={{ color: "rgba(240,244,255,0.45)", fontSize: 13, textDecoration: "none", display: "block", marginBottom: 40 }}>← Back to Marketplace</Link>
      <div style={{ fontSize: 56, marginBottom: 16, filter: `drop-shadow(0 0 20px ${product.color}60)` }}>{product.icon}</div>
      <h1 style={{ fontFamily: "Syne, sans-serif", fontSize: 48, fontWeight: 900, letterSpacing: "-2px", marginBottom: 16 }}>{product.name}</h1>
      <p style={{ fontSize: 20, color: "rgba(240,244,255,0.6)", lineHeight: 1.6, marginBottom: 48 }}>{product.tagline}</p>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 48 }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(240,244,255,0.3)", textTransform: "uppercase" as const, letterSpacing: "2px", marginBottom: 16 }}>What's included</div>
          {product.features.map((f: string, i: number) => <div key={i} style={{ display: "flex", gap: 10, marginBottom: 12, fontSize: 14, color: "rgba(240,244,255,0.7)", lineHeight: 1.5 }}><span style={{ color: product.color }}>›</span>{f}</div>)}
        </div>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(240,244,255,0.3)", textTransform: "uppercase" as const, letterSpacing: "2px", marginBottom: 16 }}>Built for</div>
          {product.who.map((w: string, i: number) => <div key={i} style={{ padding: "10px 16px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.06)", marginBottom: 8, fontSize: 13, color: "rgba(240,244,255,0.7)" }}>{w}</div>)}
        </div>
      </div>
      <div style={{ background: `linear-gradient(135deg, ${product.color}15, rgba(255,255,255,0.02))`, border: `1px solid ${product.color}30`, borderRadius: 16, padding: 32, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 20, flexWrap: "wrap" as const }}>
        <div>
          <div style={{ fontFamily: "Syne, sans-serif", fontSize: 48, fontWeight: 900, color: product.color }}>${product.price}<span style={{ fontSize: 16, color: "rgba(240,244,255,0.4)" }}>/mo</span></div>
          <div style={{ fontSize: 13, color: "rgba(240,244,255,0.4)" }}>Cancel anytime. Unlock immediately.</div>
        </div>
        <button onClick={getAccess} disabled={checking} style={{ padding: "16px 32px", borderRadius: 12, border: "none", background: product.color, color: "#000", fontSize: 16, fontWeight: 800, cursor: "pointer", fontFamily: "Syne, sans-serif" }}>
          {checking ? "Loading…" : "Get Access →"}
        </button>
      </div>
    </div>
  );
}
