import type { ReactNode } from "react";

export const metadata = {
  title: "FanzoftheOne Marketplace",
  description: "AI-powered apps, agents, and tools. Built for builders.",
};

export default function MarketLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800;900&family=DM+Sans:wght@300;400;500;600&family=DM+Mono&display=swap" rel="stylesheet" />
        <style>{`
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
          :root {
            --void: #020408;
            --surface: #0a0e16;
            --card: #0f1420;
            --border: rgba(255,255,255,0.06);
            --border-glow: rgba(99,179,237,0.3);
            --text: #f0f4ff;
            --muted: rgba(240,244,255,0.45);
            --dim: rgba(240,244,255,0.2);
            --blue: #63b3ed;
            --cyan: #76e4f7;
            --purple: #b794f4;
            --green: #68d391;
            --orange: #f6ad55;
            --gold: #ecc94b;
            --red: #fc8181;
            --glow-blue: 0 0 40px rgba(99,179,237,0.15);
            --glow-purple: 0 0 40px rgba(183,148,244,0.15);
          }
          body {
            background: var(--void);
            color: var(--text);
            font-family: 'DM Sans', system-ui, sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
          }
          body::before {
            content: '';
            position: fixed;
            inset: 0;
            background:
              radial-gradient(ellipse 80% 50% at 50% -20%, rgba(99,179,237,0.08) 0%, transparent 60%),
              radial-gradient(ellipse 60% 40% at 80% 80%, rgba(183,148,244,0.06) 0%, transparent 60%);
            pointer-events: none;
            z-index: 0;
          }
          ::-webkit-scrollbar { width: 4px; }
          ::-webkit-scrollbar-thumb { background: rgba(99,179,237,0.3); border-radius: 2px; }
          @keyframes pulse-glow {
            0%, 100% { box-shadow: 0 0 20px rgba(99,179,237,0.2); }
            50% { box-shadow: 0 0 40px rgba(99,179,237,0.4); }
          }
          @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-6px); }
          }
          @keyframes scan {
            0% { transform: translateY(-100%); }
            100% { transform: translateY(100vh); }
          }
        `}</style>
      </head>
      <body>{children}</body>
    </html>
  );
}
