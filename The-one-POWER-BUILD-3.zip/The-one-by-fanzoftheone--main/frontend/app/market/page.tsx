"use client";
import { useState, useEffect, useRef } from "react";
import Link from "next/link";

const ALL_PRODUCTS = [
  { slug: "three-six-nine-builder", name: "3-6-9 Builder",         price: 59,  tag: "FEATURED", category: "Developer Tools",      desc: "Learn to build by building. Teacher agent gives 3 code choices. Pick one. Level up.", color: "#63b3ed",  icon: "⚡", locked: true },
  { slug: "construction-ops",        name: "Construction Ops",      price: 99,  tag: "POPULAR",  category: "Service Business",    desc: "Complete field service OS. Quotes, scheduling, invoicing, dispatch. Stop losing jobs to admin.", color: "#f6ad55",  icon: "🏗️", locked: true },
  { slug: "nervous-system",          name: "Nervous System",        price: 149, tag: "INFRA",    category: "Infrastructure",      desc: "IoT & fleet brain. Redis queue + AI agents fix problems before you know they exist.", color: "#76e4f7",  icon: "🧠", locked: true },
  { slug: "content-engine",          name: "Content Engine",        price: 129, tag: "AI",       category: "Content & Marketing", desc: "Script → Image → Voice → Video. One prompt. Two avatar profiles. Fully automated.", color: "#b794f4",  icon: "🎬", locked: true },
  { slug: "email-growth-engine",     name: "Email Growth Engine",   price: 79,  tag: "GROWTH",   category: "Marketing",           desc: "AI email sequences that actually convert. Personalized at scale.", color: "#68d391",  icon: "📧", locked: true },
  { slug: "marketing-automation-app",name: "Marketing Automation",  price: 99,  tag: "STACK",    category: "Marketing",           desc: "SEO + Content + Email agents running your growth 24/7 without you.", color: "#f6ad55",  icon: "📈", locked: true },
  { slug: "content-machine",         name: "Content Machine",       price: 89,  tag: "AI",       category: "Content & Marketing", desc: "Never write content manually again. AI generates, schedules, and optimizes.", color: "#b794f4",  icon: "✍️", locked: true },
  { slug: "seo-automation-app",      name: "SEO Automation",        price: 69,  tag: "RANK",     category: "Marketing",           desc: "Keyword research, content, and on-page optimization. AI does the work.", color: "#76e4f7",  icon: "🔍", locked: true },
  { slug: "little-pro",              name: "Little Pro",            price: 49,  tag: "BUILDER",  category: "Productivity",        desc: "Daily ledger, sessions, mastery loops. The personal OS for builders who ship.", color: "#ecc94b",  icon: "⚒️", locked: true },
  { slug: "productivity-tracker",    name: "Productivity Tracker",  price: 29,  tag: "FOCUS",    category: "Productivity",        desc: "Track what matters. Kill drift. Stay on the path.", color: "#68d391",  icon: "📊", locked: true },
  { slug: "play-better",             name: "Play Better",           price: 79,  tag: "COACH",    category: "Coaching",            desc: "AI coaching platform. Track athletes, measure progress, run data-driven sessions.", color: "#fc8181",  icon: "🏆", locked: true },
  { slug: "fanzo-core",              name: "Fanzo Core",            price: 49,  tag: "TEMPLATE", category: "Developer Tools",     desc: "Iron Core microservice scaffold. Strict typing, health checks. One-time purchase.", color: "#63b3ed",  icon: "🔩", locked: true, oneTime: true },
];

const CATEGORIES = ["All", "Developer Tools", "Infrastructure", "Content & Marketing", "Marketing", "Service Business", "Productivity", "Coaching"];

export default function MarketPage() {
  const [cat, setCat]           = useState("All");
  const [search, setSearch]     = useState("");
  const [cart, setCart]         = useState<string[]>([]);
  const [email, setEmail]       = useState("");
  const [checking, setChecking] = useState(false);
  const [subActive, setSubActive] = useState(false);
  const [hovering, setHovering] = useState<string | null>(null);
  const [showCart, setShowCart] = useState(false);
  const scanRef = useRef<HTMLDivElement>(null);

  const filtered = ALL_PRODUCTS.filter(p =>
    (cat === "All" || p.category === cat) &&
    (!search || p.name.toLowerCase().includes(search.toLowerCase()) || p.desc.toLowerCase().includes(search.toLowerCase()))
  );

  const cartItems    = ALL_PRODUCTS.filter(p => cart.includes(p.slug));
  const cartTotal    = cartItems.reduce((s, p) => s + p.price, 0);
  const inCart = (slug: string) => cart.includes(slug);

  function toggleCart(slug: string) {
    setCart(c => c.includes(slug) ? c.filter(x => x !== slug) : [...c, slug]);
  }

  async function checkAccess() {
    if (!email.trim()) return;
    setChecking(true);
    try {
      const res  = await fetch(`/api/payments/subscription/${encodeURIComponent(email)}`);
      const data = await res.json();
      setSubActive(data.active);
    } catch {}
    setChecking(false);
  }

  async function checkout() {
    if (cart.length === 0) return;
    // For now checkout first item — in production do a bundle
    const slug = cart[0];
    try {
      const res  = await fetch("/api/payments/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product_slug: slug, customer_email: email || undefined }),
      });
      const data = await res.json();
      if (data.checkout_url) window.location.href = data.checkout_url;
    } catch {}
  }

  const S: Record<string, any> = {
    nav: { position: "sticky", top: 0, zIndex: 100, background: "rgba(2,4,8,0.85)", backdropFilter: "blur(20px)", borderBottom: "1px solid var(--border)", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 },
    logo: { fontFamily: "Syne, sans-serif", fontSize: 18, fontWeight: 900, color: "var(--text)", letterSpacing: "-0.5px" },
    hero: { textAlign: "center" as const, padding: "80px 24px 60px", position: "relative" as const, zIndex: 1 },
    h1: { fontFamily: "Syne, sans-serif", fontSize: "clamp(36px,6vw,72px)", fontWeight: 900, lineHeight: 1.05, letterSpacing: "-2px", marginBottom: 20 },
    card: (p: any) => ({
      background: hovering === p.slug ? `linear-gradient(135deg, ${p.color}12 0%, var(--card) 60%)` : "var(--card)",
      border: `1px solid ${hovering === p.slug ? p.color + "40" : "var(--border)"}`,
      borderRadius: 16, padding: 24, cursor: "pointer", transition: "all 0.3s ease",
      transform: hovering === p.slug ? "translateY(-4px)" : "none",
      boxShadow: hovering === p.slug ? `0 20px 60px ${p.color}20` : "none",
      position: "relative" as const, overflow: "hidden" as const,
    }),
  };

  return (
    <div style={{ position: "relative", zIndex: 1 }}>
      {/* Scan line effect */}
      <div style={{ position: "fixed", top: 0, left: 0, right: 0, height: 1, background: "linear-gradient(90deg, transparent, rgba(99,179,237,0.4), transparent)", animation: "scan 8s linear infinite", zIndex: 0, pointerEvents: "none" }} />

      {/* Nav */}
      <nav style={S.nav}>
        <div style={S.logo}>
          <span style={{ color: "var(--blue)" }}>F</span>anz<span style={{ color: "var(--purple)" }}>of</span>the<span style={{ color: "var(--cyan)" }}>One</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <input value={email} onChange={e => setEmail(e.target.value)} placeholder="your@email.com"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid var(--border)", borderRadius: 8, padding: "7px 14px", color: "var(--text)", fontSize: 13, outline: "none", width: 200 }} />
          <button onClick={checkAccess} disabled={checking}
            style={{ padding: "7px 16px", borderRadius: 8, border: "1px solid var(--blue)", background: "transparent", color: "var(--blue)", fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" }}>
            {checking ? "..." : subActive ? "✓ Access Active" : "Check Access"}
          </button>
          {subActive && <span style={{ fontSize: 11, color: "var(--green)", fontWeight: 700 }}>SUBSCRIBED</span>}
          <button onClick={() => setShowCart(!showCart)} style={{ position: "relative", padding: "7px 16px", borderRadius: 8, background: cart.length > 0 ? "var(--blue)" : "rgba(255,255,255,0.06)", border: "1px solid var(--border)", color: cart.length > 0 ? "#000" : "var(--text)", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
            🛒 {cart.length > 0 ? `$${cartTotal}/mo` : "Cart"}
          </button>
          <Link href="/dashboard" style={{ fontSize: 12, color: "var(--muted)", textDecoration: "none" }}>Admin →</Link>
        </div>
      </nav>

      {/* Cart drawer */}
      {showCart && (
        <div style={{ position: "fixed", top: 64, right: 0, width: 340, background: "var(--card)", borderLeft: "1px solid var(--border)", height: "calc(100vh - 64px)", padding: 24, zIndex: 99, overflowY: "auto" }}>
          <div style={{ fontFamily: "Syne, sans-serif", fontSize: 16, fontWeight: 800, marginBottom: 20 }}>Your Cart</div>
          {cartItems.length === 0 ? (
            <div style={{ color: "var(--muted)", fontSize: 13 }}>No items yet. Add products below.</div>
          ) : (
            <>
              {cartItems.map(p => (
                <div key={p.slug} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0", borderBottom: "1px solid var(--border)" }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{p.name}</div>
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>${p.price}{p.oneTime ? " one-time" : "/mo"}</div>
                  </div>
                  <button onClick={() => toggleCart(p.slug)} style={{ background: "none", border: "none", color: "var(--muted)", cursor: "pointer", fontSize: 16 }}>✕</button>
                </div>
              ))}
              <div style={{ padding: "16px 0", display: "flex", justifyContent: "space-between", fontSize: 16, fontWeight: 800 }}>
                <span>Total</span><span style={{ color: "var(--blue)" }}>${cartTotal}/mo</span>
              </div>
              <button onClick={checkout} style={{ width: "100%", padding: "14px", borderRadius: 10, background: "var(--blue)", color: "#000", fontSize: 14, fontWeight: 800, border: "none", cursor: "pointer", fontFamily: "Syne, sans-serif" }}>
                Checkout with Stripe →
              </button>
              <div style={{ fontSize: 10, color: "var(--muted)", textAlign: "center", marginTop: 10 }}>Powered by Stripe. Cancel anytime.</div>
            </>
          )}
        </div>
      )}

      {/* Hero */}
      <div style={S.hero}>
        <div style={{ display: "inline-block", padding: "6px 16px", borderRadius: 20, border: "1px solid rgba(99,179,237,0.3)", background: "rgba(99,179,237,0.08)", fontSize: 11, color: "var(--blue)", fontWeight: 700, letterSpacing: "2px", marginBottom: 24 }}>
          THE ONE ECOSYSTEM — FANZOFTHEONE
        </div>
        <h1 style={S.h1}>
          <span style={{ color: "var(--text)" }}>AI tools that </span>
          <span style={{ background: "linear-gradient(135deg, var(--blue), var(--purple))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>actually work</span>
          <span style={{ color: "var(--text)" }}>.</span>
        </h1>
        <p style={{ fontSize: 18, color: "var(--muted)", maxWidth: 560, margin: "0 auto 40px", lineHeight: 1.7 }}>
          Apps, agents, and infrastructure built by a solo developer who needed them to exist. Battle-tested. No fluff.
        </p>
        <div style={{ display: "flex", justifyContent: "center", gap: 32, flexWrap: "wrap" }}>
          {[["12", "Products"], ["$29", "Starts at"], ["24/7", "AI Agents"]].map(([v, l]) => (
            <div key={l} style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "Syne, sans-serif", fontSize: 32, fontWeight: 900, color: "var(--blue)" }}>{v}</div>
              <div style={{ fontSize: 12, color: "var(--muted)", fontWeight: 600 }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Category filter */}
      <div style={{ display: "flex", gap: 8, padding: "0 24px 32px", flexWrap: "wrap", position: "relative", zIndex: 1 }}>
        {CATEGORIES.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{ padding: "8px 18px", borderRadius: 20, border: `1px solid ${cat === c ? "var(--blue)" : "var(--border)"}`, background: cat === c ? "rgba(99,179,237,0.12)" : "transparent", color: cat === c ? "var(--blue)" : "var(--muted)", fontSize: 12, fontWeight: 600, cursor: "pointer", transition: "all 0.2s" }}>
            {c}
          </button>
        ))}
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products…"
          style={{ marginLeft: "auto", background: "rgba(255,255,255,0.04)", border: "1px solid var(--border)", borderRadius: 20, padding: "8px 18px", color: "var(--text)", fontSize: 12, outline: "none", width: 200 }} />
      </div>

      {/* Product grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px,1fr))", gap: 16, padding: "0 24px 80px", position: "relative", zIndex: 1 }}>
        {filtered.map(p => (
          <div key={p.slug} style={S.card(p)} onMouseEnter={() => setHovering(p.slug)} onMouseLeave={() => setHovering(null)}>
            {/* Glow accent */}
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${p.color}, transparent)`, opacity: hovering === p.slug ? 1 : 0, transition: "opacity 0.3s" }} />

            {/* Tag + icon */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
              <span style={{ fontSize: 9, fontWeight: 800, padding: "3px 10px", borderRadius: 20, background: p.color + "20", color: p.color, border: `1px solid ${p.color}40`, letterSpacing: "1.5px" }}>{p.tag}</span>
              <span style={{ fontSize: 28, filter: `drop-shadow(0 0 8px ${p.color}60)` }}>{p.icon}</span>
            </div>

            {/* Name + desc */}
            <div style={{ fontFamily: "Syne, sans-serif", fontSize: 20, fontWeight: 800, marginBottom: 8, letterSpacing: "-0.5px" }}>{p.name}</div>
            <div style={{ fontSize: 13, color: "var(--muted)", lineHeight: 1.6, marginBottom: 20, minHeight: 60 }}>{p.desc}</div>

            {/* Category pill */}
            <div style={{ fontSize: 10, color: "var(--dim)", fontWeight: 600, marginBottom: 16, textTransform: "uppercase", letterSpacing: "1px" }}>{p.category}</div>

            {/* Price + action */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <span style={{ fontFamily: "Syne, sans-serif", fontSize: 28, fontWeight: 900, color: p.color }}>${p.price}</span>
                <span style={{ fontSize: 12, color: "var(--dim)" }}>{p.oneTime ? " one-time" : "/mo"}</span>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <Link href={`/market/product/${p.slug}`} style={{ padding: "8px 14px", borderRadius: 8, border: "1px solid var(--border)", background: "transparent", color: "var(--muted)", fontSize: 12, textDecoration: "none", fontWeight: 600 }}>Details</Link>
                <button onClick={() => toggleCart(p.slug)} style={{ padding: "8px 18px", borderRadius: 8, border: "none", background: inCart(p.slug) ? "var(--green)" : p.color, color: inCart(p.slug) ? "#000" : "#000", fontSize: 12, fontWeight: 800, cursor: "pointer", transition: "all 0.2s", fontFamily: "Syne, sans-serif" }}>
                  {inCart(p.slug) ? "✓ Added" : "Add →"}
                </button>
              </div>
            </div>

            {/* Lock indicator */}
            <div style={{ position: "absolute", top: 12, right: 52, fontSize: 10, color: "var(--dim)" }}>🔒</div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div style={{ borderTop: "1px solid var(--border)", padding: "40px 24px", textAlign: "center", position: "relative", zIndex: 1 }}>
        <div style={{ fontFamily: "Syne, sans-serif", fontSize: 14, fontWeight: 800, color: "var(--muted)", marginBottom: 8 }}>FanzoftheOne · THE ONE Ecosystem</div>
        <div style={{ fontSize: 12, color: "var(--dim)" }}>All products unlock immediately after payment. Cancel anytime.</div>
      </div>
    </div>
  );
}
