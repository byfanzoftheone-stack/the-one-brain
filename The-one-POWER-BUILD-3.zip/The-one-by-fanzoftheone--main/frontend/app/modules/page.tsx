"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useEffect, useState } from "react";
import { fetchModules } from "@/lib/api";

type Mod = { id: string; name: string; description: string; price: number; tags: string[]; status?: string; };
type InstalledMap = Record<string, boolean>;

const CATALOG_MODULES: Mod[] = [
  { id: "crm",          name: "CRM",             description: "Client records, accounts, contacts",        price: 0,  tags: ["business"]       },
  { id: "scheduling",   name: "Scheduling",      description: "Calendar, crew timing, job booking",        price: 0,  tags: ["operations"]     },
  { id: "payments",     name: "Payments",        description: "Invoicing, billing, Stripe integration",    price: 19, tags: ["business"]       },
  { id: "analytics",    name: "Analytics",       description: "Core KPI tracking and dashboards",          price: 0,  tags: ["analytics"]      },
  { id: "email-agent",  name: "Email Agent",     description: "Automated email campaigns",                 price: 9,  tags: ["ai", "marketing"]},
  { id: "content-agent",name: "Content Agent",   description: "AI content generation and scheduling",      price: 9,  tags: ["ai", "content"]  },
  { id: "seo-agent",    name: "SEO Agent",       description: "Keyword research and on-page optimization", price: 9,  tags: ["ai", "seo"]      },
  { id: "companion",    name: "Companion",       description: "Growth engine, memory, reflection",         price: 0,  tags: ["ai", "growth"]   },
  { id: "messaging",    name: "Messaging",       description: "In-app chat and notifications",             price: 0,  tags: ["communication"]  },
  { id: "ai-tools",     name: "AI Tools",        description: "Agent toolkit for automation",              price: 19, tags: ["ai"]             },
];

const TAG_COLORS: Record<string, string> = {
  business: "var(--blue)", operations: "var(--orange)", analytics: "var(--teal)",
  ai: "var(--purple)", marketing: "var(--green)", content: "var(--gold)",
  seo: "var(--blue)", growth: "var(--green)", communication: "var(--teal)",
};

export default function ModulesPage() {
  const [liveModules, setLiveModules] = useState<Mod[]>([]);
  const [loading, setLoading]         = useState(true);
  const [installed, setInstalled]     = useState<InstalledMap>({});
  const [installing, setInstalling]   = useState<string | null>(null);
  const [filter, setFilter]           = useState("");
  const [tagFilter, setTagFilter]     = useState("all");

  useEffect(() => {
    fetchModules()
      .then(d => {
        const raw = Array.isArray(d?.modules) ? d.modules : [];
        setLiveModules(raw.map((m: any) => ({ id: String(m.id ?? m.slug ?? ""), name: String(m.name ?? ""), description: String(m.description ?? ""), price: Number(m.price ?? 0), tags: Array.isArray(m.tags) ? m.tags : [] })));
      })
      .catch(() => {})
      .finally(() => setLoading(false));
    const saved = localStorage.getItem("theone_installed_modules");
    if (saved) try { setInstalled(JSON.parse(saved)); } catch {}
  }, []);

  async function install(mod: Mod) {
    setInstalling(mod.id);
    await new Promise(r => setTimeout(r, 600));
    const next = { ...installed, [mod.id]: true };
    setInstalled(next);
    localStorage.setItem("theone_installed_modules", JSON.stringify(next));
    try { await fetch(`/api/modules/install?module=${mod.id}&app=the-one`, { method: "POST" }); } catch {}
    setInstalling(null);
  }

  const allMods  = [...CATALOG_MODULES, ...liveModules.filter(l => !CATALOG_MODULES.find(c => c.id === l.id))];
  const allTags  = ["all", ...Array.from(new Set(allMods.flatMap(m => m.tags)))];
  const filtered = allMods.filter(m => {
    const matchText = !filter || m.name.toLowerCase().includes(filter.toLowerCase()) || m.description.toLowerCase().includes(filter.toLowerCase());
    const matchTag  = tagFilter === "all" || m.tags.includes(tagFilter);
    return matchText && matchTag;
  });

  const instCount = Object.values(installed).filter(Boolean).length;

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">Registry</div>
          <div className="mrow"><span className="mlabel">Total Modules</span><span className="mval">{allMods.length}</span></div>
          <div className="mrow"><span className="mlabel">Installed</span><span className="mval" style={{ color: "var(--green)" }}>{instCount}</span></div>
          <div className="mrow"><span className="mlabel">Available</span><span className="mval">{allMods.length - instCount}</span></div>
          <div className="mrow"><span className="mlabel">Live</span><span className="mval" style={{ fontSize: 10 }}>{loading ? "Loading…" : `${liveModules.length} from API`}</span></div>
        </div>
        <div className="rcard">
          <div className="rt">Installed</div>
          {Object.keys(installed).filter(k => installed[k]).length === 0
            ? <div style={{ fontSize: 11, color: "var(--text3)", fontWeight: 600 }}>None installed yet</div>
            : Object.keys(installed).filter(k => installed[k]).map(k => (
              <div key={k} className="mrow">
                <span className="mlabel">{k}</span>
                <span style={{ fontSize: 8, fontWeight: 800, color: "var(--green)" }}>✓ ON</span>
              </div>
            ))}
        </div>
      </>
    );
  }

  return (
    <WorkspaceShell title="Module Registry" subtitle="Browse, install, and manage modules" rightPanel={<RightPanel />}>

      {/* Search + filter */}
      <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
        <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Search modules…"
          style={{ background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "8px 12px", fontSize: 12, fontWeight: 600, color: "var(--text)", outline: "none", flex: 1, minWidth: 160, fontFamily: "Nunito Sans, sans-serif" }} />
        <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
          {allTags.map(t => (
            <button key={t} onClick={() => setTagFilter(t)}
              className={tagFilter === t ? "chip chip-accent" : "chip"} style={{ fontSize: 10 }}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Module grid */}
      <div className="grid-cards">
        {filtered.map(m => {
          const isInstalled  = !!installed[m.id];
          const isInstalling = installing === m.id;
          return (
            <div key={m.id} className="panel-card" style={{ borderTop: isInstalled ? "4px solid var(--green)" : undefined, position: "relative" }}>
              {m.tags[0] && (
                <div style={{ fontSize: 8, fontWeight: 800, padding: "2px 6px", borderRadius: 4, background: TAG_COLORS[m.tags[0]] + "20" ?? "var(--bg)", color: TAG_COLORS[m.tags[0]] ?? "var(--text3)", border: `1.5px solid ${TAG_COLORS[m.tags[0]]}40`, marginBottom: 6, display: "inline-block", fontFamily: "Nunito, sans-serif" }}>
                  {m.tags[0].toUpperCase()}
                </div>
              )}
              <div className="card-value" style={{ fontSize: 13 }}>{m.name}</div>
              <div className="card-note" style={{ marginBottom: 10 }}>{m.description}</div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 11, fontWeight: 800, color: m.price > 0 ? "var(--green)" : "var(--text3)", fontFamily: "Nunito, sans-serif" }}>
                  {m.price > 0 ? `$${m.price}/mo` : "Free"}
                </span>
                <button
                  onClick={() => !isInstalled && install(m)}
                  disabled={isInstalled || isInstalling}
                  className={isInstalled ? "chip" : "chip chip-accent"}
                  style={{ fontSize: 9, padding: "4px 10px", cursor: isInstalled ? "default" : "pointer" }}>
                  {isInstalling ? "…" : isInstalled ? "✓ Installed" : "Install"}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </WorkspaceShell>
  );
}
