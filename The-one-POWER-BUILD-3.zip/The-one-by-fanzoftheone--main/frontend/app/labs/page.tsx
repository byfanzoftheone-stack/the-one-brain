"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState, useEffect } from "react";
import Link from "next/link";

type Block = { level: number; label: string; desc: string; code: string; };
type Session = { id: string; goal: string; category: string; chosen: Block | null; ts: string; };
type BankEntry = { goal: string; category: string; chosen_level: number; code: string; saved_at: string; };

const CATEGORIES = [
  { slug: "api_endpoint", label: "API Endpoint",  icon: "⚡" },
  { slug: "data_model",   label: "Data Model",    icon: "🗂️" },
  { slug: "agent",        label: "Agent / Crew",  icon: "🤖" },
];

function genId() { return Math.random().toString(36).slice(2,10); }

export default function LabsPage() {
  const [goal, setGoal]             = useState("");
  const [category, setCategory]     = useState("api_endpoint");
  const [blocks, setBlocks]         = useState<Block[]>([]);
  const [loading, setLoading]       = useState(false);
  const [chosen, setChosen]         = useState<Block | null>(null);
  const [sessionId, setSessionId]   = useState(genId());
  const [bank, setBank]             = useState<BankEntry[]>([]);
  const [provider, setProvider]     = useState("");
  const [activeTab, setActiveTab]   = useState<"build"|"bank">("build");
  const [sessions, setSessions]     = useState<Session[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("theone_369_bank");
    if (saved) try { setBank(JSON.parse(saved)); } catch {}
    const savedSessions = localStorage.getItem("theone_369_sessions");
    if (savedSessions) try { setSessions(JSON.parse(savedSessions)); } catch {}
  }, []);

  async function getBlocks() {
    if (!goal.trim()) return;
    setLoading(true); setBlocks([]); setChosen(null);
    try {
      const res  = await fetch("/api/builder369/blocks", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ goal, category, session_id: sessionId }),
      });
      const data = await res.json();
      setBlocks(data.blocks || []);
      setProvider(data.provider || "templates");
    } catch {}
    setLoading(false);
  }

  async function chooseBlock(block: Block) {
    setChosen(block);
    const entry: BankEntry = { goal, category, chosen_level: block.level, code: block.code, saved_at: new Date().toLocaleString() };
    const nextBank = [entry, ...bank].slice(0, 50);
    setBank(nextBank);
    localStorage.setItem("theone_369_bank", JSON.stringify(nextBank));

    const session: Session = { id: sessionId, goal, category, chosen: block, ts: new Date().toLocaleString() };
    const nextSessions = [session, ...sessions].slice(0, 20);
    setSessions(nextSessions);
    localStorage.setItem("theone_369_sessions", JSON.stringify(nextSessions));

    try {
      await fetch("/api/builder369/choose", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, goal, category, chosen_level: block.level, chosen_code: block.code }),
      });
    } catch {}
  }

  function nextGoal() { setGoal(""); setBlocks([]); setChosen(null); setSessionId(genId()); }

  const LEVEL_COLORS: Record<number, string> = { 3: "var(--green)", 6: "var(--blue)", 9: "var(--purple)" };
  const LEVEL_LABELS: Record<number, string> = { 3: "SIMPLE", 6: "INTERMEDIATE", 9: "PRO" };

  const fi = { background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "9px 11px", fontSize: 12, fontWeight: 600, color: "var(--text)", outline: "none", width: "100%", fontFamily: "Nunito Sans, sans-serif" } as const;
  const tabS = (active: boolean) => ({ padding: "7px 18px", borderRadius: 8, border: "2px solid", borderColor: active ? "#111" : "var(--border2)", background: active ? "#111" : "transparent", color: active ? "#fff" : "var(--text2)", fontSize: 12, fontWeight: 800, cursor: "pointer", fontFamily: "Nunito, sans-serif" } as const);

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">3-6-9 Method</div>
          <div style={{ fontSize: 11, color: "var(--text2)", fontWeight: 600, lineHeight: 1.9 }}>
            <div><span style={{ color: "var(--green)", fontWeight: 800 }}>3</span> — Simple path</div>
            <div><span style={{ color: "var(--blue)", fontWeight: 800 }}>6</span> — Intermediate</div>
            <div><span style={{ color: "var(--purple)", fontWeight: 800 }}>9</span> — Production ready</div>
          </div>
        </div>
        <div className="rcard">
          <div className="rt">Code Bank</div>
          <div className="mrow"><span className="mlabel">Saved blocks</span><span className="mval">{bank.length}</span></div>
          <div className="mrow"><span className="mlabel">Sessions</span><span className="mval">{sessions.length}</span></div>
          <div className="mrow"><span className="mlabel">AI Provider</span><span className="mval" style={{ fontSize: 10, color: provider === "claude" ? "var(--purple)" : "var(--text3)" }}>{provider || "—"}</span></div>
        </div>
        {chosen && (
          <div className="rcard" style={{ borderLeft: `3px solid ${LEVEL_COLORS[chosen.level]}` }}>
            <div className="rt">Last Choice</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: LEVEL_COLORS[chosen.level] }}>{LEVEL_LABELS[chosen.level]} — Level {chosen.level}</div>
            <div style={{ fontSize: 11, color: "var(--text2)", marginTop: 4 }}>{chosen.label}</div>
          </div>
        )}
      </>
    );
  }

  return (
    <WorkspaceShell title="3-6-9 Builder" subtitle="Teacher presents 3 blocks · You choose · Code stored and recycled" rightPanel={<RightPanel />}>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 6, marginBottom: 18 }}>
        <button style={tabS(activeTab === "build")} onClick={() => setActiveTab("build")}>⚡ Build</button>
        <button style={tabS(activeTab === "bank")}  onClick={() => setActiveTab("bank")}>🗝 Code Bank ({bank.length})</button>
        <Link href="/market/product/three-six-nine-builder" style={{ marginLeft: "auto", padding: "7px 16px", borderRadius: 8, border: "2px solid var(--border2)", background: "var(--bg)", color: "var(--text2)", textDecoration: "none", fontSize: 11, fontWeight: 700, fontFamily: "Nunito, sans-serif" }}>Upgrade →</Link>
      </div>

      {activeTab === "build" && (
        <>
          {/* Goal input */}
          <div className="section-card" style={{ marginBottom: 14 }}>
            <div className="section-title">What do you want to build?</div>
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              <input style={fi} value={goal} onChange={e => setGoal(e.target.value)} onKeyDown={e => e.key === "Enter" && getBlocks()} placeholder="e.g. a REST endpoint to create users, a CRM data model, an agent that monitors APIs…" />
              <button className="btn btn-p" onClick={getBlocks} disabled={loading || !goal.trim()} style={{ whiteSpace: "nowrap" }}>
                {loading ? "⏳" : "Get Blocks"}
              </button>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {CATEGORIES.map(c => (
                <button key={c.slug} onClick={() => setCategory(c.slug)} className={category === c.slug ? "chip chip-accent" : "chip"} style={{ fontSize: 11 }}>
                  {c.icon} {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* The 3 blocks */}
          {blocks.length > 0 && !chosen && (
            <>
              <div className="sh"><span className="st">Teacher's 3 Block Options</span><div className="sl"></div><span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)" }}>PICK YOUR LEVEL</span></div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginBottom: 18 }}>
                {blocks.map((block, i) => (
                  <div key={i} onClick={() => chooseBlock(block)}
                    className="panel-card" style={{ cursor: "pointer", borderTop: `4px solid ${LEVEL_COLORS[block.level] || "var(--border)"}`, transition: "all .2s" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                      <span style={{ fontSize: 9, fontWeight: 800, padding: "2px 8px", borderRadius: 20, background: (LEVEL_COLORS[block.level] || "var(--text3)") + "20", color: LEVEL_COLORS[block.level] || "var(--text3)", border: `1.5px solid ${(LEVEL_COLORS[block.level] || "var(--text3)") + "40"}` }}>
                        LEVEL {block.level} — {LEVEL_LABELS[block.level] || "BLOCK"}
                      </span>
                    </div>
                    <div style={{ fontSize: 14, fontWeight: 900, color: "#111", fontFamily: "Nunito, sans-serif", marginBottom: 4, textShadow: "var(--puff-xs)" }}>{block.label}</div>
                    <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 12 }}>{block.desc}</div>
                    <pre style={{ fontFamily: "DM Mono, monospace", fontSize: 10, color: "var(--text2)", background: "var(--bg)", borderRadius: 6, padding: 10, overflowX: "auto", lineHeight: 1.7, maxHeight: 180, overflowY: "auto" }}>
                      {block.code}
                    </pre>
                    <button className="btn btn-p" style={{ width: "100%", marginTop: 10, fontSize: 11, background: LEVEL_COLORS[block.level] || "#111", borderColor: LEVEL_COLORS[block.level] }}>
                      Choose This Block →
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Chosen confirmation */}
          {chosen && (
            <div className="section-card" style={{ borderLeft: `4px solid ${LEVEL_COLORS[chosen.level]}`, marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 900, color: "#111", fontFamily: "Nunito, sans-serif" }}>✓ Saved to Code Bank — Level {chosen.level}</div>
                  <div style={{ fontSize: 11, color: "var(--text3)" }}>{chosen.label} · {goal}</div>
                </div>
                <button className="btn btn-p" onClick={nextGoal} style={{ fontSize: 11 }}>Next Goal →</button>
              </div>
              <pre style={{ fontFamily: "DM Mono, monospace", fontSize: 11, color: "var(--text2)", background: "#111", color: "#7ec67e", borderRadius: 8, padding: 14, overflowX: "auto", lineHeight: 1.7 }}>
                {chosen.code}
              </pre>
            </div>
          )}
        </>
      )}

      {/* Code Bank tab */}
      {activeTab === "bank" && (
        <>
          <div className="sh"><span className="st">Your Code Bank</span><div className="sl"></div><span style={{ fontSize: 9, fontWeight: 700, color: "var(--text3)" }}>{bank.length} BLOCKS SAVED</span></div>
          {bank.length === 0 ? (
            <div className="section-card"><div style={{ color: "var(--text3)", fontSize: 12 }}>No blocks saved yet. Make your first choice in the Build tab.</div></div>
          ) : bank.map((entry, i) => (
            <div key={i} className="section-card" style={{ marginBottom: 10, borderLeft: `3px solid ${LEVEL_COLORS[entry.chosen_level] || "var(--border)"}` }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 800, color: "#111", fontFamily: "Nunito, sans-serif" }}>{entry.goal}</div>
                  <div style={{ fontSize: 10, color: "var(--text3)" }}>{entry.category} · Level {entry.chosen_level} · {entry.saved_at}</div>
                </div>
                <span style={{ fontSize: 9, fontWeight: 800, padding: "2px 8px", borderRadius: 20, background: (LEVEL_COLORS[entry.chosen_level] || "var(--text3)") + "20", color: LEVEL_COLORS[entry.chosen_level] || "var(--text3)", alignSelf: "flex-start" }}>
                  L{entry.chosen_level}
                </span>
              </div>
              <pre style={{ fontFamily: "DM Mono, monospace", fontSize: 10, color: "var(--text2)", background: "var(--bg)", borderRadius: 6, padding: 10, overflowX: "auto", lineHeight: 1.6, maxHeight: 120, overflowY: "auto" }}>
                {entry.code}
              </pre>
            </div>
          ))}
        </>
      )}
    </WorkspaceShell>
  );
}
