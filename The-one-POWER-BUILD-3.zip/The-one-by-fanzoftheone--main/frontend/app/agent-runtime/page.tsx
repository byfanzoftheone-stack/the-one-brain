"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState } from "react";
import { request } from "@/lib/api";

export default function AgentRuntimePage() {
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState<string|null>(null);

  async function runAgent(name: string) {
    setLoading(name);
    try {
      const d = await request("/agents/run", { method: "POST", body: JSON.stringify({ agent_name: name, payload: { source: "agent-runtime-page" } }) });
      setResult(d);
    } catch(e:any) { setResult({ ok: false, error: e.message }); }
    setLoading(null);
  }

  return (
    <WorkspaceShell title="Agent Runtime" subtitle="Trigger real agent runs and write visible history">
      <div className="section-card">
        <div className="section-title">Fire Agents</div>
        <div className="chip-row">
          {["strategist", "builder", "auditor"].map(name => (
            <button key={name} onClick={() => runAgent(name)} disabled={loading !== null}
              className={`chip${loading === name ? " chip-accent" : ""}`}>
              {loading === name ? `Running ${name}…` : `▶ Run ${name}`}
            </button>
          ))}
        </div>
      </div>
      {result && (
        <div className="section-card">
          <div className="section-title">Result</div>
          <pre style={{ fontFamily: "DM Mono, monospace", fontSize: 11, color: result?.ok === false ? "var(--red)" : "var(--text2)", background: "var(--bg)", borderRadius: 8, padding: 14, overflowX: "auto", lineHeight: 1.7 }}>
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
    </WorkspaceShell>
  );
}
