"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState, useEffect } from "react";

type Reflection = { id: number; text: string; ts: string; };
type MemoryItem  = { key: string; value: string; };
type Direction   = { date: string; focus: string[]; guidance: string[]; recent_reflections: string[]; mode: string; };

export default function CompanionPage() {
  const [reflections, setReflections] = useState<Reflection[]>([]);
  const [memory, setMemory]           = useState<MemoryItem[]>([]);
  const [direction, setDirection]     = useState<Direction | null>(null);
  const [newReflection, setNewReflection] = useState("");
  const [memKey, setMemKey]           = useState("");
  const [memVal, setMemVal]           = useState("");
  const [saving, setSaving]           = useState(false);
  const [activeTab, setActiveTab]     = useState<"reflect" | "memory" | "direction">("direction");

  // Load from localStorage (works even when backend offline)
  useEffect(() => {
    try {
      const r = localStorage.getItem("theone_reflections");
      const m = localStorage.getItem("theone_memory");
      if (r) setReflections(JSON.parse(r));
      if (m) setMemory(JSON.parse(m));
    } catch {}
    // Also try backend
    fetch("/api/companion/direction").then(r => r.json()).then(setDirection).catch(() => {
      setDirection({ date: new Date().toISOString().slice(0,10), focus: ["building", "shipping", "growth"], guidance: ["Stay close to the revenue engine today.", "One module shipped beats three planned.", "Check the warehouse — your patterns tell the story."], recent_reflections: [], mode: "active" });
    });
  }, []);

  async function saveReflection() {
    if (!newReflection.trim()) return;
    setSaving(true);
    const entry: Reflection = { id: Date.now(), text: newReflection, ts: new Date().toLocaleString() };
    const next = [entry, ...reflections].slice(0, 50);
    setReflections(next);
    localStorage.setItem("theone_reflections", JSON.stringify(next));
    setNewReflection("");
    // Also hit backend
    try { await fetch("/api/companion/reflect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: entry.text }) }); } catch {}
    setSaving(false);
  }

  async function saveMemory() {
    if (!memKey.trim() || !memVal.trim()) return;
    setSaving(true);
    const next = [{ key: memKey, value: memVal }, ...memory.filter(m => m.key !== memKey)].slice(0, 30);
    setMemory(next);
    localStorage.setItem("theone_memory", JSON.stringify(next));
    setMemKey(""); setMemVal("");
    try { await fetch("/api/companion/memory", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: memKey, value: memVal }) }); } catch {}
    setSaving(false);
  }

  function deleteReflection(id: number) {
    const next = reflections.filter(r => r.id !== id);
    setReflections(next);
    localStorage.setItem("theone_reflections", JSON.stringify(next));
  }

  function deleteMemory(key: string) {
    const next = memory.filter(m => m.key !== key);
    setMemory(next);
    localStorage.setItem("theone_memory", JSON.stringify(next));
  }

  const fi = { background: "var(--bg)", border: "2px solid var(--border2)", borderRadius: 8, padding: "9px 11px", fontSize: 12, fontWeight: 600, color: "var(--text)", outline: "none", width: "100%", fontFamily: "Nunito Sans, sans-serif" } as const;
  const tabStyle = (active: boolean) => ({ padding: "7px 16px", borderRadius: 8, border: "2px solid", borderColor: active ? "#111" : "var(--border2)", background: active ? "#111" : "transparent", color: active ? "#fff" : "var(--text2)", fontSize: 12, fontWeight: 800, cursor: "pointer", fontFamily: "Nunito, sans-serif", boxShadow: active ? "var(--puff-xs)" : undefined } as const);

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">Growth Engine</div>
          {[
            { label: "Memory",     val: `${memory.length} keys`,       ok: memory.length > 0 },
            { label: "Reflections",val: `${reflections.length} saved`,  ok: reflections.length > 0 },
            { label: "Patterns",   val: "Active",                       ok: true },
            { label: "Planning",   val: direction ? "Ready" : "Loading",ok: !!direction },
          ].map(r => (
            <div key={r.label} className="mrow">
              <span className="mlabel">{r.label}</span>
              <span className="mval" style={{ fontSize: 11, color: r.ok ? "var(--green)" : "var(--text3)" }}>{r.val}</span>
            </div>
          ))}
        </div>
        {direction && (
          <div className="rcard">
            <div className="rt">Today's Focus</div>
            {direction.focus.slice(0, 3).map((f, i) => (
              <div key={i} className="mrow">
                <span className="mlabel">{f}</span>
                <span style={{ fontSize: 9, color: "var(--blue)", fontWeight: 700 }}>→</span>
              </div>
            ))}
          </div>
        )}
        <div className="rcard">
          <div className="rt">Quick Save</div>
          <textarea style={{ ...fi, height: 70, resize: "none", fontSize: 11 }} placeholder="Quick reflection…"
            value={newReflection} onChange={e => setNewReflection(e.target.value)} />
          <button className="btn btn-p" style={{ fontSize: 11, width: "100%", marginTop: 6 }} onClick={saveReflection} disabled={saving}>
            {saving ? "Saving…" : "💭 Save Reflection"}
          </button>
        </div>
      </>
    );
  }

  return (
    <WorkspaceShell title="Companion" subtitle="Growth engine · Memory · Reflection · Life direction" rightPanel={<RightPanel />}>

      {/* Guidance strip */}
      {direction && (
        <div style={{ background: "linear-gradient(135deg, #111 0%, #222 100%)", borderRadius: 12, padding: "16px 20px", marginBottom: 18, color: "#fff" }}>
          <div style={{ fontSize: 9, color: "#666", fontWeight: 700, textTransform: "uppercase", letterSpacing: "2px", marginBottom: 8 }}>Daily Direction · {direction.date}</div>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            {direction.guidance.map((g, i) => (
              <div key={i} style={{ fontSize: 12, fontWeight: 600, color: "#d4d4d4", lineHeight: 1.6, flex: "1 1 200px" }}>
                <span style={{ color: "var(--green)", marginRight: 6 }}>›</span>{g}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tabs */}
      <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
        {(["direction", "reflect", "memory"] as const).map(t => (
          <button key={t} style={tabStyle(activeTab === t)} onClick={() => setActiveTab(t)}>
            {t === "direction" ? "◈ Direction" : t === "reflect" ? "💭 Reflections" : "🗝 Memory"}
          </button>
        ))}
      </div>

      {/* Direction tab */}
      {activeTab === "direction" && direction && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div className="section-card">
            <div className="section-title">Focus Areas</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {direction.focus.map((f, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", background: "var(--bg)", border: "2px solid var(--border)", borderRadius: 8 }}>
                  <div style={{ width: 7, height: 7, borderRadius: "50%", background: ["var(--blue)","var(--green)","var(--orange)"][i % 3], flexShrink: 0 }} />
                  <span style={{ fontSize: 12, fontWeight: 700, color: "var(--text)", fontFamily: "Nunito, sans-serif" }}>{f}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="section-card">
            <div className="section-title">Guidance</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {direction.guidance.map((g, i) => (
                <div key={i} style={{ fontSize: 12, fontWeight: 600, color: "var(--text2)", lineHeight: 1.7, borderLeft: "3px solid var(--border2)", paddingLeft: 10 }}>{g}</div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Reflections tab */}
      {activeTab === "reflect" && (
        <>
          <div className="section-card" style={{ marginBottom: 14 }}>
            <div className="section-title">New Reflection</div>
            <textarea style={{ ...fi, height: 90, resize: "vertical" }} placeholder="What happened today? What did you learn? What patterns do you notice?" value={newReflection} onChange={e => setNewReflection(e.target.value)} />
            <button className="btn btn-p" style={{ marginTop: 10, fontSize: 12 }} onClick={saveReflection} disabled={saving}>
              {saving ? "Saving…" : "Save Reflection"}
            </button>
          </div>
          <div className="sh"><span className="st">Past Reflections</span><div className="sl"></div><span style={{ fontSize: 9, color: "var(--text3)", fontWeight: 700 }}>{reflections.length} SAVED</span></div>
          {reflections.length === 0 ? (
            <div className="section-card"><div style={{ fontSize: 12, color: "var(--text3)", fontWeight: 600 }}>No reflections yet. Start writing — patterns emerge over time.</div></div>
          ) : reflections.map(r => (
            <div key={r.id} className="section-card" style={{ marginBottom: 8 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <div style={{ fontSize: 9, color: "var(--text3)", fontFamily: "DM Mono, monospace" }}>{r.ts}</div>
                <button style={{ fontSize: 10, background: "none", border: "none", cursor: "pointer", color: "var(--text3)" }} onClick={() => deleteReflection(r.id)}>✕</button>
              </div>
              <div style={{ fontSize: 13, color: "var(--text)", fontWeight: 600, lineHeight: 1.7 }}>{r.text}</div>
            </div>
          ))}
        </>
      )}

      {/* Memory tab */}
      {activeTab === "memory" && (
        <>
          <div className="section-card" style={{ marginBottom: 14 }}>
            <div className="section-title">Save Memory</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 10, marginBottom: 10 }}>
              <div>
                <label style={{ display: "block", fontSize: 10, fontWeight: 700, color: "var(--text2)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 4, fontFamily: "Nunito, sans-serif" }}>Key</label>
                <input style={fi} placeholder="focus" value={memKey} onChange={e => setMemKey(e.target.value)} />
              </div>
              <div>
                <label style={{ display: "block", fontSize: 10, fontWeight: 700, color: "var(--text2)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 4, fontFamily: "Nunito, sans-serif" }}>Value</label>
                <input style={fi} placeholder="ship THE ONE ecosystem" value={memVal} onChange={e => setMemVal(e.target.value)} />
              </div>
            </div>
            <button className="btn btn-p" style={{ fontSize: 12 }} onClick={saveMemory} disabled={saving}>Save Memory</button>
          </div>
          <div className="sh"><span className="st">Stored Memory</span><div className="sl"></div><span style={{ fontSize: 9, color: "var(--text3)", fontWeight: 700 }}>{memory.length} KEYS</span></div>
          {memory.length === 0 ? (
            <div className="section-card"><div style={{ fontSize: 12, color: "var(--text3)", fontWeight: 600 }}>No memory keys saved yet.</div></div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {memory.map(m => (
                <div key={m.key} className="panel-card" style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ fontSize: 10, fontWeight: 800, color: "var(--blue)", fontFamily: "DM Mono, monospace", minWidth: 80 }}>{m.key}</div>
                  <div style={{ flex: 1, fontSize: 13, fontWeight: 600, color: "var(--text)" }}>{m.value}</div>
                  <button style={{ fontSize: 10, background: "none", border: "none", cursor: "pointer", color: "var(--text3)" }} onClick={() => deleteMemory(m.key)}>✕</button>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </WorkspaceShell>
  );
}
