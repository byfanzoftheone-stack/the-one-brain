"use client";
import WorkspaceShell from "../_components/layout/WorkspaceShell";
import { useState, useEffect, useRef } from "react";
import Link from "next/link";

const QUICKLINKS = [
  { icon: "⚒",  label: "Builder",   sub: "scaffold & ship",    href: "/builder"   },
  { icon: "📁",  label: "Apps",       sub: "deploy manager",     href: "/apps"      },
  { icon: "📦",  label: "Warehouse",  sub: "FanzSpot live",      href: "/warehouse" },
  { icon: "⬡",   label: "Agents",     sub: "teacher · student",  href: "/agents"    },
  { icon: "◈",   label: "Companion",  sub: "growth engine",      href: "/companion" },
  { icon: "📧",  label: "Gmail",      sub: "inbox digest",       href: "/gmail"     },
];

type ChatMsg = { role: "user" | "ai"; text: string; provider?: string; };

export default function DashboardPage() {
  const [health, setHealth]           = useState<any>(null);
  const [orchStatus, setOrchStatus]   = useState<any>(null);
  const [messages, setMessages]       = useState<ChatMsg[]>([]);
  const [input, setInput]             = useState("");
  const [thinking, setThinking]       = useState(false);
  const chatRef                       = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/api/health").then(r => r.json()).then(setHealth).catch(() => {});
    fetch("/api/orchestrator/status").then(r => r.json()).then(d => {
      setOrchStatus(d);
      const greeting = d?.ai_provider === "claude"
        ? "Claude connected. Full context on your ecosystem — SubiLife, NotAlones, FanzSpot, LegacyVault. What do you need?"
        : d?.ai_provider === "deepseek"
        ? "DeepSeek connected and ready. Ask me anything about your projects or give me a mission."
        : "THE ONE crew active (rule-based mode). Set ANTHROPIC_API_KEY or DEEPSEEK_API_KEY on Railway for live AI. What's the goal?";
      setMessages([{ role: "ai", text: greeting, provider: d?.ai_provider }]);
    }).catch(() => {
      setMessages([{ role: "ai", text: "THE ONE crew standing by. What's the goal?", provider: "fallback" }]);
    });
  }, []);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages, thinking]);

  async function send() {
    const text = input.trim();
    if (!text || thinking) return;
    const history = messages.map(m => ({ role: m.role === "ai" ? "assistant" : "user", text: m.text }));
    setMessages(m => [...m, { role: "user", text }]);
    setInput("");
    setThinking(true);
    try {
      const res  = await fetch("/api/orchestrator/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, history }),
      });
      const data = await res.json();
      setMessages(m => [...m, { role: "ai", text: data.response, provider: data.provider }]);
    } catch {
      setMessages(m => [...m, { role: "ai", text: "Crew offline. Check backend connection.", provider: "error" }]);
    }
    setThinking(false);
  }

  const backendOk  = health?.status === "ok";
  const aiProvider = orchStatus?.ai_provider || "fallback";
  const providerColor: Record<string, string> = {
    claude: "var(--purple)", deepseek: "var(--blue)", fallback: "var(--text3)", "rule-based": "var(--text3)"
  };

  function RightPanel() {
    return (
      <>
        <div className="rcard">
          <div className="rt">Live Services</div>
          {[
            { name: "Backend API",    sub: "Railway · FastAPI",          ok: backendOk },
            { name: "AI Brain",       sub: aiProvider,                   ok: aiProvider !== "fallback" && aiProvider !== "rule-based" },
            { name: "Warehouse",      sub: "FanzSpot proxy",             ok: backendOk },
            { name: "Gmail",          sub: "Google OAuth",               ok: false },
          ].map(s => (
            <div key={s.name} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 0", borderBottom: "2px solid var(--border)" }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: s.ok ? "var(--green)" : "var(--text3)", flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 800, color: "var(--text)", fontFamily: "Nunito, sans-serif" }}>{s.name}</div>
                <div style={{ fontSize: 9, color: "var(--text3)", fontWeight: 600 }}>{s.sub}</div>
              </div>
              <span style={{ fontSize: 9, fontWeight: 800, color: s.ok ? "var(--green)" : "var(--text3)" }}>{s.ok ? "LIVE" : "IDLE"}</span>
            </div>
          ))}
        </div>
        <div className="rcard">
          <div className="rt">AI Provider</div>
          <div style={{ textAlign: "center", padding: "8px 0" }}>
            <div style={{ fontSize: 18, fontWeight: 900, color: providerColor[aiProvider] ?? "var(--text3)",
              textShadow: "var(--puff-xs)", fontFamily: "Nunito, sans-serif", marginBottom: 4 }}>
              {aiProvider === "claude" ? "CLAUDE" : aiProvider === "deepseek" ? "DEEPSEEK" : "RULE-BASED"}
            </div>
            <div style={{ fontSize: 9, color: "var(--text3)", fontWeight: 600 }}>
              {aiProvider === "fallback" || aiProvider === "rule-based"
                ? "Set ANTHROPIC_API_KEY on Railway for live AI"
                : "Live AI responses active"}
            </div>
          </div>
        </div>
        <div className="rcard">
          <div className="rt">Quick Access</div>
          {QUICKLINKS.map(l => (
            <Link key={l.href} href={l.href} style={{ display: "flex", alignItems: "center", gap: 8,
              padding: "6px 8px", borderRadius: 7, textDecoration: "none",
              marginBottom: 4, background: "var(--bg)", border: "2px solid var(--border)" }}>
              <span style={{ fontSize: 14 }}>{l.icon}</span>
              <span style={{ fontSize: 11, fontWeight: 800, color: "#111", fontFamily: "Nunito, sans-serif" }}>{l.label}</span>
            </Link>
          ))}
        </div>
      </>
    );
  }

  return (
    <WorkspaceShell title="Command Center" subtitle="THE ONE — FanzoftheOne ecosystem" rightPanel={<RightPanel />}>

      {/* Quick nav */}
      <div className="qgrid" style={{ marginBottom: 20 }}>
        {QUICKLINKS.map(l => (
          <Link key={l.href} href={l.href} style={{ textDecoration: "none" }}>
            <div className="qcard">
              <span className="qi">{l.icon}</span>
              <span className="ql">{l.label}</span>
              <span className="qs">{l.sub}</span>
            </div>
          </Link>
        ))}
      </div>

      {/* Pipeline */}
      <div className="sh"><span className="st">Ecosystem Pipeline</span><div className="sl"></div>
        <span style={{ fontSize: 9, fontWeight: 700, color: backendOk ? "var(--green)" : "var(--orange)" }}>
          {backendOk ? "● BACKEND LIVE" : "○ BACKEND OFFLINE"}
        </span>
      </div>
      <div className="section-card" style={{ marginBottom: 18 }}>
        <div className="pip-row">
          {[
            { label: "Backend",    done: backendOk },
            { label: "AI Brain",   done: aiProvider !== "fallback" && aiProvider !== "rule-based" },
            { label: "Warehouse",  done: backendOk },
            { label: "Gmail",      done: false },
            { label: "Autopilot",  done: false },
          ].map(s => (
            <div key={s.label} className="pip-step">
              <div className={`pip-icon${s.done ? " done" : ""}`}>{s.done ? "✓" : "○"}</div>
              <div className="pip-name">{s.label}</div>
              <div className="pip-state">{s.done ? "ready" : "pending"}</div>
            </div>
          ))}
        </div>
        <div className="pbw" style={{ marginTop: 12 }}>
          <div className="pb" style={{ width: `${[backendOk, aiProvider !== "fallback", backendOk, false, false].filter(Boolean).length * 20}%` }} />
        </div>
      </div>

      {/* AI Orchestrator — real chat */}
      <div className="sh">
        <span className="st">AI Orchestrator</span><div className="sl"></div>
        <span style={{ fontSize: 9, fontWeight: 800, fontFamily: "Nunito, sans-serif",
          color: providerColor[aiProvider] ?? "var(--text3)" }}>
          {aiProvider.toUpperCase()} · THE ONE CREW
        </span>
      </div>
      <div className="orch-area">
        <div className="orch-hdr">
          <div className="orch-title">
            <div className="orch-op" style={{ background: providerColor[aiProvider] }} />
            &nbsp;THE ONE — COMMAND INTERFACE
          </div>
          <span className="cbadge" style={{
            background: aiProvider === "claude" ? "#f5f3ff" : aiProvider === "deepseek" ? "#eff6ff" : "var(--bg)",
            color: providerColor[aiProvider] ?? "var(--text3)",
            border: `2px solid ${aiProvider === "claude" ? "#ddd6fe" : aiProvider === "deepseek" ? "#bfdbfe" : "var(--border2)"}`,
          }}>
            {aiProvider === "claude" ? "claude-sonnet-4" : aiProvider === "deepseek" ? "deepseek-chat" : "rule-based"}
          </span>
        </div>

        <div ref={chatRef} className="orch-body">
          {messages.map((m, i) => (
            <div key={i} className="omsg" style={{ justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
              {m.role === "ai" && (
                <div className="oav" style={{ background: providerColor[m.provider ?? "fallback"] ?? "#111" }}>T1</div>
              )}
              <div className={`obub${m.role === "user" ? " obub-u" : ""}`}
                style={{ whiteSpace: "pre-wrap", lineHeight: 1.6 }}>{m.text}</div>
            </div>
          ))}
          {thinking && (
            <div className="omsg">
              <div className="oav" style={{ background: providerColor[aiProvider] ?? "#111" }}>T1</div>
              <div className="obub" style={{ color: "var(--text3)" }}>
                <span style={{ animation: "blink 1s infinite" }}>Thinking…</span>
              </div>
            </div>
          )}
        </div>

        <div className="orch-inp-row">
          <input className="orch-inp"
            placeholder={aiProvider === "fallback" ? "Ask THE ONE crew anything… (rule-based mode)" : "Ask THE ONE crew anything…"}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !e.shiftKey && send()}
          />
          <button className="orch-send" onClick={send} disabled={thinking}>SEND ↗</button>
        </div>
      </div>

    </WorkspaceShell>
  );
}
